/* CurveScout road network for routing on the rider's phone (backup when the public OSRM server is not available).
   Input: highway ways exported by osmium as GeoJSON lines (one LineString per way, with its tags).
   Output: one file per 1° square, data/net/net-<lat>_<lon>.json (every file far below 10 MB), and net-index.json.
   Each edge runs from crossing to crossing: [la1, lo1, la2, lo2] (1e-5 degree integers), metres, road class, flags
   (1 one-way, 2 toll, 4 motorway), curviness 0-255, name index, polyline of the points between (precision 5).
   Nodes are identified by their coordinates, so squares join without ids. Data: OpenStreetMap contributors, ODbL. */
import fs from 'node:fs'; import path from 'node:path'; import readline from 'node:readline'; import zlib from 'node:zlib';
/* GitHub Pages keeps a site under 1 GB: files are gzip-compressed (the phone unpacks them), residential streets stay out
   (a destination in town is reached from the nearest through road) and the whole network is capped at CAP_MB. */
export const CAP_MB = 150;   /* r44: the site plus roads plus SEO pages must stay under GitHub Pages' 1 GB */
const gz = o => zlib.gzipSync(JSON.stringify(o), { level: 9 });
const readGz = f => JSON.parse(zlib.gunzipSync(fs.readFileSync(f)).toString('utf8'));
function dirMB(d) { let t = 0; try { for (const f of fs.readdirSync(d)) t += fs.statSync(path.join(d, f)).size; } catch (e) {} return t / 1048576; }
export const CLASSES = ['motorway', 'motorway_link', 'trunk', 'trunk_link', 'primary', 'primary_link', 'secondary', 'secondary_link', 'tertiary', 'tertiary_link', 'unclassified'];
const CLS = Object.fromEntries(CLASSES.map((c, i) => [c, i]));
const R = 6371008.8, rad = Math.PI / 180;
export function hav(a, b) { const dLa = (b[0] - a[0]) * rad, dLo = (b[1] - a[1]) * rad; const s = Math.sin(dLa / 2) ** 2 + Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(s)); }
function enc(pts) { let o = '', pl = 0, pn = 0; const e = v => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const [la, lo] of pts) { o += e(la - pl) + e(lo - pn); pl = la; pn = lo; } return o; }
const q = v => Math.round(v * 1e5);
/* curviness: degrees of heading change per km, scaled to 0-255 */
function curv(pts) { let turn = 0, len = 0; for (let i = 1; i < pts.length; i++) { len += hav(pts[i - 1], pts[i]); if (i > 1) { const h1 = Math.atan2(pts[i - 1][1] - pts[i - 2][1], pts[i - 1][0] - pts[i - 2][0]), h2 = Math.atan2(pts[i][1] - pts[i - 1][1], pts[i][0] - pts[i - 1][0]); let d = Math.abs(h2 - h1); if (d > Math.PI) d = 2 * Math.PI - d; turn += d / rad; } }
  return len > 30 ? Math.min(255, Math.round(turn / (len / 1000) / 4)) : 0; }
function usable(t) { if (!t || !(t.highway in CLS)) return false; if (/^(no|private)$/.test(t.access || '') || /^(no|private)$/.test(t.motor_vehicle || '') || /^(no|private)$/.test(t.motorcycle || '')) return false; if (t.area === 'yes') return false; return true; }
/* geojsonseq lines -> network files. Two passes: count how many ways use each point (a crossing is used twice or more),
   then cut every way at its crossings. */
export async function exportNet(seqFile, outDir, log = () => {}, opt = {}) {   /* r88 opt: { majorsOnly, only: Set of squares, capMB } */
  if (opt.majorsOnly) return exportCoverage(seqFile, outDir, log, opt);   /* r89: coverage tiles have their own exporter (below) */
  const lines = async function* () { const rl = readline.createInterface({ input: fs.createReadStream(seqFile), crlfDelay: Infinity }); for await (let l of rl) { l = l.replace(/^\x1e/, '').trim(); if (!l) continue; let f; try { f = JSON.parse(l); } catch (e) { continue; } if (!f.geometry || f.geometry.type !== 'LineString' || !usable(f.properties)) continue; yield f; } };
  const use = new Map(); let ways = 0;
  for await (const f of lines()) { ways++; const c = f.geometry.coordinates; c.forEach((p, i) => { const k = q(p[1]) + ',' + q(p[0]); use.set(k, (use.get(k) || 0) + (i === 0 || i === c.length - 1 ? 2 : 1)); }); }
  log('network: ' + ways + ' ways, ' + use.size + ' points');
  const cells = new Map(), names = new Map(); let edges = 0;
  const cellOf = (la, lo) => Math.floor(la / 1e5) + '_' + Math.floor(lo / 1e5);
  const put = (a, b, mid, t, len, cv) => { const ow = t.oneway === 'yes' || t.oneway === '1' || t.highway === 'motorway' || t.junction === 'roundabout' ? 1 : 0;
    const fl = ow | (t.toll === 'yes' ? 2 : 0) | (/^motorway/.test(t.highway) ? 4 : 0); const nm = t.ref && /^(motorway|trunk)/.test(t.highway) ? t.ref : (t.name || t.ref || '');
    let ni = names.get(nm); if (ni === undefined) { ni = names.size; names.set(nm, ni); }
    const c = cellOf(a[0], a[1]); let C = cells.get(c); if (!C) { C = { e: [], nm: new Map() }; cells.set(c, C); }
    let li = C.nm.get(nm); if (li === undefined) { li = C.nm.size; C.nm.set(nm, li); }
    C.e.push(a[0], a[1], b[0], b[1], Math.round(len), CLS[t.highway], fl, cv, li, enc(mid)); edges++; };
  for await (const f of lines()) { const t = f.properties; let c = f.geometry.coordinates.map(p => [q(p[1]), q(p[0])]); if (t.oneway === '-1') { c = c.reverse(); t.oneway = 'yes'; }
    let start = 0; for (let i = 1; i < c.length; i++) { if (i === c.length - 1 || (use.get(c[i][0] + ',' + c[i][1]) || 0) >= 2) { const seg = c.slice(start, i + 1); const fl = seg.map(p => [p[0] / 1e5, p[1] / 1e5]); let len = 0; for (let k = 1; k < fl.length; k++) len += hav(fl[k - 1], fl[k]);
      if (len > 0) put(seg[0], seg[seg.length - 1], thin(seg.slice(1, -1)), t, len, curv(fl)); start = i; } } }
  fs.mkdirSync(outDir, { recursive: true }); const idxF = path.join(outDir, 'net-index.json'); let idx = { v: 1, cells: {} }; try { idx = JSON.parse(fs.readFileSync(idxF, 'utf8')); } catch (e) {}
  for (const [c, C] of cells) { const f = path.join(outDir, 'net-' + c + '.json.gz'); let prev = null; try { prev = readGz(f); } catch (e) {}
    if (!prev && dirMB(outDir) > CAP_MB) { log('network: size cap reached (' + CAP_MB + ' MB) - ' + c + ' left out'); continue; }
    /* a square shared by two regions: keep the edges of both, without doubles */
    let nmArr = [...C.nm.keys()], e = C.e; if (prev && prev.e && prev.names) { const seen = new Set(); for (let i = 0; i < e.length; i += 10) seen.add(e.slice(i, i + 4).join(',')); const map = new Map(nmArr.map((n, i) => [n, i]));
      for (let i = 0; i < prev.e.length; i += 10) { if (seen.has(prev.e.slice(i, i + 4).join(','))) continue; const n = prev.names[prev.e[i + 8]] || ''; let li = map.get(n); if (li === undefined) { li = nmArr.length; nmArr.push(n); map.set(n, li); } e.push(...prev.e.slice(i, i + 8), li, prev.e[i + 9]); } }
    const body = gz({ v: 1, cell: c, names: nmArr, e }); fs.writeFileSync(f, body);
    { const m = []; for (let i = 0; i < e.length; i += 10) if (e[i + 5] <= 7) for (let k = 0; k < 10; k++) m.push(e[i + k]); fs.writeFileSync(path.join(outDir, 'netm-' + c + '.json.gz'), gz({ v: 1, cell: c, names: nmArr, e: m })); } idx.cells[c] = { edges: e.length / 10, kb: Math.round(body.length / 1024) }; }
  idx.built = new Date().toISOString(); idx.licence = 'Road data (c) OpenStreetMap contributors, ODbL'; fs.writeFileSync(idxF, JSON.stringify(idx));
  log('network: ' + edges + ' edges in ' + cells.size + ' squares'); return { ways, edges, cells: cells.size };
}
/* keep the shape but drop points closer than ~15 m to the straight line between their neighbours */
function thin(pts) { if (pts.length < 3) return pts; const out = [pts[0]]; for (let i = 1; i < pts.length - 1; i++) { const a = out[out.length - 1], b = pts[i], c = pts[i + 1]; const ax = (b[1] - a[1]) * Math.cos(b[0] / 1e5 * rad), ay = b[0] - a[0], bx = (c[1] - a[1]) * Math.cos(b[0] / 1e5 * rad), by = c[0] - a[0];
  const L = Math.hypot(bx, by) || 1, d = Math.abs(ax * by - ay * bx) / L * 1.11; if (d > 15 || Math.hypot(ax, ay) * 1.11 > 400) out.push(b); } out.push(pts[pts.length - 1]); return out; }

/* ==== r89 COVERAGE TILES (audit r88 N1) ====
   The r88 main-road fill joined roads by their COORDINATES (a bridge and the road beneath it became one junction), kept
   roads closed to all vehicles, dropped roads open to motorcycles by a specific exception, and kept only one of two roads
   sharing their ends. Coverage tiles are therefore written by this exporter only, in a format of their own (netc-*, v2):
   - junctions are OpenStreetMap NODE IDS (osmium export --attributes id,way_nodes): two ways meet only where they share a
     node; each edge carries its two node ids (node_ids) and its way id (w);
   - motorcycle access by the most specific tag present: motorcycle, then motor_vehicle, then vehicle, then access;
   - direction: oneway:motorcycle before oneway; -1 runs backwards; motorway, motorway_link and roundabouts are one-way;
     reversible/alternating ways (direction by time of day) are left out;
   - turn restrictions with a via NODE (no_* and only_*, plain or restriction:motorcycle, honouring except=motorcycle) travel
     in the tile (rs) and the phone router obeys them; restrictions with a via WAY are counted and reported, not encoded;
   - an edge is one way between two junction nodes, identified by (way, from-node, to-node): two roads sharing their ends
     both stay, also when a second region merges into the same square;
   - the size cap is checked against the bytes the new or merged file will have, before it is written.
   Output files land in opt.stage (an owned folder) when given; the caller validates and adopts them. */
export const COVERAGE_VERSION = 'netc-2';
const DENY = /^(no|private|agricultural|forestry|delivery|emergency|military|permit|customers|use_sidepath)$/;
export function motorcycleAccess(t) {
  for (const k of ['motorcycle', 'motor_vehicle', 'vehicle', 'access']) { const v = String(t[k] || '').trim().toLowerCase(); if (!v) continue; return !DENY.test(v.split(';')[0]); }
  return true;
}
export function direction(t) {
  const v = String((t['oneway:motorcycle'] != null ? t['oneway:motorcycle'] : t.oneway) || '').trim().toLowerCase();
  if (v === 'reversible' || v === 'alternating') return null;   /* time-dependent - left out */
  if (v === '-1' || v === 'reverse') return -1;
  if (v === 'yes' || v === '1' || v === 'true') return 1;
  if (v === 'no' || v === '0' || v === 'false') return 0;
  if (t.highway === 'motorway' || t.highway === 'motorway_link' || t.junction === 'roundabout' || t.junction === 'circular') return 1;
  return 0;
}
function usableCov(t) { if (!t || !(t.highway in CLS) || CLS[t.highway] > 7) return false; if (t.area === 'yes') return false; return motorcycleAccess(t) && direction(t) !== null; }
const nid = v => (typeof v === 'number' ? v : (/^\d+$/.test(String(v)) && Number.isSafeInteger(+v) ? +v : String(v)));
/* r91: OPL escapes a character as %<hex code point>% (e.g. %20% for a space) - it is not URL encoding. r90 used
   decodeURIComponent and 79 of 170 coverage regions failed with "URI malformed" on a relation name with a % in it. */
export function oplText(s) { return String(s).replace(/%([0-9a-fA-F]{1,6})%/g, (m, h) => { const c = parseInt(h, 16); return c >= 0 && c <= 0x10ffff ? String.fromCodePoint(c) : m; }); }
export function parseRestrictionsOpl(text) {   /* osmium cat -f opl of type=restriction relations */
  const out = [], viaWay = { count: 0 }; let skipped = 0;
  for (const line of String(text).split('\n')) { if (!/^r\d+/.test(line)) continue;
    const T = {}; const tm = line.match(/ T(\S*)/); if (tm) for (const kv of tm[1].split(',')) { const i = kv.indexOf('='); if (i > 0) T[oplText(kv.slice(0, i))] = oplText(kv.slice(i + 1)); }
    if (T.type !== 'restriction') continue; const kind = T['restriction:motorcycle'] || T.restriction || ''; if (!/^(no|only)_/.test(kind)) { skipped++; continue; }
    if (/(^|;)\s*motorcycle\s*(;|$)/.test(T.except || '')) { skipped++; continue; }
    const mm = line.match(/ M(\S*)/); if (!mm) continue; const mem = mm[1].split(',').map(x => { const k = x.match(/^([nwr])(\d+)@(.*)$/); return k ? { t: k[1], id: +k[2], role: k[3] } : null; }).filter(Boolean);
    const from = mem.filter(m => m.role === 'from' && m.t === 'w'), to = mem.filter(m => m.role === 'to' && m.t === 'w'), via = mem.filter(m => m.role === 'via');
    if (via.length !== 1 || via[0].t !== 'n' || from.length !== 1 || to.length !== 1) { if (via.some(v => v.t === 'w')) viaWay.count++; else skipped++; continue; }
    out.push({ from: from[0].id, via: via[0].id, to: to[0].id, only: kind.startsWith('only_') });
  }
  return { list: out, viaWay: viaWay.count, skipped };
}
export async function exportCoverage(seqFile, outDir, log = () => {}, opt = {}) {
  const capB = (opt.capMB != null ? opt.capMB : CAP_MB) * 1048576, stage = opt.stage || outDir, prefix = opt.prefix || 'netc';
  fs.mkdirSync(stage, { recursive: true });
  const lines = async function* () { const rl = readline.createInterface({ input: fs.createReadStream(seqFile), crlfDelay: Infinity }); for await (let l of rl) { l = l.replace(/^\x1e/, '').trim(); if (!l) continue; let f; try { f = JSON.parse(l); } catch (e) { continue; } if (!f.geometry || f.geometry.type !== 'LineString') continue; yield f; } };
  const use = new Map(), pos = new Map(); let ways = 0, refused = 0, noIds = 0;
  for await (const f of lines()) { const t = f.properties || {}; if (!usableCov(t)) { refused++; continue; }
    const ids = t['@way_nodes'], c = f.geometry.coordinates; if (!Array.isArray(ids) || ids.length !== c.length) { noIds++; continue; } ways++;
    ids.forEach((n, i) => { const k = nid(n); use.set(k, (use.get(k) || 0) + (i === 0 || i === ids.length - 1 ? 2 : 1)); pos.set(k, [q(c[i][1]), q(c[i][0])]); }); }
  if (noIds) throw Error('network: ' + noIds + ' ways without node identities - export them with --attributes id,way_nodes');
  const cells = new Map(); let edges = 0;
  const cellOf = p => Math.floor(p[0] / 1e5) + '_' + Math.floor(p[1] / 1e5);
  const cellObj = c => { let C = cells.get(c); if (!C) { C = { e: [], ids: [], w: [], nm: new Map(), rs: [] }; cells.set(c, C); } return C; };
  for await (const f of lines()) { const t = f.properties || {}; if (!usableCov(t)) continue; const dir = direction(t);
    let ids = t['@way_nodes'].map(nid), c = f.geometry.coordinates.map(p => [q(p[1]), q(p[0])]); if (dir === -1) { ids = ids.slice().reverse(); c = c.slice().reverse(); }
    const way = nid(t['@id'] != null ? t['@id'] : t.id), fl = (dir !== 0 ? 1 : 0) | (t.toll === 'yes' ? 2 : 0) | (/^motorway/.test(t.highway) ? 4 : 0);
    const nm = String(t.ref && /^(motorway|trunk)/.test(t.highway) ? t.ref : (t.name || t.ref || ''));
    let start = 0;
    for (let i = 1; i < c.length; i++) { if (i === c.length - 1 || (use.get(ids[i]) || 0) >= 2) {
      const seg = c.slice(start, i + 1), flt = seg.map(p => [p[0] / 1e5, p[1] / 1e5]); let len = 0; for (let k = 1; k < flt.length; k++) len += hav(flt[k - 1], flt[k]);
      if (len > 0 && ids[start] !== ids[i]) { const C = cellObj(cellOf(seg[0])); let li = C.nm.get(nm); if (li === undefined) { li = C.nm.size; C.nm.set(nm, li); }
        C.e.push(seg[0][0], seg[0][1], seg[seg.length - 1][0], seg[seg.length - 1][1], Math.max(1, Math.round(len)), CLS[t.highway], fl, curv(flt), li, enc(thin(seg.slice(1, -1))));
        C.ids.push(ids[start], ids[i]); C.w.push(way); edges++; }
      start = i; } } }
  let rinfo = { list: [], viaWay: 0, skipped: 0 };
  if (opt.restrictions) rinfo = typeof opt.restrictions === 'string' ? parseRestrictionsOpl(opt.restrictions) : { list: opt.restrictions, viaWay: 0, skipped: 0 };
  let rkept = 0; for (const r of rinfo.list) { const p = pos.get(nid(r.via)); if (!p) continue; const C = cells.get(cellOf(p)) || cellObj(cellOf(p)); C.rs.push(nid(r.from), nid(r.via), nid(r.to), r.only ? 1 : 0); rkept++; }
  /* write: merge with the square's existing coverage file (identity = way + from node + to node), cap by projected size */
  let used = 0; try { for (const f of fs.readdirSync(outDir)) used += fs.statSync(path.join(outDir, f)).size; } catch (e) {}
  const written = {}, capped = [], skipped = [];
  for (const [c, C] of cells) {
    if (opt.only && !opt.only.has(c)) { skipped.push(c); continue; }
    if (fs.existsSync(path.join(outDir, 'net-' + c + '.json.gz'))) { skipped.push(c); continue; }   /* a square with a full file is never touched */
    if (!C.e.length && !C.rs.length) continue;
    const f = path.join(outDir, prefix + '-' + c + '.json.gz'); let prev = null, prevB = 0; try { prevB = fs.statSync(f).size; prev = readGz(f); } catch (e) {}
    let names = [...C.nm.keys()], e = C.e.slice(), node_ids = C.ids.slice(), w = C.w.slice(), rs = C.rs.slice();
    if (prev && prev.v === 2 && Array.isArray(prev.e)) { const seen = new Set(); for (let i = 0; i < w.length; i++) seen.add(w[i] + '|' + node_ids[2 * i] + '|' + node_ids[2 * i + 1]);
      const map = new Map(names.map((n, i) => [n, i]));
      for (let i = 0, k = 0; i < prev.e.length; i += 10, k++) { const key = prev.w[k] + '|' + prev.node_ids[2 * k] + '|' + prev.node_ids[2 * k + 1]; if (seen.has(key)) continue; seen.add(key);
        const n = prev.names[prev.e[i + 8]] || ''; let li = map.get(n); if (li === undefined) { li = names.length; names.push(n); map.set(n, li); }
        e.push(...prev.e.slice(i, i + 8), li, prev.e[i + 9]); node_ids.push(prev.node_ids[2 * k], prev.node_ids[2 * k + 1]); w.push(prev.w[k]); }
      const rseen = new Set(); for (let i = 0; i < rs.length; i += 4) rseen.add(rs.slice(i, i + 4).join('|')); for (let i = 0; i < (prev.rs || []).length; i += 4) { const k = prev.rs.slice(i, i + 4).join('|'); if (!rseen.has(k)) { rseen.add(k); rs.push(...prev.rs.slice(i, i + 4)); } } }
    const body = gz({ v: 2, gen: COVERAGE_VERSION, cell: c, names, e, node_ids, w, rs });
    if (used - prevB + body.length > capB) { capped.push(c); log('network: size cap (' + (capB / 1048576).toFixed(1) + ' MB) - ' + c + ' left out'); continue; }
    fs.writeFileSync(path.join(stage, prefix + '-' + c + '.json.gz'), body); used += body.length - prevB; written[c] = { edges: e.length / 10, bytes: body.length };
  }
  log('network (coverage): ' + Object.keys(written).length + ' squares written, ' + capped.length + ' capped, ' + refused + ' ways refused (access/class/direction), ' + rkept + ' turn restrictions kept, ' + rinfo.viaWay + ' via-way restrictions not encoded');
  return { ways, edges, refusedWays: refused, cells: Object.keys(written).length, written, capped: capped.length ? capped : null, skipped, restrictions: { kept: rkept, viaWay: rinfo.viaWay, skipped: rinfo.skipped } };
}
