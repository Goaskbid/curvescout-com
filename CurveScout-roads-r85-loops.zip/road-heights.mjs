/* r60 HEIGHT PROFILE FOR EVERY STORED ROAD (runs inside the road job on GitHub's machines, after the routing passes)
 * For each ride with a stored road: 120 points spaced evenly along the road, the ground height at each from the open
 * Terrain Tiles on AWS (terrarium PNG, zoom 10, about 150 m a pixel; credited on the site), written next to the roads:
 *   data/roads/heights-<cell>.json.gz   { v: 1, cell, z: 10, heights: { <ride id>: [m, m, ...] } }
 * Rides that already have heights are skipped, so a stopped run carries on. One tile is fetched once and reused; at most
 * 6 requests at a time. No keys, no accounts. Exports run(outDir, deadline, log) -> true when every ride has heights. */
import fs from 'node:fs'; import path from 'node:path'; import zlib from 'node:zlib';
const URL0 = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/'; const Z = 10, N = 120;
const gz = f => JSON.parse(zlib.gunzipSync(fs.readFileSync(f)).toString('utf8'));
function decode(s) { const out = []; let i = 0, la = 0, lo = 0; while (i < s.length) { for (const k of [0, 1]) { let r = 0, sh = 0, b; do { b = s.charCodeAt(i++) - 63; r |= (b & 31) << sh; sh += 5; } while (b >= 32); const d = r & 1 ? ~(r >> 1) : r >> 1; if (k) lo += d; else la += d; } out.push([la / 1e5, lo / 1e5]); } return out; }
const hav = (a, b) => { const r = Math.PI / 180, x = Math.sin((b[0] - a[0]) * r / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin((b[1] - a[1]) * r / 2) ** 2; return 12742 * Math.asin(Math.sqrt(x)); };
/* a minimal PNG reader for 8-bit RGB / RGBA, non-interlaced (what terrarium tiles are) */
export function png(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('not a png');
  let o = 8, w = 0, h = 0, ct = 0, idat = [];
  while (o < buf.length) { const len = buf.readUInt32BE(o), type = buf.toString('ascii', o + 4, o + 8), d = buf.subarray(o + 8, o + 8 + len);
    if (type === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); if (d[8] !== 8 || d[12] !== 0) throw new Error('unsupported png'); ct = d[9]; }
    else if (type === 'IDAT') idat.push(d); else if (type === 'IEND') break; o += 12 + len; }
  const bpp = ct === 6 ? 4 : ct === 2 ? 3 : 0; if (!bpp) throw new Error('colour type ' + ct);
  const raw = zlib.inflateSync(Buffer.concat(idat)), stride = w * bpp, px = Buffer.alloc(h * stride);
  for (let y = 0; y < h; y++) { const f = raw[y * (stride + 1)], src = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)), row = y * stride;
    for (let x = 0; x < stride; x++) { const a = x >= bpp ? px[row + x - bpp] : 0, b = y ? px[row - stride + x] : 0, c = x >= bpp && y ? px[row - stride + x - bpp] : 0; let v = src[x];
      if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1; else if (f === 4) { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      px[row + x] = v & 255; } }
  return { w, h, bpp, px };
}
export const heightAt = (t, fx, fy) => { const x = Math.min(t.w - 1, Math.floor(fx * t.w)), y = Math.min(t.h - 1, Math.floor(fy * t.h)), i = (y * t.w + x) * t.bpp; return t.px[i] * 256 + t.px[i + 1] + t.px[i + 2] / 256 - 32768; };
export function samples(line, n) {   /* n points evenly spaced along the line */
  const cum = [0]; for (let i = 1; i < line.length; i++) cum.push(cum[i - 1] + hav(line[i - 1], line[i])); const L = cum[cum.length - 1], out = []; let j = 1;
  for (let k = 0; k < n; k++) { const s = L * k / (n - 1); while (j < cum.length - 1 && cum[j] < s) j++; const a = line[j - 1], b = line[j], f = (s - cum[j - 1]) / ((cum[j] - cum[j - 1]) || 1); out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]); }
  return out; }
export async function run(OUT, DEADLINE, log, fetchFn) {
  const F = fetchFn || fetch; const tiles = new Map(); let busy = 0; const q = [];
  const slot = () => new Promise(r => { if (busy < 6) { busy++; r(); } else q.push(r); }); const free = () => { const n = q.shift(); if (n) n(); else busy--; };
  const tile = (x, y) => { const k = x + '/' + y; if (!tiles.has(k)) tiles.set(k, (async () => { await slot(); try { for (let t = 0; t < 3; t++) { try { const r = await F(URL0 + Z + '/' + k + '.png'); if (r.ok) return png(Buffer.from(await r.arrayBuffer())); } catch (e) {} await new Promise(r => setTimeout(r, 1000 * (t + 1))); } return null; } finally { free(); } })()); if (tiles.size > 4000) tiles.delete(tiles.keys().next().value); return tiles.get(k); };
  const n2 = 2 ** Z; let done = 0, made = 0, all = true;
  for (const f of fs.readdirSync(OUT).filter(f => /^roads-\d+-\d+\.json\.gz$/.test(f)).sort()) {
    if (Date.now() > DEADLINE) { all = false; break; }
    const cell = f.slice(6, -8), hf = path.join(OUT, 'heights-' + cell + '.json.gz'); const roads = gz(path.join(OUT, f)).roads || {};
    const H = fs.existsSync(hf) ? gz(hf) : { v: 1, cell, z: Z, src: 'Terrain Tiles on AWS (terrarium)', heights: {} }; let ch = false;
    await Promise.all(Object.entries(roads).map(async ([id, v]) => { if (H.heights[id] || !v || !v[0]) return; if (Date.now() > DEADLINE) { all = false; return; }
      const pts = samples(decode(v[0]), N); const hs = [];
      for (const [la0, lo] of pts) { const la = Math.max(-85, Math.min(85, la0)), s = Math.sin(la * Math.PI / 180), xf = (lo + 180) / 360 * n2, yf = (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * n2, x = Math.floor(xf), y = Math.floor(yf);
        const t = await tile(((x % n2) + n2) % n2, Math.max(0, Math.min(n2 - 1, y))); if (!t) return; hs.push(Math.round(heightAt(t, xf - x, yf - y))); }
      if (hs.length === N && hs.every(Number.isFinite)) { H.heights[id] = hs; ch = true; made++; } }));
    if (ch) fs.writeFileSync(hf, zlib.gzipSync(JSON.stringify(H), { level: 9 })); done++;
    if (done % 25 === 0) log('heights: ' + done + ' cells, ' + made + ' new profiles');
  }
  log('heights: ' + made + ' new profiles' + (all ? ', every stored road has one' : ', the next run carries on'));
  return all;
}
