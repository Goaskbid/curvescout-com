#!/usr/bin/env node
/* ---- EVERY RIDE ON ITS REAL ROAD, ROUTED ONCE (owner 2026-10-13: "no more crap vector rides") ----
 * Runs in a GitHub Codespace of the site repository (no Actions, no secrets, no schedule). It routes every ride in the
 * catalogue on its own OSRM router, region by region, and writes the roads into the site as small files the app reads
 * before it ever asks a public router:
 *     roads-index.json            which cells exist, how many roads each holds, when it was built
 *     roads-<cell>.json           { v:1, cell, roads: { <ride id>: [polyline5, km, min, nWaypoints] } }
 *     steps-<cell>.json           { v:1, cell, steps: { <ride id>: [[metres along, type, modifier, road, exit], ...] } }  every turn
 *     roads-progress.json         which regions are done, so a stopped run carries on where it left off
 * A cell is 3 x 3 degrees of the ride's start, so the atlas loads only the cells it is looking at and a ride page one.
 *
 *   node route-catalogue.mjs                       everything, region by region, commit + push after each region
 *   node route-catalogue.mjs --regions switzerland,austria     just these Geofabrik regions
 *   node route-catalogue.mjs --plan                show the regions and ride counts, change nothing
 *   node route-catalogue.mjs --no-push             write files, do not commit
 *   node route-catalogue.mjs --router http://127.0.0.1:5000   use a router that is already running (tests)
 *   node route-catalogue.mjs --max-pbf 1000        MB; a bigger region is split into its sub-regions (default 1000; 1500 on an 8-core codespace)
 *
 * Input: route-catalogue-input.json (every ride id with its checkpoints, shipped with this tool).
 * Region shapes: https://download.geofabrik.de/index-v1.json. Map data: Geofabrik extracts of OpenStreetMap (ODbL).
 * Router: OSRM v5.27.1 in Docker (car profile, MLD). Each region's files are deleted when the region is done.
 */
import fs from 'node:fs'; import path from 'node:path'; import zlib from 'node:zlib'; import crypto from 'node:crypto'; import { execFileSync, spawn } from 'node:child_process';

const A = process.argv.slice(2);
const opt = (n, d) => { const i = A.indexOf('--' + n); return i >= 0 ? (A[i + 1] && !A[i + 1].startsWith('--') ? A[i + 1] : true) : d; };
let OUT = path.resolve(opt('out', '.'));
const NET = process.argv.includes('--net');
let NETDIR;   /* audit r88 N2 (candidate): resolved after the input-selected output folder is applied */
const NETX = await import(new URL('./net-export.mjs', import.meta.url));
const INPUT = opt('input', fs.existsSync('route-catalogue-input.json') ? 'route-catalogue-input.json' : 'route-catalogue-input.json.gz');
/* r85 audit G2: a work folder and a router container of this run's own - cleanup only ever touches these */
/* r87 (audit G2): --work names a PARENT folder; this run always works in a new child of it that it creates and marks as its
   own. Cleanup only ever removes that marked child, never a folder it did not create, never through a symlink. */
const WORK_TOKEN = process.pid + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
const WORK = path.join(path.resolve(opt('work', process.env.RUNNER_TEMP || '/tmp')), 'cs-roads-' + WORK_TOKEN), CNAME = 'csosrm-' + process.pid;
function ownsWork() { try { const st = fs.lstatSync(WORK); if (st.isSymbolicLink() || !st.isDirectory()) return false; return fs.readFileSync(path.join(WORK, '.cs-roads-owner'), 'utf8') === WORK_TOKEN; } catch (e) { return false; } }
function wipeWork() { if (!fs.existsSync(WORK)) return; if (!ownsWork()) { log('work folder not owned by this run - left untouched:', WORK); return; } fs.rmSync(WORK, { recursive: true, force: true }); }   /* r88 (audit J1): was calling itself */
function freshWork() { wipeWork(); if (fs.existsSync(WORK)) throw Error('work folder exists and is not ours: ' + WORK); fs.mkdirSync(WORK, { recursive: true }); fs.writeFileSync(path.join(WORK, '.cs-roads-owner'), WORK_TOKEN); }
let GRAPH_REV = '', GRAPH_SRC = '', LEDGER = null;   /* r85: which map extract and box the current router was built from (stored with every road) */
const IMAGE = opt('image', 'ghcr.io/project-osrm/osrm-backend:v5.27.1');
const OSMIUM = opt('osmium-image', 'iboates/osmium:1.16.0');
const MAXPBF = +opt('max-pbf', 1000) * 1048576;   // 1000 MB suits a 4-core, 16 GB codespace; 1500 on 8-core, 32 GB
const ROUTER = opt('router', '');
const INDEX = opt('index', 'https://download.geofabrik.de/index-v1.json');
/* r85 audit G2: build-only by default - nothing is committed or pushed unless --publish is given (or the job's input asks
   for it explicitly, see PUBLISH below); --no-push always wins */
const PUSH = !!opt('publish', false) && !opt('no-push', false), PLAN = !!opt('plan', false);
const ONLY = String(opt('regions', '') || '').split(',').map(s => s.trim()).filter(Boolean);
const PAR = +opt('parallel', 8);
const LOGR = []; const log = (...a) => { const l = new Date().toISOString().slice(11, 19) + ' ' + a.join(' '); console.log(l); LOGR.push(l); if (LOGR.length > 300) LOGR.shift(); };
/* r54: each run stops itself in time (default 300 min), saves everything and leaves the rest to the next run */
const T0 = Date.now(), DEADLINE = T0 + +opt('minutes', 300) * 60000; let STOPPED = false;

/* ---- input ---- */
const readJson = f => { const b = fs.readFileSync(f); return JSON.parse((/\.gz$/.test(f) ? zlib.gunzipSync(b) : b).toString('utf8')); };
const INJ = readJson(INPUT); const rides = INJ.rides;
var NETCOVER = INJ.mode === 'net-cover' || !!INJ.netCover;   /* r88: see the network-coverage run below (alone, or first in a rides job) */            // [[id, [[lat,lon],...], km], ...]
/* r72 loop job (owner 2026-11-21: circular rides): the input may name its own output folder, kept apart from the live
   roads until a release adopts the results (relative to the repository), the router classes to avoid (ferry), and
   whether heights are skipped. A router that cannot exclude a class answers 400; that ride is then routed without it. */
if (INJ.out) { OUT = path.resolve(process.env.GITHUB_WORKSPACE || process.cwd(), INJ.out); if (!PLAN) fs.mkdirSync(OUT, { recursive: true }); }
NETDIR = path.resolve(opt('net', path.join(OUT, '..', 'net')));
/* exclude may name alternatives in order of preference, e.g. ["motorway", "ferry"]: the first answer that needs no ferry
   wins (owner: rides avoid motorways, and no ferry crossings), else the first answer at all, else the plain route */
const EXCLS = Array.isArray(INJ.exclude) ? INJ.exclude : (INJ.exclude ? [INJ.exclude] : []);
/* r85 audit G2: an explicit publish request in the reviewed job input; scoped to the output folder only (see commit) */
/* r87 (audit G2): a plain run never publishes, whatever its input says. Publishing needs --publish, or the input's request
   AND the repository's own road workflow as the runner (GitHub Actions, workflow "CurveScout road job"); --no-push always wins */
const PUBLISH = !PLAN && !opt('no-push', false) && (PUSH || (INJ.publish === true && process.env.GITHUB_ACTIONS === 'true' && /^CurveScout road job$/i.test(process.env.GITHUB_WORKFLOW || '')));
/* r76: motorways are left out of the router itself (a profile built on OSRM's car profile, motorways and their ramps not
   routable), so "no motorway" and "no ferry" hold together; the request then only excludes ferries */
const PROFILE = INJ.noMotorway ? '/data/cs-nomotorway.lua' : '/opt/car.lua';
function writeProfile() { if (!INJ.noMotorway) return; fs.writeFileSync(path.join(WORK, 'cs-nomotorway.lua'), PROFILE_TEXT); if (typeof SCENIC_TEXT !== 'undefined' && SCENIC_TEXT) fs.writeFileSync(path.join(WORK, 'cs-scenic.lua'), SCENIC_TEXT); }
/* r86 (owner 2026-11-23: "loop roads must still be maximum scenic and nice to ride"): with INJ.scenic the router prefers the
   smaller roads - trunk roads cost 1.7 times and primary roads 1.25 times their riding time when it picks the way (the
   riding time it reports stays the real one). Motorways stay unroutable. If this profile cannot be built, the plain
   motorway-free profile is used (a soft preference dropped, never a hard rule); the receipt says which one was used. */
let ACTIVE_TEXT = '';
function extractWith(d, input) {
  if (typeof SCENIC_TEXT !== 'undefined' && SCENIC_TEXT) { try { sh('docker', d.concat(['osrm-extract', '-p', '/data/cs-scenic.lua', input])); ACTIVE_TEXT = SCENIC_TEXT; return; } catch (e) { log('scenic preference profile failed, the plain motorway-free profile is used:', String(e && e.message || e).slice(0, 120)); } }
  sh('docker', d.concat(['osrm-extract', '-p', PROFILE, input])); ACTIVE_TEXT = PROFILE_TEXT; }
/* r87 (audit G1): motorways and their ramps are refused outright (the way is never processed, whatever speed or access tags
   it carries - removing the speeds alone was not a prohibition), and access is read for motorcycles first:
   motorcycle, then motor_vehicle, vehicle, access; turn restrictions likewise */
const PROFILE_TEXT = INJ.noMotorway ? "package.path = '/opt/?.lua;' .. package.path\nlocal Sequence = require('lib/sequence')\nlocal base = dofile('/opt/car.lua')\nlocal setup0 = base.setup\nbase.setup = function()\n  local p = setup0()\n  p.speeds.highway.motorway = nil\n  p.speeds.highway.motorway_link = nil\n  p.access_tags_hierarchy = Sequence { 'motorcycle', 'motor_vehicle', 'vehicle', 'access' }\n  p.restrictions = Sequence { 'motorcycle', 'motor_vehicle', 'vehicle' }\n  return p\nend\nlocal pw0 = base.process_way\nbase.process_way = function(profile, way, result, relations)\n  local h = way:get_value_by_key('highway')\n  if h == 'motorway' or h == 'motorway_link' then return end\n  pw0(profile, way, result, relations)\nend\nreturn base\n" : 'osrm-backend /opt/car.lua';
const SCENIC_TEXT = INJ.noMotorway && INJ.scenic ? PROFILE_TEXT.replace(/return base\n$/, "local pw = base.process_way\nbase.process_way = function(profile, way, result, relations)\n  pw(profile, way, result, relations)\n  local h = way:get_value_by_key('highway')\n  local f = 1\n  if h == 'trunk' or h == 'trunk_link' then f = 1 / 1.7 elseif h == 'primary' or h == 'primary_link' then f = 1 / 1.25 end\n  if f < 1 then\n    if result.forward_rate and result.forward_rate > 0 then result.forward_rate = result.forward_rate * f end\n    if result.backward_rate and result.backward_rate > 0 then result.backward_rate = result.backward_rate * f end\n  end\nend\nreturn base\n") : '';
const usesFerry = js => !!(js && js.routes && js.routes[0] && (js.routes[0].legs || []).some(l => (l.steps || []).some(st => st.mode === 'ferry')));
/* r85 audit G1: an exclusion is a hard rule. Only answers to a request that carried it count, and an answer that still uses
   a ferry is refused. If the router cannot apply the exclusion (400) the ride is REFUSED - never routed without it. */
async function preferred(base, coords) {
  let why = 'no answer';
  for (const ex of EXCLS) { const r = await fetch(base + '/route/v1/driving/' + coords + '?overview=full&geometries=polyline&steps=true&exclude=' + encodeURIComponent(ex));
    if (!r.ok) { why = r.status >= 500 ? 'http ' + r.status : 'exclusion ' + ex + ' not applied by the router (http ' + r.status + ')'; continue; }
    const js = await r.json(); if (!js.routes || !js.routes[0]) { why = (js && js.code) || 'no route'; continue; }
    if (usesFerry(js)) { why = 'only a route with a ferry'; continue; }
    return { ok: true, status: 200, json: async () => js }; }
  return { ok: false, status: /^http 5/.test(why) ? +why.slice(5) : 422, why };
}
/* r59 retry pass (input field mode:"retry-missing"): only the rides that still have no stored road. The first pass is
   skipped, their earlier second-pass refusals are cleared, boxes are smaller, a start or finish up to 15 km from the
   nearest road is accepted, and a checkpoint OSRM cannot place on any road is left out of the routing (the stop stays
   in the ride; the page says how far the road passes from it). Lengths are compared with the CURRENT ride length. */
const RETRY = INJ.mode === 'retry-missing' || !!opt('retry-missing', false);
log('rides in the catalogue:', rides.length);

/* ---- NEW ROUTES (owner 2026-10-13: "ingest new routes") ----
   catalogue-queue.json holds the accepted concepts that were never routed: a title, a road and the places it passes. With
   --queue the job finds those places (Nominatim, one request a second, cached in roads-ingest-geocode.json), routes them
   on the same regional routers and writes new-rides.json - measured distance and time, the real road, the named places.
   They go live after review in the next release; nothing is published straight from a machine. */
const QUEUE = opt('queue', fs.existsSync('catalogue-queue.json') ? 'catalogue-queue.json' : '');
const NEW = new Map();   // id -> metadata for queued concepts
const newFile = path.join(OUT, 'new-rides.json');
const newOut = (() => { try { return JSON.parse(fs.readFileSync(newFile, 'utf8')); } catch (e) { return { v: 1, rides: {}, refused: {} }; } })();
/* ---- polyline (precision 5), Douglas-Peucker ---- */
function encode(pts) { let out = '', pl = 0, pn = 0; const e = v => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const [la, lo] of pts) { const a = Math.round(la * 1e5), b = Math.round(lo * 1e5); out += e(a - pl) + e(b - pn); pl = a; pn = b; } return out; }
function decode(s) { const out = []; let i = 0, la = 0, lo = 0; while (i < s.length) { for (const k of [0, 1]) { let r = 0, sh = 0, b; do { b = s.charCodeAt(i++) - 63; r |= (b & 0x1f) << sh; sh += 5; } while (b >= 0x20); const d = r & 1 ? ~(r >> 1) : r >> 1; if (k) lo += d; else la += d; } out.push([la / 1e5, lo / 1e5]); } return out; }
function simplify(pts, tolM) {
  if (pts.length < 3) return pts; const k = 111320, cos = Math.cos(pts[0][0] * Math.PI / 180);
  const P = pts.map(p => [p[1] * k * cos, p[0] * k]); const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1; const st = [[0, pts.length - 1]];
  while (st.length) { const [a, b] = st.pop(); let dm = 0, im = -1; const [x1, y1] = P[a], [x2, y2] = P[b], dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
    for (let i = a + 1; i < b; i++) { const [x, y] = P[i]; let t = l2 ? ((x - x1) * dx + (y - y1) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t)); const d = Math.hypot(x - x1 - t * dx, y - y1 - t * dy); if (d > dm) { dm = d; im = i; } }
    if (dm > tolM) { keep[im] = 1; st.push([a, im], [im, b]); } }
  return pts.filter((_, i) => keep[i]);
}
const cellOf = (la, lo) => (Math.floor(la / 3) + 30) + '-' + (Math.floor(lo / 3) + 60);
const hav = (a, b) => { const R = 6371, t = Math.PI / 180, dLa = (b[0] - a[0]) * t, dLo = (b[1] - a[1]) * t; const h = Math.sin(dLa / 2) ** 2 + Math.cos(a[0] * t) * Math.cos(b[0] * t) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };

/* ---- the site files: read what is there, add, write ---- */
const cells = new Map();
const cellFile = c => path.join(OUT, 'roads-' + c + '.json');
const stepsC = new Map(), stepsFile = c => path.join(OUT, 'steps-' + c + '.json');
/* r46 (GitHub 1 GB rule): cells are stored gzip-compressed (*.json.gz); a leftover plain file is merged in and removed on write */
function readCell(f, key) { let j = null; try { j = JSON.parse(zlib.gunzipSync(fs.readFileSync(f + '.gz')).toString('utf8')); } catch (e) {} let p = null; try { p = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) {} if (j && p) { j[key] = Object.assign({}, j[key], p[key]); return j; } return j || p; }
function writeCell(f, j) { fs.writeFileSync(f + '.gz', zlib.gzipSync(JSON.stringify(j), { level: 9 })); try { fs.rmSync(f); } catch (e) {} }
function stepsGet(c) { if (!stepsC.has(c)) { stepsC.set(c, readCell(stepsFile(c), 'steps') || { v: 1, cell: c, steps: {} }); } return stepsC.get(c); }
function cellGet(c) { if (!cells.has(c)) { cells.set(c, readCell(cellFile(c), 'roads') || { v: 1, cell: c, roads: {} }); } return cells.get(c); }
const progFile = path.join(OUT, 'roads-progress.json');
/* r54: the site keeps roads-progress.json and roads-index.json gzip-compressed (*.json.gz) - read and write those */
const prog = (() => { let a = null, b = null; try { a = JSON.parse(fs.readFileSync(progFile, 'utf8')); } catch (e) {} try { b = JSON.parse(zlib.gunzipSync(fs.readFileSync(progFile + '.gz')).toString('utf8')); } catch (e) {}
  const j = b || a || { v: 1, done: {}, failed: {}, tooBig: [] }; if (a && b) for (const k of ['done', 'done2', 'failed', 'sizes', 'netDone', 'tries']) if (a[k]) j[k] = Object.assign({}, b[k], a[k]); if (a && b) j.tooBig = [...new Set((b.tooBig || []).concat(a.tooBig || []))]; return j; })();
function flush() {
  for (const [c, j] of cells) writeCell(cellFile(c), j);
  for (const [c, j] of stepsC) writeCell(stepsFile(c), j);
  const idx = { v: 1, built: new Date().toISOString(), cells: {} };
  for (const f of fs.readdirSync(OUT)) { const m = f.match(/^roads-(\d+-\d+)\.json(\.gz)?$/); if (!m || m[1] in idx.cells) continue; const j = cells.get(m[1]) || readCell(cellFile(m[1]), 'roads'); if (j) idx.cells[m[1]] = Object.keys(j.roads || {}).length; }
  idx.total = Object.values(idx.cells).reduce((a, b) => a + b, 0);
  writeCell(path.join(OUT, 'roads-index.json'), idx);
  writeCell(progFile, prog);
  /* r85 audit G1: the result ledger - every input ride is accepted, refused, retryable or unprocessed, and they add up */
  if (typeof rideById !== 'undefined') { const RETRYABLE = /^(retryable|http 5|region too slow|box build failed|map download refused|too slow|too large|Command failed)/;
    const L = { contract: CONTRACT, built: new Date().toISOString(), input: rides.length, accepted: [], refused: {}, retryable: {}, unprocessed: [] };
    for (const r of rides) { const k = RK(r), why = (prog.clipFail || {})[k] || (prog.refused || {})[k];
      if ((prog.ok || {})[k]) L.accepted.push(r[0]); else if (why && RETRYABLE.test(why)) L.retryable[r[0]] = why; else if (why && ((prog.done3 || {})[k] || (prog.done2 || {})[k])) L.refused[r[0]] = why; else L.unprocessed.push(r[0]); }
    L.counts = { accepted: L.accepted.length, refused: Object.keys(L.refused).length, retryable: Object.keys(L.retryable).length, unprocessed: L.unprocessed.length };
    if (INJ.canary) L.canary = Object.fromEntries(INJ.canary.map(id => [id, L.accepted.includes(id) ? 'accepted' : L.refused[id] ? 'refused: ' + L.refused[id] : L.retryable[id] ? 'retryable: ' + L.retryable[id] : 'unprocessed']));
    L.counts.sum = L.counts.accepted + L.counts.refused + L.counts.retryable + L.counts.unprocessed; LEDGER = L.counts;
    if (prog.cov) L.coverage = { summary: prog.cov.summary || null, qualified: prog.cov.qualified, refused: prog.cov.refused, regions: prog.cov.regions, orphansRemoved: (prog.cov.orphansRemoved || []).length };   /* r89: coverage accepted / refused / incomplete, region by region */
    writeCell(path.join(OUT, 'roads-ledger.json'), L); }
  try { fs.writeFileSync(path.join(OUT, 'roads-run.txt'), LOGR.join('\n') + '\n'); } catch (e) {}
  if (NEW.size || Object.keys(newOut.rides).length) fs.writeFileSync(newFile, JSON.stringify(newOut, null, 1));
  return idx;
}

/* ---- regions: smallest Geofabrik region that contains every checkpoint of a ride ---- */
function pip(pt, ring) { let inside = false; const [y, x] = pt; for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) { const [xi, yi] = ring[i], [xj, yj] = ring[j]; if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside; } return inside; }
function inGeom(pt, g) { const polys = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : []; return polys.some(p => pip(pt, p[0]) && !p.slice(1).some(h => pip(pt, h))); }
async function regions() {
  let j; if (/^https?:/.test(INDEX)) { log('reading the Geofabrik region index'); const r = await fetch(INDEX); if (!r.ok) throw new Error('index ' + r.status); j = await r.json(); } else j = JSON.parse(fs.readFileSync(INDEX, 'utf8'));
  return j.features.filter(f => f.geometry && f.properties && f.properties.urls && f.properties.urls.pbf).map(f => {
    let b = [180, 90, -180, -90]; const polys = f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates;
    for (const p of polys) for (const [x, y] of p[0]) { b = [Math.min(b[0], x), Math.min(b[1], y), Math.max(b[2], x), Math.max(b[3], y)]; }
    return { id: f.properties.id, parent: f.properties.parent || '', name: f.properties.name, pbf: f.properties.urls.pbf, geom: f.geometry, bbox: b, area: (b[2] - b[0]) * (b[3] - b[1]) };
  });
}
/* each checkpoint belongs to the smallest region around it; a ride whose checkpoints all share one region is routed
   there, a ride that crosses a border is routed on the merged extracts of the regions it touches (osmium merge) */
/* fewer, larger router builds: a ride goes to the LARGEST region that holds all its checkpoints and whose extract is
   small enough for this machine (--max-pbf); sizes come from one HEAD request per region, kept in roads-progress.json.
   Without sizes (offline, tests) each checkpoint takes its smallest region and border crossings merge those. */
async function sizeOf(g) {
  prog.sizes = prog.sizes || {};
  if (g.id in prog.sizes) return prog.sizes[g.id];
  if (opt('assume-pbf-mb', '')) return +opt('assume-pbf-mb', '') * 1048576;   /* tests only: no download server */
  let n = 0; try { const r = await fetch(g.pbf, { method: 'HEAD' }); n = +(r.ok && r.headers.get('content-length')) || 0; } catch (e) { n = 0; }
  if (n) prog.sizes[g.id] = n; return n;   /* a failed HEAD is asked again next run */
}
async function assign(regs, list) {
  const by = new Map(), none = [];
  const sorted = regs.slice().sort((a, b) => a.area - b.area), big = sorted.slice().reverse();
  const inBox = (p, g) => p[1] >= g.bbox[0] && p[1] <= g.bbox[2] && p[0] >= g.bbox[1] && p[0] <= g.bbox[3];
  const leaf = p => sorted.find(g => inBox(p, g) && inGeom(p, g.geom) && !(prog.tooBig || []).includes(g.id));
  const add = (key, set, r) => { if (!by.has(key)) by.set(key, { key, regs: set, rides: [] }); by.get(key).rides.push(r); };
  const decided = new Map();   // region id -> fits (true/false)
  for (const r of list) { const [id, wps] = r; if (!wps || wps.length < 2) { none.push(id); continue; }
    const pts = wps.map(p => [p[0], p[1]]);
    let pick = null;
    for (const g of big) { if ((prog.tooBig || []).includes(g.id) || !pts.every(p => inBox(p, g))) continue; if (!pts.every(p => inGeom(p, g.geom))) continue;
      if (!decided.has(g.id)) { const n = await sizeOf(g); decided.set(g.id, n > 0 && n <= MAXPBF); }
      if (decided.get(g.id)) { pick = g; break; } }
    if (pick) { add(pick.id, [pick], r); continue; }
    const set = []; let miss = false; for (const p of pts) { const g = leaf(p); if (!g) { miss = true; break; } if (!set.includes(g)) set.push(g); }
    if (miss || set.length > 3) { none.push(id); continue; }
    set.sort((a, b) => a.id.localeCompare(b.id)); add(set.map(g => g.id).join('+'), set, r); }
  return { by, none };
}
/* ---- the router ---- */
const sh = (cmd, args, o = {}) => execFileSync(cmd, args, Object.assign({ stdio: 'inherit' }, o));
/* border crossings need two extracts merged: osmium from the Codespace's package manager, else from Docker */
function osmiumMerge(files, out) {
  const have = () => { try { execFileSync('osmium', ['--version'], { stdio: 'ignore' }); return true; } catch (e) { return false; } };
  /* r85 audit G2: the job never installs packages itself - osmium comes from the workflow, else from Docker */
  if (have()) return sh('osmium', ['merge', '--overwrite'].concat(files).concat(['-o', out]));
  return sh('docker', ['run', '--rm', '-v', WORK + ':/data', OSMIUM, 'merge', '--overwrite'].concat(files.map(f => '/data/' + path.basename(f))).concat(['-o', '/data/' + path.basename(out)]));
}
async function startRouter(group) {
  freshWork();
  let total = 0; const sizes = [];
  for (const reg of group.regs) { const head = await fetch(reg.pbf, { method: 'HEAD' }).catch(() => null); const size = head && +head.headers.get('content-length'); sizes.push(size || 0); total += size || 0;
    if (size && size > MAXPBF) return { tooBig: size, reg }; }
  if (total > MAXPBF * 1.3) return { tooLarge: total };
  const files = [];
  for (const [k, reg] of group.regs.entries()) { log('downloading', reg.id, sizes[k] ? Math.round(sizes[k] / 1048576) + ' MB' : ''); const f = path.join(WORK, 'p' + k + '.osm.pbf'); sh('curl', ['-fL', '--retry', '3', '-o', f, reg.pbf]); files.push(f); }
  GRAPH_REV = group.key + '@' + new Date().toISOString().slice(0, 10) + ':' + files.reduce((a, f) => a + fs.statSync(f).size, 0);
  if (files.length === 1) fs.renameSync(files[0], path.join(WORK, 'r.osm.pbf'));
  else { log('merging', group.key); osmiumMerge(files, path.join(WORK, 'r.osm.pbf')); files.forEach(f => fs.rmSync(f, { force: true })); }
  const d = ['run', '--rm', '-v', WORK + ':/data', IMAGE];
  /* r42: the road network for routing on the rider's phone (backup when OSRM is unavailable), from the same extract */
  if (NET) { try { log('road network for the phone');
    const dm = ['run', '--rm', '-v', WORK + ':/data', OSMIUM];
    sh('docker', dm.concat(['tags-filter', '--overwrite', '/data/r.osm.pbf', 'w/highway=' + NETX.CLASSES.join(','), '-o', '/data/hw.osm.pbf']));
    sh('docker', dm.concat(['export', '--overwrite', '/data/hw.osm.pbf', '-f', 'geojsonseq', '--geometry-types=linestring', '-o', '/data/hw.geojsonseq']));
    await NETX.exportNet(path.join(WORK, 'hw.geojsonseq'), NETDIR, log);
    for (const f of ['hw.osm.pbf', 'hw.geojsonseq']) fs.rmSync(path.join(WORK, f), { force: true }); } catch (e) { log('road network skipped:', String(e && e.message || e).slice(0, 200)); } }
  log('osrm-extract'); writeProfile(); extractWith(d, '/data/r.osm.pbf');   /* r85 audit G1: a failed motorway-free build stops here - never rebuilt on the ordinary car profile */
  fs.rmSync(path.join(WORK, 'r.osm.pbf'), { force: true });
  log('osrm-partition'); sh('docker', d.concat(['osrm-partition', '/data/r.osrm']));
  log('osrm-customize'); sh('docker', d.concat(['osrm-customize', '/data/r.osrm']));
  try { execFileSync('docker', ['rm', '-f', CNAME], { stdio: 'ignore' }); } catch (e) {}
  sh('docker', ['run', '-d', '--name', CNAME, '-p', '127.0.0.1:5000:5000', '-v', WORK + ':/data', IMAGE, 'osrm-routed', '--algorithm', 'mld', '--max-viaroute-size', '1000', '/data/r.osrm']);
  for (let k = 0; k < 120; k++) { try { const r = await fetch('http://127.0.0.1:5000/route/v1/driving/0,0;0.001,0.001'); if (r.status) break; } catch (e) {} await new Promise(r => setTimeout(r, 1000)); }
  return { url: 'http://127.0.0.1:5000' };
}
function stopRouter() { try { execFileSync('docker', ['rm', '-f', CNAME], { stdio: 'ignore' }); } catch (e) {} wipeWork(); }

/* r85 audit G1 - admission: a road is stored only when the FULL routed path visits every required stop, in order, close by
   (SNAP), starts and ends at the ride's ends, has a complete turn list (one leg per stop-to-stop, each ending in an arrival),
   finite positive distance and time, respects the exclusions, and carries its identity: request (ordered stops +
   constraints + profile + engine), full and published geometry, turn list, visit chainage, graph revision. */
const SNAP = +(INJ.snapM || 900), CONTRACT = 'curvescout-loop-admission-2';   /* r87: -2 = instructions checked, motorways refused in the profile */
const H = v => crypto.createHash('sha256').update(typeof v === 'string' ? v : JSON.stringify(v)).digest('hex').slice(0, 32);
/* r87 (audit G1): the request = ordered stops, hard exclusions, the REQUESTED scenic preference, the hard profile and the
   engine; reqHash also binds the graph the road is built on (once a graph is loaded). Progress (RK) is keyed by the request
   without the graph - the map extracts change daily, so binding progress to them would restart the job every day; each
   stored road instead carries the graph it was built on in its receipt, and adoption checks road and receipt together. */
const reqOf = wps => ({ c: CONTRACT, wps: wps.map(p => [+(+p[0]).toFixed(5), +(+p[1]).toFixed(5)]), exclude: EXCLS.slice(), noMotorway: !!INJ.noMotorway, scenic: !!INJ.scenic, profile: H(PROFILE_TEXT), engine: IMAGE });
const rqHash = wps => H(reqOf(wps));
const reqHash = wps => H(Object.assign(reqOf(wps), { graph: (typeof GRAPH_REV !== 'undefined' && GRAPH_REV) || '' }));
const RK = r => r[0] + '#' + rqHash(r[1]);
function segDist(p, a, b) { const k = 111.32, c = Math.cos(p[0] * Math.PI / 180), ax = (a[1] - p[1]) * k * c, ay = (a[0] - p[0]) * k, bx = (b[1] - p[1]) * k * c, by = (b[0] - p[0]) * k;
  const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy; let t = l2 ? -(ax * dx + ay * dy) / l2 : 0; t = Math.max(0, Math.min(1, t)); return { d: Math.hypot(ax + t * dx, ay + t * dy), t }; }
function visitChain(line, wps) {   /* chainage (m) of each required stop on the full path, strictly in order; null if one is missed */
  const cum = [0]; for (let i = 1; i < line.length; i++) cum.push(cum[i - 1] + hav(line[i - 1], line[i]) * 1000);
  const out = [0]; let from = 0, prev = 0;
  for (let k = 1; k < wps.length - 1; k++) { let hit = -1, best = null, bestAt = 0;
    for (let i = from; i < line.length - 1; i++) { const sd = segDist(wps[k], line[i], line[i + 1]), along = cum[i] + (cum[i + 1] - cum[i]) * sd.t;
      if (sd.d * 1000 <= SNAP && along >= prev) { if (!best || sd.d < best.d) { best = sd; hit = i; bestAt = along; } } else if (best) break; }
    if (hit < 0) return null; out.push(bestAt); from = hit; prev = bestAt; }
  out.push(cum[cum.length - 1]); return out; }
function admit(js, wps) {
  const rt = js && js.routes && js.routes[0]; if (!rt || !rt.geometry) return { err: (js && js.code) || 'no route' };
  if (usesFerry(js) && EXCLS.includes('ferry')) return { err: 'uses a ferry despite the exclusion' };
  if (!Number.isFinite(rt.distance) || rt.distance <= 0) return { err: 'distance missing' };
  if (!Number.isFinite(rt.duration) || rt.duration <= 0) return { err: 'duration missing (unknown is not zero)' };
  const line = decode(rt.geometry); if (line.length < 2) return { err: 'empty' };
  if (hav(line[0], wps[0]) * 1000 > SNAP || hav(line[line.length - 1], wps[wps.length - 1]) * 1000 > SNAP) return { err: 'ends do not match the ride (more than ' + SNAP + ' m)' };
  if (Array.isArray(js.waypoints) && (js.waypoints.length !== wps.length || js.waypoints.some(w => !(+w.distance <= SNAP)))) return { err: 'a required stop could not be placed on a road within ' + SNAP + ' m' };
  const legs = rt.legs || []; if (legs.length !== wps.length - 1) return { err: 'turn list incomplete (' + legs.length + ' legs for ' + (wps.length - 1) + ' stretches)' };
  for (const [li, lg] of legs.entries()) { const ss = lg.steps || []; if (ss.length < 2) return { err: 'turn list incomplete on stretch ' + (li + 1) };
    if ((ss[0].maneuver || {}).type !== 'depart' || (ss[ss.length - 1].maneuver || {}).type !== 'arrive') return { err: 'stretch ' + (li + 1) + ' does not end in an arrival' };
    if (!Number.isFinite(lg.distance) || !Number.isFinite(lg.duration)) return { err: 'stretch ' + (li + 1) + ' has no distance or time' }; }
  const sum = legs.reduce((a, l) => a + l.distance, 0); if (Math.abs(sum - rt.distance) > Math.max(50, rt.distance * 0.02)) return { err: 'stretch lengths do not add up' };
  const len = line.reduce((a, p, i) => i ? a + hav(line[i - 1], p) * 1000 : 0, 0); if (Math.abs(len - rt.distance) > Math.max(500, rt.distance * 0.5)) return { err: 'path and stated distance disagree' };
  const chain = visitChain(line, wps); if (!chain) return { err: 'path misses a required stop or visits them out of order' };
  return { rt, line, chain }; }
function checkSteps(rt, line, T, chain) {
  const legs = rt.legs || [];
  if (!Array.isArray(chain) || chain.length !== legs.length + 1) return 'instruction chainage unavailable';
  const cum = [0];
  for (let i = 1; i < line.length; i++) cum.push(cum[i - 1] + hav(line[i - 1], line[i]) * 1000);
  let total = 0, duration = 0;
  for (const [li, lg] of legs.entries()) {
    const from = chain[li], to = chain[li + 1], span = to - from;
    if (!Number.isFinite(from) || !Number.isFinite(to) || span < 0 || !Number.isFinite(lg.distance) || lg.distance <= 0 || !Number.isFinite(lg.duration) || lg.duration < 0) return 'invalid stretch facts';
    let sum = 0, seconds = 0, previousAt = from;
    const tolerance = Math.max(30, Math.min(250, span * 0.02));
    const ss = lg.steps || [];
    for (const [si, st] of ss.entries()) {
      const m = st && st.maneuver;
      if (!m || typeof m !== 'object' || T[m.type] == null) return 'unknown or absent manoeuvre on stretch ' + (li + 1);
      if (!Number.isFinite(st.distance) || st.distance < 0 || !Number.isFinite(st.duration) || st.duration < 0) return 'invalid instruction distance or time';
      const loc = m.location;
      if (!Array.isArray(loc) || loc.length !== 2 || !loc.every(Number.isFinite) || Math.abs(loc[1]) > 90 || Math.abs(loc[0]) > 180) return 'invalid instruction coordinate';
      if ((si === 0 && m.type !== 'depart') || (si > 0 && m.type === 'depart') || (si === ss.length - 1 && m.type !== 'arrive') || (si < ss.length - 1 && m.type === 'arrive')) return 'invalid instruction boundary';
      // A coordinate may occur several times on a loop. Select its occurrence in this
      // leg, near this instruction's cumulative distance, not the closest point globally.
      const expected = from + span * Math.min(1, sum / lg.distance);
      let best = null;
      for (let i = 0; i < line.length - 1; i++) {
        if (cum[i + 1] < from - tolerance || cum[i] > to + tolerance) continue;
        const pr = segDist([loc[1], loc[0]], line[i], line[i + 1]);
        const at = cum[i] + (cum[i + 1] - cum[i]) * pr.t;
        if (pr.d * 1000 > 250 || at < from - tolerance || at > to + tolerance || at < previousAt - 5 || Math.abs(at - expected) > tolerance) continue;
        const score = Math.abs(at - expected) + pr.d * 1000;
        if (!best || score < best.score) best = { at, score };
      }
      if (!best) return 'instruction ' + (si + 1) + ' is not at its ordered position in stretch ' + (li + 1);
      previousAt = Math.max(previousAt, best.at);
      sum += st.distance; seconds += st.duration;
    }
    if (Math.abs(sum - lg.distance) > Math.max(30, lg.distance * 0.02)) return 'instruction distances do not match stretch';
    if (Math.abs(seconds - lg.duration) > Math.max(2, lg.duration * 0.02)) return 'instruction times do not match stretch';
    total += sum; duration += seconds;
  }
  if (!(total > 0) || Math.abs(total - rt.distance) > Math.max(50, rt.distance * 0.02)) return 'instruction distances do not match ride';
  if (Math.abs(duration - rt.duration) > Math.max(2, rt.duration * 0.02)) return 'instruction times do not match ride';
  return null;
}
async function routeOne(base, ride) {
  const [id, wps, km] = ride; const coords = wps.map(p => (+p[1]).toFixed(5) + ',' + (+p[0]).toFixed(5)).join(';');
  let r;
  if (EXCLS.length) { r = await preferred(base, coords); if (!r.ok) return { id, err: r.why || 'http ' + r.status }; }
  else { r = await fetch(base + '/route/v1/driving/' + coords + '?overview=full&geometries=polyline&steps=true');
    if (!r.ok) { let msg = ''; try { msg = (await r.json()).message || ''; } catch (e) {} const m = msg.match(/coordinate (\d+)/);
      /* r85 audit G1: a stop the router cannot place is never dropped - the ride is refused and keeps its stops */
      return { id, err: m ? 'required stop ' + m[1] + ' is not on a routable road' : 'http ' + r.status }; } }
  const js = await r.json(); const a = admit(js, wps); if (a.err) return { id, err: a.err };
  const { rt, line, chain } = a; const rkm = rt.distance / 1000;
  /* a road that is far longer or shorter than the ride says is not this ride: kept out, listed */
  const nw = NEW.get(id);
  if (nw && nw.tk && (rkm < nw.tk[0] * 0.6 || rkm > nw.tk[1] * 1.6)) return { id, err: 'length ' + Math.round(rkm) + ' km outside ' + nw.tk.join('-') + ' km' };
  if (!nw && km && (rkm > km * 2.3 + 20 || rkm < km * 0.45)) return { id, err: 'length ' + Math.round(rkm) + ' km vs ' + km + ' km' };
  const s = simplify(line, 12);
  /* r36+ (owner 2026-11-07: "full functionality, no sign-up, no legal risk"): every turn of the ride, from this own router,
     so the navigator guides turn by turn on the ride from the site's files - [metres along, type, modifier, road, exit];
     metres are measured on the FULL path (the same one the stops were checked on), not on the simplified display line */
  const T = { depart: 0, turn: 1, 'new name': 2, continue: 3, merge: 4, 'on ramp': 5, 'off ramp': 6, fork: 7, 'end of road': 8, roundabout: 9, rotary: 9, 'roundabout turn': 9, 'exit roundabout': 10, 'exit rotary': 10, arrive: 11, notification: 12 };
  const MOD = { uturn: 0, 'sharp right': 1, right: 2, 'slight right': 3, straight: 4, 'slight left': 5, left: 6, 'sharp left': 7 };
  /* r87 (audit G1): every instruction is checked before anything is stored - a known manoeuvre type, a real position on this
     road (within 250 m of the full path, never [0,0]), a finite non-negative distance, positions that only move forward,
     and the instruction distances adding up to their stretch and to the whole ride (a missing, zero or negative step is a
     refusal, never a silently dropped turn) */
  { const sErr = checkSteps(rt, line, T, chain); if (sErr) return { id, err: sErr }; }
  const steps = []; let at = 0; const legs = rt.legs;
  legs.forEach((leg, li) => (leg.steps || []).forEach(st => { const m = st.maneuver || {}, t = T[m.type]; if (t == null) { at += +st.distance || 0; return; }
    if ((t === 0 && li > 0) || (t === 11 && li < legs.length - 1)) { if (t === 11) steps.push([Math.round(at), 13, MOD[m.modifier] ?? 4, '', 0, li]); at += +st.distance || 0; return; }
    if (t === 2 && !(st.name || st.ref)) { at += +st.distance || 0; return; }
    steps.push([Math.round(at), t, MOD[m.modifier] ?? 4, String(st.ref && !st.name ? st.ref : st.name || '').slice(0, 60), +m.exit || 0]); at += +st.distance || 0; }));
  if (!steps.length || steps[steps.length - 1][1] !== 11) return { id, err: 'turn list does not end in an arrival' };
  const pub = encode(s), mins = Math.round(rt.duration / 60);
  const identity = { contract: CONTRACT, req: reqHash(wps), rq: rqHash(wps), scenicRequested: !!INJ.scenic, profileHash: H((typeof ACTIVE_TEXT !== 'undefined' && ACTIVE_TEXT) || PROFILE_TEXT), scenicPreference: !!(typeof ACTIVE_TEXT !== 'undefined' && ACTIVE_TEXT && ACTIVE_TEXT !== PROFILE_TEXT), engine: IMAGE, graphRevision: (typeof GRAPH_REV !== 'undefined' && GRAPH_REV) || ('router ' + base),
    wps: reqOf(wps).wps, exclude: EXCLS.slice(), noMotorway: !!INJ.noMotorway, snapM: SNAP, geometryHash: H(rt.geometry), publishedHash: H(pub), stepsHash: H(steps), orderedVisitsHash: H(reqOf(wps).wps), visitsAt: chain.map(Math.round), legs: legs.map(l => Math.round(l.distance)),
    km: +rkm.toFixed(2), minutes: mins, at: new Date().toISOString() };
  return { id, cell: cellOf(wps[0][0], wps[0][1]), v: [pub, Math.round(rkm), mins, wps.length, identity], steps, identity };
}
async function routeAll(base, list, regId) {
  let ok = 0, bad = 0, n = 0; const fails = [], retry = new Set();
  const q = list.slice(), tried = new Set(); const work = async () => { for (;;) { if (Date.now() > DEADLINE) { STOPPED = true; return; } const r = q.shift(); if (!r) return; n++; tried.add(r[0]);
    try { const x = await routeOne(base, r); if (x.err) { bad++; fails.push(x.id + ': ' + x.err); { const rr = rideById.get(x.id); if (rr) { prog.refused = prog.refused || {}; prog.refused[RK(rr)] = x.err; } } if (NEW.has(x.id) && !/^http 5/.test(x.err)) newOut.refused[x.id.slice(4)] = x.err; if (/^http 5/.test(x.err)) retry.add(x.id); } else if (NEW.has(x.id)) { const nw = NEW.get(x.id), c = nw.c; newOut.rides[c.id] = { id: c.id, title: c.title, road: c.road || '', cc: c.cc || '', region: c.region || '', kind: c.kind || '', tags: c.tags || '', sources: c.sources || '', wps: nw.wps, poly: x.v[0], km: x.v[1], min: x.v[2], routed: new Date().toISOString().slice(0, 10) }; ok++; }
      else { cellGet(x.cell).roads[x.id] = x.v; stepsGet(x.cell).steps[x.id] = x.steps || []; ok++; const rr = rideById.get(x.id); if (rr) { prog.ok = prog.ok || {}; prog.ok[RK(rr)] = x.identity.req; if (prog.refused) delete prog.refused[RK(rr)]; } } } catch (e) { bad++; fails.push(r[0] + ': ' + e.message); retry.add(r[0]); prog.refused = prog.refused || {}; prog.refused[RK(r)] = 'retryable: ' + String(e.message).slice(0, 80); }
    if (n % 200 === 0) log(regId, n + '/' + list.length, 'routed', ok, 'refused', bad); } };
  await Promise.all(Array.from({ length: PAR }, work));
  return { ok, bad, fails, retry, tried };
}
let LASTPUSH = 0;
/* r55: always push to main by name - a run started by a release is checked out on the tag (no branch), where a plain push fails */
const BR = opt('branch', 'main');
function pushMain() { try { sh('git', ['-C', OUT, 'pull', '-q', '--rebase', 'origin', BR]); } catch (e) {} sh('git', ['-C', OUT, 'push', '-q', 'origin', 'HEAD:refs/heads/' + BR]); }
function commit(msg, force) {
  if (!PUBLISH) return;
  try { /* r55: one pathspec for the whole roads folder - a glob that matches no file made 'git add' fail and nothing was pushed */ sh('git', ['-C', OUT, 'add', '-A', '--', '.']); if ((NET || NETCOVER) && fs.existsSync(NETDIR)) sh('git', ['-C', NETDIR, 'add', '-A', '--', '.']); for (const f of ['new-rides.json', 'roads-ingest-geocode.json']) if (fs.existsSync(path.join(OUT, f))) sh('git', ['-C', OUT, 'add', '--', f]);
    /* r85 audit G2: publication is scoped - if anything outside this job's output folder is staged, nothing is committed */
    const top = execFileSync('git', ['-C', OUT, 'rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim(), relOf = d => path.relative(top, d).replace(/\\/g, '/') + '/';
    const rel = relOf(OUT), relN = (NET || NETCOVER) && NETDIR ? relOf(NETDIR) : null;
    const staged = execFileSync('git', ['-C', OUT, 'diff', '--cached', '--name-only'], { encoding: 'utf8' }).split('\n').filter(Boolean);
    if (rel === '/' || rel.startsWith('../') || staged.some(f => !f.startsWith(rel) && !(relN && f.startsWith(relN)))) { log('publish refused: changes outside ' + rel + ' are staged'); return; }
    const st = execFileSync('git', ['-C', OUT, 'status', '--porcelain', '--', '.'], { encoding: 'utf8' }); if (!st.trim()) { if (force) { try { pushMain(); } catch (e) {} } return; }
    /* r53: GitHub history - one commit per push, at most every 2 hours (files are written in between, nothing is lost) */
    if (!force && Date.now() - LASTPUSH < 120 * 60000) { log('saved on disk - committed and pushed with the next 2-hourly push'); return; }
    sh('git', ['-C', OUT, 'commit', '-q', '-m', msg]);
    /* the owner may have uploaded a release in the meantime: take it first, then push (roads files never clash with it) */
    /* r46 GitHub rule: every push rebuilds the Pages site - push at most every 30 minutes (and at the end), commits are kept locally in between */
    pushMain(); LASTPUSH = Date.now(); } catch (e) { log('commit/push failed - the files are written; push again later with: git push'); }
}

/* ---- run ---- */
if (QUEUE && !PLAN && !opt('no-ingest', false)) {
  const q = readJson(QUEUE); const core = (q.core || []).filter(c => c && c.id && c.waypoint_names);
  const gfile = path.join(OUT, 'roads-ingest-geocode.json'); const G = (() => { try { return JSON.parse(fs.readFileSync(gfile, 'utf8')); } catch (e) { return {}; } })();
  const GEO = opt('geocoder', 'https://nominatim.openstreetmap.org');
  let asked = 0;
  for (const c of core) {
    if (newOut.rides[c.id] || newOut.refused[c.id]) continue;
    const names = String(c.waypoint_names).split(';').map(x => x.trim()).filter(Boolean); const pts = [];
    for (const n of names) {
      const k = (c.cc || '') + '|' + n;
      if (!(k in G)) {
        if (/^https?:/.test(GEO)) { await new Promise(r => setTimeout(r, 1100)); asked++; }
        try { const u = GEO + '/search?format=json&limit=1&q=' + encodeURIComponent(n + (c.region ? ', ' + String(c.region).split(' - ').pop() : '')) + (c.cc ? '&countrycodes=' + String(c.cc).toLowerCase() : '');
          const r = await fetch(u, { headers: { 'User-Agent': 'CurveScout route catalogue (https://curvescout.com)', Accept: 'application/json' } }); const j = r.ok ? await r.json() : [];
          G[k] = j && j[0] ? [+(+j[0].lat).toFixed(5), +(+j[0].lon).toFixed(5)] : null; } catch (e) { G[k] = null; }
        if (asked % 20 === 0) fs.writeFileSync(gfile, JSON.stringify(G)); }
      if (G[k]) pts.push([G[k][0], G[k][1], n]);
    }
    fs.writeFileSync(gfile, JSON.stringify(G));
    /* places that were not found, or that lie far from the others, are dropped; fewer than three left is not a ride */
    const centre = pts.length ? [pts.reduce((a, p) => a + p[0], 0) / pts.length, pts.reduce((a, p) => a + p[1], 0) / pts.length] : null;
    const good = pts.filter(p => centre && hav(p, centre) < 250);
    if (good.length < 3) { newOut.refused[c.id] = 'only ' + good.length + ' of ' + names.length + ' places found'; continue; }
    if (/\bloop\b/.test(String(c.tags || '')) && hav(good[0], good[good.length - 1]) > 5) good.push(good[0]);
    const tk = Array.isArray(c.target_km) ? c.target_km : null;
    NEW.set('new:' + c.id, { c, wps: good, tk });
    rides.push(['new:' + c.id, good.map(p => [p[0], p[1]]), tk ? Math.round((tk[0] + tk[1]) / 2) : 0]);
  }
  fs.writeFileSync(newFile, JSON.stringify(newOut, null, 1));
  log('queued concepts to route as new rides:', NEW.size, '(' + Object.keys(newOut.rides).length + ' already done, ' + Object.keys(newOut.refused).length + ' refused)');
}

const rideById = new Map(rides.map(r => [r[0], r]));
const regs = await regions();
/* r89 qualification (audit r88 N1): the staged coverage tiles, together with the site's current road files, are loaded into the
   REAL phone router (phone-route.js shipped with this job) in a sandbox; routes cross a square border with a required middle
   stop; every answer must keep its stops in order, one leg per stop gap, stops within 30 m; and every pair of distinct
   OSM nodes at one point (a bridge over a road) must stay two nodes. Times and memory are recorded. */
async function qualify(staged, netDir, man, log) {
  const vm = await import('node:vm'); const src = fs.readFileSync(new URL('./phone-route.js', import.meta.url), 'utf8');
  const cells = Object.keys(staged), idx = { cells: Object.assign({}, man.cells, Object.fromEntries(cells.map(c => [c, 1]))) };
  const failures = [], routes = [], t0 = Date.now(), m0 = process.memoryUsage().heapUsed;
  const C = { console: { log() {}, warn() {}, error() {} }, URL, Response, Request, Headers, Blob, TextDecoder, TextEncoder, Uint8Array, ReadableStream, AbortController, DOMException, DecompressionStream, setTimeout, clearTimeout, Map, Set, Promise, Math, Date, JSON, Number, isFinite, decodeURIComponent, location: { href: 'https://curvescout.com/' }, sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} } };
  C.window = C; C.fetch = async u => { const name = String(u.url || u).split('?')[0].split('/').pop();
    if (name === 'netc-index.json') return new Response(JSON.stringify(idx));
    const m = name.match(/^netc-(-?\d+_-?\d+)\.json\.gz$/); const f = m && staged[m[1]] ? staged[m[1]].file : path.join(netDir, name);
    return fs.existsSync(f) ? new Response(fs.readFileSync(f)) : new Response('', { status: 404 }); };
  vm.createContext(C); vm.runInContext(src, C); const R = C.CS_PHONE_ROUTE;
  /* sample stops: junction nodes of the staged tiles, in different squares, 15-90 km apart, plus a middle stop */
  const nodes = []; for (const c of cells) { const j = JSON.parse(zlib.gunzipSync(fs.readFileSync(staged[c].file))); for (let i = 0, k = 0; i < j.e.length; i += 10, k++) if (j.e[i + 5] <= 5 && k % 7 === 0) nodes.push({ c, p: [j.e[i] / 1e5, j.e[i + 1] / 1e5] }); }
  const H = (a, b) => { const r = Math.PI / 180, x = (b[0] - a[0]) * r, y = (b[1] - a[1]) * r; return 12742000 * Math.asin(Math.sqrt(Math.sin(x / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(y / 2) ** 2)); };
  let seed = 7; const rnd = n => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed % n; };
  for (let tries = 0; routes.length < 6 && tries < 400 && nodes.length > 2; tries++) { const a = nodes[rnd(nodes.length)], b = nodes[rnd(nodes.length)]; if (a.c === b.c) continue; const d = H(a.p, b.p); if (d < 15000 || d > 90000) continue;
    const mids = nodes.filter(x => Math.abs(H(a.p, x.p) + H(x.p, b.p) - d) < d * 0.15 && H(a.p, x.p) > d * 0.3 && H(x.p, b.p) > d * 0.3); if (!mids.length) continue; const m = mids[rnd(mids.length)];
    const q0 = Date.now(), r = await R.route([a.p, m.p, b.p], {}), ok = r.code === 'Ok', w = r.waypoints || [], legs = ok ? r.routes[0].legs.length : 0;
    const near = ok && w.length === 3 && w.every((x, i) => H([x.location[1], x.location[0]], [a.p, m.p, b.p][i]) <= 30);
    routes.push({ from: a.p, via: m.p, to: b.p, squares: [a.c, m.c, b.c], code: r.code, km: ok ? Math.round(r.routes[0].distance / 100) / 10 : null, legs, stopsWithin30m: !!near, ms: Date.now() - q0 }); }
  const okRoutes = routes.filter(r => r.code === 'Ok');
  if (routes.length < 4) failures.push('too few test routes could be drawn (' + routes.length + ')');
  if (okRoutes.length < Math.ceil(routes.length * 2 / 3)) failures.push(okRoutes.length + ' of ' + routes.length + ' test routes found');
  if (okRoutes.some(r => r.legs !== 2 || !r.stopsWithin30m)) failures.push('a route did not keep its stops in order or near the road');
  if (!okRoutes.some(r => new Set(r.squares).size > 1)) failures.push('no route crossed a square border');
  /* grade separation: two node ids at one point stay two nodes in the router */
  let pairs = 0, merged = 0; const at = new Map();
  for (const c of cells) { const j = JSON.parse(zlib.gunzipSync(fs.readFileSync(staged[c].file))); for (let i = 0, k = 0; i < j.e.length; i += 10, k++) for (const [o, id] of [[0, j.node_ids[2 * k]], [2, j.node_ids[2 * k + 1]]]) { const key = j.e[i + o] + ',' + j.e[i + o + 1]; const s = at.get(key) || new Set(); s.add(String(id)); at.set(key, s); } }
  const G = R.graph; for (const [, s] of at) if (s.size > 1) { pairs++; const idxs = new Set([...s].map(id => G.key.get(/^\d+$/.test(id) ? +id : 'id:' + id)).filter(x => x !== undefined)); if (idxs.size > 0 && idxs.size < s.size) merged++; }
  if (merged) failures.push(merged + ' separate OSM nodes at one point were joined');
  return { passed: !failures.length, failures, routes, gradeSeparatedPoints: pairs, joined: merged, loadedSquares: Object.keys(G.loaded).length, turnRestrictionNodes: G.restN.size, seconds: Math.round((Date.now() - t0) / 100) / 10, heapMB: Math.round((process.memoryUsage().heapUsed - m0) / 1048576), at: new Date().toISOString() };
}
/* ---- r89 NETWORK COVERAGE (owner: "sort out this crazy slowness"; audit r88 N1/N2) ----
   Fills 1-degree squares that have no legacy road file with COVERAGE tiles (netc-*, v2: OSM node ids, motorcycle access,
   direction, via-node turn restrictions; see net-export.mjs). The phone uses a square's coverage tile only when the
   manifest data/net/netc-index.json lists it, and that manifest is written only for qualified, validated output.
   - never in --plan (plan mode only counts the squares, no download, no work folder, no file);
   - per region a state: done (files written and in the manifest), empty (verified: no road in the wanted squares),
     retry (failed, tried again next run), failed (three failures - NOT done), capped (size cap - NOT done);
   - resume checks the request (box, cap, classes, exporter version) and every file of a done region against the
     manifest's SHA-256; a missing or changed file sends its region back to work;
   - each region is built in this run's own work folder, validated, then copied in (temporary name, then rename);
   - QUALIFICATION first: the smallest region with two or more squares is built, loaded into the real phone router and
     routed across a square border with a required middle stop; bridges (two node ids at one point) must stay apart.
     Only when that passes is anything adopted; otherwise coverage is refused and recorded, and the rides follow;
   - r88's unqualified main-road files (netm-* in squares without a legacy full file) are removed first. */
if (NETCOVER && PLAN) { const box = INJ.box || [35, 72, -11, 32]; let n = 0; for (let la = box[0]; la < box[1]; la++) for (let lo = box[2]; lo < box[3]; lo++) if (!fs.existsSync(path.join(NETDIR, 'net-' + la + '_' + lo + '.json.gz'))) n++;
  log('plan: network coverage would look at', n, 'squares without a legacy road file (nothing downloaded or written in plan mode)'); }
if (NETCOVER && !PLAN) {
  const box = INJ.box || [35, 72, -11, 32], capMB = +INJ.capMB || 265, sha = b => crypto.createHash('sha256').update(b).digest('hex');
  const covReq = sha(JSON.stringify({ box, capMB, classes: NETX.CLASSES.slice(0, 8), gen: NETX.COVERAGE_VERSION, maxpbf: MAXPBF }));
  const MAN = path.join(NETDIR, 'netc-index.json'), readMan = () => { try { const m = JSON.parse(fs.readFileSync(MAN, 'utf8')); return m && m.cells ? m : null; } catch (e) { return null; } };
  const writeMan = m => { m.built = new Date().toISOString(); m.licence = 'Road data (c) OpenStreetMap contributors, ODbL'; const t = MAN + '.tmp-' + process.pid; fs.writeFileSync(t, JSON.stringify(m)); fs.renameSync(t, MAN); };
  let C = prog.cov && prog.cov.req === covReq ? prog.cov : { req: covReq, regions: {}, qualified: null, refused: null, orphansRemoved: [] }; prog.cov = C;
  let man = readMan(); if (!man || man.req !== covReq) man = { v: 2, gen: NETX.COVERAGE_VERSION, req: covReq, cells: {} };
  /* r88's unqualified main-road files: netm-* where no legacy full file exists */
  let legacy = new Set(); try { legacy = new Set(Object.keys(JSON.parse(fs.readFileSync(path.join(NETDIR, 'net-index.json'), 'utf8')).cells || {})); } catch (e) {}
  if (legacy.size) for (const f of fs.readdirSync(NETDIR)) { const m = f.match(/^netm-(-?\d+_-?\d+)\.json\.gz$/); if (m && !legacy.has(m[1]) && !fs.existsSync(path.join(NETDIR, 'net-' + m[1] + '.json.gz'))) { fs.rmSync(path.join(NETDIR, f)); C.orphansRemoved.push(f); } }
  if (C.orphansRemoved.length) log('network coverage: removed', C.orphansRemoved.length, 'unqualified r88 main-road files');
  /* resume: every done region's files must be in the manifest with the same bytes */
  for (const [id, r] of Object.entries(C.regions)) if (r.state === 'done') for (const c of r.cells || []) { const f = path.join(NETDIR, 'netc-' + c + '.json.gz'), e = man.cells[c];
    if (!e || !fs.existsSync(f) || sha(fs.readFileSync(f)) !== e.sha256) { log('network coverage: ' + c + ' missing or changed - ' + id + ' is built again'); r.state = 'retry'; r.tries = 0; delete man.cells[c]; break; } }
  const want = new Set(); for (let la = box[0]; la < box[1]; la++) for (let lo = box[2]; lo < box[3]; lo++) { const c = la + '_' + lo; if (!legacy.has(c) && !fs.existsSync(path.join(NETDIR, 'net-' + c + '.json.gz'))) want.add(c); }
  const big = regs.slice().sort((a, b) => b.area - a.area), fits = new Map(), picks = new Map();
  for (const c of want) { const [la, lo] = c.split('_').map(Number);
    for (const [fy, fx] of [[0.5, 0.5], [0.15, 0.15], [0.15, 0.85], [0.85, 0.15], [0.85, 0.85], [0.5, 0.15], [0.5, 0.85], [0.15, 0.5], [0.85, 0.5]]) { const p = [la + fy, lo + fx]; let pick = null;
      for (const g of big) { if (p[1] < g.bbox[0] || p[1] > g.bbox[2] || p[0] < g.bbox[1] || p[0] > g.bbox[3] || !inGeom(p, g.geom)) continue;
        if (!fits.has(g.id)) { const n = await sizeOf(g); fits.set(g.id, n > 0 && n <= MAXPBF); } if (fits.get(g.id)) { pick = g; break; } }
      if (pick) { if (!picks.has(pick.id)) picks.set(pick.id, { g: pick, cells: new Set() }); picks.get(pick.id).cells.add(c); } } }
  const OSM = (() => { try { execFileSync('osmium', ['--version'], { stdio: 'ignore' }); return a => sh('osmium', a.map(x => x.replace(/^\/data\//, WORK + '/'))); } catch (e) { return a => sh('docker', ['run', '--rm', '-v', WORK + ':/data', OSMIUM].concat(a)); } })();
  const dist = x => Math.hypot((x.g.bbox[1] + x.g.bbox[3]) / 2 - 46, ((x.g.bbox[0] + x.g.bbox[2]) / 2 - 8) * 0.7);
  const all = [...picks.values()].sort((a, b) => dist(a) - dist(b));
  const open = x => { const r = C.regions[x.g.id]; return !r || r.state === 'retry'; };
  /* build one region into this run's own folder; returns { staged: {cell: file}, stats } */
  async function buildRegion(x) { freshWork(); const st = path.join(WORK, 'stage'); fs.mkdirSync(st);
    sh('curl', ['-fL', '--retry', '5', '--retry-all-errors', '-o', path.join(WORK, 'r.osm.pbf'), x.g.pbf]);
    const inHash = sha(fs.readFileSync(path.join(WORK, 'r.osm.pbf')));
    OSM(['tags-filter', '--overwrite', '/data/r.osm.pbf', 'w/highway=' + NETX.CLASSES.slice(0, 8).join(','), '-o', '/data/hw.osm.pbf']);
    OSM(['export', '--overwrite', '/data/hw.osm.pbf', '-f', 'geojsonseq', '--geometry-types=linestring', '--attributes=id,way_nodes', '-o', '/data/hw.geojsonseq']);
    OSM(['tags-filter', '--overwrite', '-R', '/data/r.osm.pbf', 'r/type=restriction', '-o', '/data/rel.osm.pbf']);
    OSM(['cat', '--overwrite', '-t', 'relation', '-f', 'opl', '/data/rel.osm.pbf', '-o', '/data/rel.opl']);
    const rel = fs.readFileSync(path.join(WORK, 'rel.opl'), 'utf8');
    const stats = await NETX.exportNet(path.join(WORK, 'hw.geojsonseq'), NETDIR, log, { majorsOnly: true, only: x.cells, capMB, stage: st, prefix: 'netc', restrictions: rel });
    const staged = {}; for (const f of fs.readdirSync(st)) { const m = f.match(/^netc-(-?\d+_-?\d+)\.json\.gz$/); if (!m) continue; const b = fs.readFileSync(path.join(st, f)), j = JSON.parse(zlib.gunzipSync(b));
      const ne = j.e.length / 10; if (j.v !== 2 || j.e.length % 10 || j.node_ids.length !== 2 * ne || j.w.length !== ne || (j.rs || []).length % 4) throw Error('coverage tile failed validation: ' + f);
      staged[m[1]] = { file: path.join(st, f), sha256: sha(b), bytes: b.length, edges: ne }; }
    return { staged, stats, inHash }; }
  function adopt(staged) { for (const [c, x] of Object.entries(staged)) { const t = path.join(NETDIR, '.netc-' + c + '.tmp-' + process.pid); fs.copyFileSync(x.file, t); fs.renameSync(t, path.join(NETDIR, 'netc-' + c + '.json.gz')); man.cells[c] = { sha256: x.sha256, bytes: x.bytes, edges: x.edges }; } writeMan(man); }
  let stop = false;
  /* qualification */
  if (!C.qualified && !C.refused) { const q = all.filter(x => x.cells.size >= 2 && (prog.sizes || {})[x.g.id] && prog.sizes[x.g.id] <= 150 * 1048576).sort((a, b) => prog.sizes[a.g.id] - prog.sizes[b.g.id])[0];
    if (!q) { C.refused = 'no small region with two squares to qualify on'; log('network coverage refused:', C.refused); }
    else { try { log('network coverage: qualifying on', q.g.id, [...q.cells].join(' '));
        const t0 = Date.now(), b = await buildRegion(q), rep = await qualify(b.staged, NETDIR, man, log);
        rep.region = q.g.id; rep.inputSha256 = b.inHash; rep.exportStats = { ways: b.stats.ways, edges: b.stats.edges, refusedWays: b.stats.refusedWays, restrictions: b.stats.restrictions }; rep.buildSeconds = Math.round((Date.now() - t0) / 1000); rep.profile = 'motorcycle: access motorcycle>motor_vehicle>vehicle>access, oneway:motorcycle>oneway, via-node turn restrictions'; rep.graphRevision = NETX.COVERAGE_VERSION; rep.tiles = Object.fromEntries(Object.entries(b.staged).map(([c, x]) => [c, { sha256: x.sha256, bytes: x.bytes, edges: x.edges }]));
        writeCell(path.join(OUT, 'net-qualification.json'), rep);
        if (rep.passed) { adopt(b.staged); C.qualified = { region: q.g.id, at: new Date().toISOString() }; const cp = b.stats.capped || []; C.regions[q.g.id] = { state: cp.length ? 'capped' : Object.keys(b.staged).length ? 'done' : 'empty', tries: 1, cells: Object.keys(b.staged) }; if (cp.length) { C.regions[q.g.id].cappedCells = cp; for (const y of all) if (y !== q && !C.regions[y.g.id]) C.regions[y.g.id] = { state: 'capped', tries: 0 }; } log('network coverage: qualified on', q.g.id); }
        else { C.refused = 'qualification failed: ' + rep.failures.join('; '); log('network coverage refused -', C.refused); }
      } catch (e) { const r = C.regions[q.g.id] = C.regions[q.g.id] || { tries: 0 }; r.tries++; r.err = String(e && e.message || e).slice(0, 200); r.state = r.tries >= 3 ? 'failed' : 'retry'; if (r.state === 'failed') C.refused = 'qualification region could not be built: ' + r.err; log('network coverage qualification error:', r.err); stop = r.state === 'retry'; }
      finally { wipeWork(); } }
    flush(); commit('Network: coverage qualification (' + (C.qualified ? 'passed' : C.refused ? 'refused' : 'to retry') + ')'); }
  if (C.qualified && !stop) {
    for (const x of all) { if (!open(x)) continue; if (C.regions[x.g.id] && C.regions[x.g.id].state === 'capped') continue;
      if (Date.now() > DEADLINE - 25 * 60000) { flush(); commit('Network: coverage saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); }
      const r = C.regions[x.g.id] = C.regions[x.g.id] || { tries: 0 }; r.tries = (r.tries || 0) + 1;
      try { log('network coverage', x.g.id, [...x.cells].join(' ')); const b = await buildRegion(x); adopt(b.staged);
        const capped = b.stats.capped || []; r.cells = Object.keys(b.staged); r.err = undefined;
        r.state = capped.length ? 'capped' : r.cells.length ? 'done' : 'empty'; if (capped.length) r.cappedCells = capped;
        flush(); commit('Network: ' + x.g.id + ' (' + r.cells.length + ' squares' + (capped.length ? ', ' + capped.length + ' left out at the size cap' : '') + ')');
        if (capped.length) { for (const y of all) if (open(y) && y !== x) C.regions[y.g.id] = { state: 'capped', tries: 0 }; log('network coverage: size cap reached - the remaining regions are recorded as capped (not covered)'); break; }
      } catch (e) { r.err = String(e && e.message || e).slice(0, 200); r.state = r.tries >= 3 ? 'failed' : 'retry'; log('network coverage', r.state, x.g.id, r.err); }
      finally { wipeWork(); } } }
  const S = { done: 0, empty: 0, retry: 0, failed: 0, capped: 0 }; for (const r of Object.values(C.regions)) S[r.state] = (S[r.state] || 0) + 1;
  C.summary = Object.assign({ regionsWanted: all.length, untouched: all.filter(x => !C.regions[x.g.id]).length, squaresCovered: Object.keys(man.cells).length, complete: !C.refused && !!C.qualified && S.retry === 0 && S.failed === 0 && S.capped === 0 && all.every(x => C.regions[x.g.id]) }, S);
  flush(); commit('Network: coverage state (' + JSON.stringify(C.summary) + ')', true);
  if (S.retry > 0 && !C.refused) { log('stopped: some regions are to be retried - the next run carries on.'); process.exit(0); }
  if (INJ.mode === 'net-cover') { log((C.summary.complete ? 'finished.' : 'stopped: coverage incomplete'), JSON.stringify(C.summary)); process.exit(0); }
  log('network coverage ' + (C.summary.complete ? 'complete' : 'INCOMPLETE') + ' - the rides follow', JSON.stringify(C.summary)); }
/* r36+: a ride routed before turn steps were kept is routed again once (prog.done2) */
prog.done2 = prog.done2 || {};
const todo = RETRY ? [] : rides.filter(r => !prog.done2[RK(r)]);   /* r85: resume by request identity, never by ride ID alone */
if (RETRY) { prog.done3 = prog.done3 || {}; prog.clipFail = prog.clipFail || {}; prog.retried = prog.retried || {};
  for (const r of rides) if (!prog.retried[RK(r)]) { delete prog.done3[RK(r)]; delete prog.clipFail[RK(r)]; prog.retried[RK(r)] = 1; }
  if (!prog.retryStarted) { for (const k of Object.keys(prog.tries || {})) if (k.startsWith('clip:')) delete prog.tries[k]; prog.retryStarted = 1; } }
const { by, none } = await assign(regs, todo);
if (!PLAN) { prog.refused = prog.refused || {}; for (const id of none) { const r = rideById.get(id); if (r) { prog.refused[RK(r)] = 'fits no downloadable map region'; prog.done2[RK(r)] = 1; } } }
let order = [...by.values()].sort((a, b) => (a.regs.length - b.regs.length) || (b.rides.length - a.rides.length));
if (ONLY.length) order = order.filter(x => x.regs.some(g => ONLY.includes(g.id)));
/* r85: the canary rides (INJ.canary: ids) go first, so a small real-graph batch is on record before the bulk */
const CANARY = new Set(INJ.canary || []), hasCanary = x => x.rides.some(r => CANARY.has(r[0]));
if (CANARY.size) order = order.filter(hasCanary).concat(order.filter(x => !hasCanary(x)));
log(order.length + ' router builds planned (' + order.filter(x => x.regs.length === 1).length + ' single regions, ' + order.filter(x => x.regs.length > 1).length + ' border crossings), ' + todo.length + ' rides not yet done, ' + none.length + ' rides fit no region');
if (PLAN) { for (const x of order) console.log(String(x.rides.length).padStart(6), x.key); process.exit(0); }
prog.tries = prog.tries || {};
for (let gi = 0; gi < order.length; gi++) { const x = order[gi];
  /* r54: a region needs about an hour to build; with less time left the next run takes it */
  if (!ROUTER && Date.now() > DEADLINE - 75 * 60000) { STOPPED = true; log('time limit near - the next run carries on with', x.key); break; }
  if (Date.now() > DEADLINE) { STOPPED = true; break; }
  /* r54: a region that already used up two runs without finishing is set aside (no endless loop) */
  /* r56: a region build that already failed (too large, out of memory, too slow) is not tried again - the second pass cuts small boxes instead */
  if (!ROUTER && typeof prog.failed[x.key] === 'string' && /^(too large|too slow|Command failed)/.test(prog.failed[x.key])) { log(x.key, 'left to the second pass (' + prog.failed[x.key].slice(0, 40) + ')'); for (const r of x.rides) prog.done[RK(r)] = prog.done2[RK(r)] = 1; continue; }
  if (!ROUTER && (prog.tries[x.key] || 0) >= 2) { log(x.key, 'did not finish in two runs - left to the live router'); prog.failed[x.key] = 'too slow for this machine'; for (const r of x.rides) prog.done[RK(r)] = prog.done2[RK(r)] = 1; flush(); continue; }
  if (!ROUTER) { prog.tries[x.key] = (prog.tries[x.key] || 0) + 1; flush(); commit('Roads: starting ' + x.key, false); }
  log('== ' + (gi + 1) + '/' + order.length, x.key, x.rides.length, 'rides');
  let base = ROUTER;
  if (!base) { const st = await startRouter(x).catch(e => ({ err: e.message }));
    if (st.tooBig) { log(st.reg.id, 'is ' + Math.round(st.tooBig / 1048576) + ' MB - its rides go to its sub-regions'); prog.tooBig = [...new Set((prog.tooBig || []).concat(st.reg.id))]; flush();
      const sub = await assign(regs, x.rides); for (const y of sub.by.values()) { const e = order.slice(gi + 1).find(z => z.key === y.key); if (e) e.rides.push(...y.rides); else order.push(y); } stopRouter(); continue; }
    if (st.tooLarge) { log(x.key, 'together are too large for this machine - left to the live router'); prog.failed[x.key] = 'too large together'; flush(); stopRouter(); continue; }
    if (st.err) { log('router failed for', x.key, st.err); prog.failed[x.key] = st.err; flush(); stopRouter(); continue; }
    base = st.url; }
  const res = await routeAll(base, x.rides, x.key);
  for (const r of x.rides) if (res.tried.has(r[0]) && !res.retry.has(r[0])) { prog.done[RK(r)] = 1; prog.done2[RK(r)] = 1; }
  if (!STOPPED || res.tried.size) delete prog.tries[x.key];   /* a router hiccup is tried again on the next run */
  if (res.fails.length) prog.failed[x.key] = res.fails.slice(0, 200);
  const idx = flush(); cells.clear();
  log(x.key, 'done:', res.ok, 'roads,', res.bad, 'refused · catalogue now', idx.total, 'roads');
  if (NET && !ROUTER) { prog.netDone = prog.netDone || {}; prog.netDone[x.key] = 1; flush(); }
  if (!ROUTER) stopRouter();
  commit('Roads: ' + x.key + ' (' + res.ok + ' rides on their real road)');
  if (STOPPED) break;
}
if (STOPPED) { flush(); commit('Roads: run saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); }
/* r56 second pass - the rides that still have no stored road. Instead of building the router for a whole region (too big for
   a GitHub machine: Italy, Turkey, US state groups...), download the region once, cut a small box around a handful of nearby
   rides (osmium extract) and build the router on that box only. Each box is a few minutes; nothing waits on huge builds.
   Only rides without a stored road are touched, stored roads are never changed. Progress: prog.done3. */
const CLIPMAX = +opt('clip-max', 3500) * 1048576, BOXDEG = +opt('box', RETRY ? 1.2 : 2.2), PAD = +opt('pad', RETRY ? 0.5 : 0.35);
const storedIds = () => { const ids = new Set(); for (const f of fs.readdirSync(OUT)) { const m = f.match(/^roads-(\d+-\d+)\.json(\.gz)?$/); if (!m) continue; const j = readCell(cellFile(m[1]), 'roads'); if (j) for (const [k, v] of Object.entries(j.roads || {})) { const r = rideById.get(k); if (r && v && v[4] && v[4].rq === rqHash(r[1])) ids.add(k); } } return ids; };   /* r85: only a road stored for THIS request counts */
function clusters(list) {   /* greedy: rides whose combined box stays within BOXDEG x BOXDEG share one router build */
  const box = r => { const la = r[1].map(p => p[0]), lo = r[1].map(p => p[1]); return [Math.min(...lo), Math.min(...la), Math.max(...lo), Math.max(...la)]; };
  const items = list.map(r => ({ r, b: box(r) })).sort((a, b) => (a.b[0] + a.b[2]) - (b.b[0] + b.b[2]) || (a.b[1] + a.b[3]) - (b.b[1] + b.b[3]));
  const out = [];
  for (const it of items) { let best = null;
    for (const c of out) { const u = [Math.min(c.b[0], it.b[0]), Math.min(c.b[1], it.b[1]), Math.max(c.b[2], it.b[2]), Math.max(c.b[3], it.b[3])];
      if (u[2] - u[0] <= BOXDEG && u[3] - u[1] <= BOXDEG) { best = c; best.u = u; break; } }
    if (best) { best.b = best.u; best.rides.push(it.r); } else out.push({ b: it.b.slice(), rides: [it.r] }); }
  return out.map(c => ({ rides: c.rides, bbox: [c.b[0] - PAD, c.b[1] - PAD, c.b[2] + PAD, c.b[3] + PAD].map(v => Math.round(v * 1e4) / 1e4) }));
}
async function clipAssign(regs, list) {   /* the SMALLEST region holding every checkpoint and small enough to download */
  const by = new Map(), none = []; const sorted = regs.slice().sort((a, b) => a.area - b.area);
  const inBox = (p, g) => p[1] >= g.bbox[0] && p[1] <= g.bbox[2] && p[0] >= g.bbox[1] && p[0] <= g.bbox[3];
  for (const r of list) { const pts = (r[1] || []).map(p => [p[0], p[1]]); if (pts.length < 2) { none.push(r[0]); continue; }
    let pick = null; for (const g of sorted) { if (!pts.every(p => inBox(p, g)) || !pts.every(p => inGeom(p, g.geom))) continue; const n = await sizeOf(g); if (n > 0 && n <= CLIPMAX) { pick = g; break; } }
    let set = pick ? [pick] : [];
    if (!pick) { for (const p of pts) { let g = null; for (const h of sorted) { if (inBox(p, h) && inGeom(p, h.geom)) { const n = await sizeOf(h); if (n > 0 && n <= CLIPMAX) { g = h; break; } } } if (!g) { set = null; break; } if (!set.includes(g)) set.push(g); }
      if (set && (set.length > 3 || set.reduce((a, g) => a + (prog.sizes[g.id] || 0), 0) > CLIPMAX * 1.5)) set = null; }
    if (!set) { none.push(r[0]); continue; }
    set.sort((a, b) => a.id.localeCompare(b.id)); const key = set.map(g => g.id).join('+'); if (!by.has(key)) by.set(key, { key, regs: set, rides: [] }); by.get(key).rides.push(r); }
  return { by, none };
}
async function buildOn(pbf, bbox) {   /* cut the box out of the downloaded region and start the router on it */
  for (const f of fs.readdirSync(WORK)) if (/^c\./.test(f)) fs.rmSync(path.join(WORK, f), { force: true });
  const b = bbox.join(','), out = path.join(WORK, 'c.osm.pbf'); GRAPH_REV = ((typeof GRAPH_SRC !== 'undefined' && GRAPH_SRC) || path.basename(pbf)) + ' box ' + b;
  try { execFileSync('osmium', ['--version'], { stdio: 'ignore' }); sh('osmium', ['extract', '-b', b, '-s', 'smart', '--overwrite', pbf, '-o', out]); }
  catch (e) { sh('docker', ['run', '--rm', '-v', WORK + ':/data', OSMIUM, 'extract', '-b', b, '-s', 'smart', '--overwrite', '/data/' + path.basename(pbf), '-o', '/data/c.osm.pbf']); }
  const d = ['run', '--rm', '-v', WORK + ':/data', IMAGE];
  writeProfile(); extractWith(d, '/data/c.osm.pbf');   /* r85 audit G1: no fallback to the ordinary car profile */ fs.rmSync(out, { force: true });
  sh('docker', d.concat(['osrm-partition', '/data/c.osrm'])); sh('docker', d.concat(['osrm-customize', '/data/c.osrm']));
  try { execFileSync('docker', ['rm', '-f', CNAME], { stdio: 'ignore' }); } catch (e) {}
  sh('docker', ['run', '-d', '--name', CNAME, '-p', '127.0.0.1:5000:5000', '-v', WORK + ':/data', IMAGE, 'osrm-routed', '--algorithm', 'mld', '--max-viaroute-size', '1000', '/data/c.osrm']);
  for (let k = 0; k < 120; k++) { try { const r = await fetch('http://127.0.0.1:5000/route/v1/driving/0,0;0.001,0.001'); if (r.status) break; } catch (e) {} await new Promise(r => setTimeout(r, 1000)); }
  return 'http://127.0.0.1:5000';
}
if (!PLAN && !opt('no-clip', false)) {
  prog.done3 = prog.done3 || {}; prog.clipFail = prog.clipFail || {};
  const have = storedIds(); const todo3 = rides.filter(r => !have.has(r[0]) && !prog.done3[RK(r)]);
  log('second pass: ' + todo3.length + ' rides without a stored road - routed in small boxes cut from their region');
  const { by: by3, none: none3 } = await clipAssign(regs, todo3);
  for (const id of none3) { const r = rideById.get(id); prog.done3[RK(r)] = 1; prog.clipFail[RK(r)] = 'no downloadable region holds it'; }
  let groups = [...by3.values()].sort((a, b) => b.rides.length - a.rides.length); if (CANARY.size) groups = groups.filter(hasCanary).concat(groups.filter(x => !hasCanary(x))); let DLFAIL = 0;
  if (!ROUTER && (prog.dlStops || 0) >= 6) { log('map downloads refused in six runs in a row - the rest keep the live router'); for (const x of groups) for (const r of x.rides) { prog.done3[RK(r)] = 1; prog.clipFail[RK(r)] = 'map download refused'; } groups.length = 0; flush(); }
  for (const x of groups) {
    if (Date.now() > DEADLINE - 30 * 60000) { STOPPED = true; log('time limit near - the next run carries on with', x.key); break; }
    const tk = 'clip:' + x.key; prog.tries[tk] = (prog.tries[tk] || 0) + 1;
    if (!ROUTER && prog.tries[tk] > 3) { log(x.key, 'did not finish in three runs - left to the live router'); for (const r of x.rides) { prog.done3[RK(r)] = 1; prog.clipFail[RK(r)] = 'region too slow'; } flush(); continue; }
    flush();
    let pbf = null;
    if (!ROUTER) { try { freshWork(); const files = [];
        for (const [k, reg] of x.regs.entries()) { log('downloading', reg.id, Math.round((prog.sizes[reg.id] || 0) / 1048576) + ' MB'); const f = path.join(WORK, 'p' + k + '.osm.pbf'); sh('curl', ['-fsSL', '--retry', '4', '--retry-delay', '30', '--retry-all-errors', '-o', f, reg.pbf]); files.push(f); }
        GRAPH_SRC = x.key + '@' + new Date().toISOString().slice(0, 10) + ':' + files.reduce((a, f) => a + fs.statSync(f).size, 0);
        pbf = path.join(WORK, 'r.osm.pbf'); if (files.length === 1) fs.renameSync(files[0], pbf); else { osmiumMerge(files, pbf); files.forEach(f => fs.rmSync(f, { force: true })); }
      } catch (e) { log('download failed for', x.key, String(e.message || e).slice(0, 160)); stopRouter(); DLFAIL++;
        /* r84: map downloads refused several times in a row means the download server is limiting this machine - stop and
           save so the next run (a new machine) carries on, instead of skipping every region and calling the run finished */
        if (DLFAIL >= 3) { STOPPED = true; prog.dlStops = (prog.dlStops || 0) + 1; log('map downloads refused ' + DLFAIL + ' times in a row - saving; the next run carries on'); break; }
        try { execFileSync('sleep', [String(60 * DLFAIL)]); } catch (e2) {} continue; } DLFAIL = 0; prog.dlStops = 0; }
    const boxes = clusters(x.rides); log('== ' + x.key + ': ' + x.rides.length + ' rides in ' + boxes.length + ' boxes');
    let ok = 0, bad = 0;
    for (const c of boxes) {
      if (Date.now() > DEADLINE - 15 * 60000) { STOPPED = true; break; }
      let base = ROUTER;
      if (!ROUTER) { try { base = await buildOn(pbf, c.bbox); } catch (e) { log('box failed', c.bbox.join(','), String(e.message || e).slice(0, 120)); for (const r of c.rides) { prog.done3[RK(r)] = 1; prog.clipFail[RK(r)] = 'box build failed'; } continue; } }
      const res = await routeAll(base, c.rides, x.key);
      for (const r of c.rides) if (res.tried.has(r[0]) && !res.retry.has(r[0])) prog.done3[RK(r)] = 1;
      for (const f of res.fails) { const i = f.indexOf(': '), r = rideById.get(f.slice(0, i)); if (r) prog.clipFail[RK(r)] = f.slice(i + 2); }
      ok += res.ok; bad += res.bad;
      if (!ROUTER) { try { execFileSync('docker', ['rm', '-f', CNAME], { stdio: 'ignore' }); } catch (e) {} }
      if (STOPPED) break;
    }
    if (!STOPPED) delete prog.tries[tk];
    const idx = flush(); cells.clear(); if (!ROUTER) stopRouter();
    log(x.key, 'second pass:', ok, 'new roads,', bad, 'refused · catalogue now', idx.total, 'roads');
    commit('Roads: ' + x.key + ' second pass (' + ok + ' rides on their real road)');
    if (STOPPED) break;
  }
  if (STOPPED) { flush(); commit('Roads: run saved (time limit or map downloads refused - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); }
}
/* r42: regions whose rides were routed before the phone network existed get their network now (download + export only) */
if (NET && !ROUTER && !PLAN) { prog.netDone = prog.netDone || {};
  const all = await assign(regs, rides); const later = [...all.by.values()].filter(x => x.regs.length === 1 && !prog.netDone[x.key]).sort((a, b) => b.rides.length - a.rides.length);
  log(later.length + ' regions still need their road network for the phone');
  for (const x of later) { try { freshWork(); const reg = x.regs[0];
      log('network', x.key); sh('curl', ['-fL', '--retry', '3', '-o', path.join(WORK, 'r.osm.pbf'), reg.pbf]);
      const dm = ['run', '--rm', '-v', WORK + ':/data', OSMIUM];
      sh('docker', dm.concat(['tags-filter', '--overwrite', '/data/r.osm.pbf', 'w/highway=' + NETX.CLASSES.join(','), '-o', '/data/hw.osm.pbf']));
      sh('docker', dm.concat(['export', '--overwrite', '/data/hw.osm.pbf', '-f', 'geojsonseq', '--geometry-types=linestring', '-o', '/data/hw.geojsonseq']));
      await NETX.exportNet(path.join(WORK, 'hw.geojsonseq'), NETDIR, log); prog.netDone[x.key] = 1; flush(); commit('Network: ' + x.key + ' (roads for routing on the phone)');
    } catch (e) { log('network failed for', x.key, String(e && e.message || e).slice(0, 160)); } finally { wipeWork(); } } }
/* r60: a height profile for every stored road (Terrain Tiles on AWS), before the job may call itself finished */
if (!PLAN && !opt('no-heights', false) && !INJ.noHeights && !ROUTER) { const HT = await import(new URL('./road-heights.mjs', import.meta.url));
  const allDone = await HT.run(OUT, DEADLINE, log);
  if (!allDone) { flush(); commit('Roads: heights saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); } }
const idx = flush(); commit('Roads: finished run', true); log('finished.', idx.total, 'roads in', Object.keys(idx.cells).length, 'cells.', none.length, 'rides fit no region (they keep the live router).', 'Ledger:', JSON.stringify(LEDGER));
commit('Roads: catalogue index');
