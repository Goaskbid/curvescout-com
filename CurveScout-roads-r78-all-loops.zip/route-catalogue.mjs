#!/usr/bin/env node
/* ---- EVERY RIDE ON ITS REAL ROAD, ROUTED ONCE (owner 2026-10-13: "no more crap vector rides") ----
 * Runs in a GitHub Codespace of the site repository (no Actions, no secrets, no schedule). It routes every ride in the
 * catalogue on its own OSRM router, region by region, and writes the roads into the site as small files the app reads
 * before it ever asks a public router:
 *     roads-index.json            which cells exist, how many roads each holds, when it was built
 *     roads-<cell>.json           { v:1, cell, roads: { <ride id>: [polyline5, km, min, nWaypoints] } }
 *     steps-<cell>.json           { v:1, cell, steps: { <ride id>: [[metres along, type, modifier, road, exit], ...] } }  every turn
 *     roads-progress.json         which regions are done, so a stopped run carries on where it left off
 * A cell is 3 x 3 degrees of the ride's start, so the atlas loads only the cells it is looking at and a ride page one.
 *
 *   node route-catalogue.mjs                       everything, region by region, commit + push after each region
 *   node route-catalogue.mjs --regions switzerland,austria     just these Geofabrik regions
 *   node route-catalogue.mjs --plan                show the regions and ride counts, change nothing
 *   node route-catalogue.mjs --no-push             write files, do not commit
 *   node route-catalogue.mjs --router http://127.0.0.1:5000   use a router that is already running (tests)
 *   node route-catalogue.mjs --max-pbf 1000        MB; a bigger region is split into its sub-regions (default 1000; 1500 on an 8-core codespace)
 *
 * Input: route-catalogue-input.json (every ride id with its checkpoints, shipped with this tool).
 * Region shapes: https://download.geofabrik.de/index-v1.json. Map data: Geofabrik extracts of OpenStreetMap (ODbL).
 * Router: OSRM v5.27.1 in Docker (car profile, MLD). Each region's files are deleted when the region is done.
 */
import fs from 'node:fs'; import path from 'node:path'; import zlib from 'node:zlib'; import { execFileSync, spawn } from 'node:child_process';

const A = process.argv.slice(2);
const opt = (n, d) => { const i = A.indexOf('--' + n); return i >= 0 ? (A[i + 1] && !A[i + 1].startsWith('--') ? A[i + 1] : true) : d; };
let OUT = path.resolve(opt('out', '.'));
const NET = process.argv.includes('--net'), NETDIR = path.resolve(opt('net', path.join(OUT, '..', 'net')));
const NETX = await import(new URL('./net-export.mjs', import.meta.url));
const INPUT = opt('input', fs.existsSync('route-catalogue-input.json') ? 'route-catalogue-input.json' : 'route-catalogue-input.json.gz');
const WORK = path.resolve(opt('work', '/tmp/cs-roads'));
const IMAGE = opt('image', 'ghcr.io/project-osrm/osrm-backend:v5.27.1');
const OSMIUM = opt('osmium-image', 'iboates/osmium:1.16.0');
const MAXPBF = +opt('max-pbf', 1000) * 1048576;   // 1000 MB suits a 4-core, 16 GB codespace; 1500 on 8-core, 32 GB
const ROUTER = opt('router', '');
const INDEX = opt('index', 'https://download.geofabrik.de/index-v1.json');
const PUSH = !opt('no-push', false), PLAN = !!opt('plan', false);
const ONLY = String(opt('regions', '') || '').split(',').map(s => s.trim()).filter(Boolean);
const PAR = +opt('parallel', 8);
const LOGR = []; const log = (...a) => { const l = new Date().toISOString().slice(11, 19) + ' ' + a.join(' '); console.log(l); LOGR.push(l); if (LOGR.length > 300) LOGR.shift(); };
/* r54: each run stops itself in time (default 300 min), saves everything and leaves the rest to the next run */
const T0 = Date.now(), DEADLINE = T0 + +opt('minutes', 300) * 60000; let STOPPED = false;

/* ---- input ---- */
const readJson = f => { const b = fs.readFileSync(f); return JSON.parse((/\.gz$/.test(f) ? zlib.gunzipSync(b) : b).toString('utf8')); };
const INJ = readJson(INPUT); const rides = INJ.rides;            // [[id, [[lat,lon],...], km], ...]
/* r72 loop job (owner 2026-11-21: circular rides): the input may name its own output folder, kept apart from the live
   roads until a release adopts the results (relative to the repository), the router classes to avoid (ferry), and
   whether heights are skipped. A router that cannot exclude a class answers 400; that ride is then routed without it. */
if (INJ.out) { OUT = path.resolve(process.env.GITHUB_WORKSPACE || process.cwd(), INJ.out); fs.mkdirSync(OUT, { recursive: true }); }
/* exclude may name alternatives in order of preference, e.g. ["motorway", "ferry"]: the first answer that needs no ferry
   wins (owner: rides avoid motorways, and no ferry crossings), else the first answer at all, else the plain route */
const EXCLS = Array.isArray(INJ.exclude) ? INJ.exclude : (INJ.exclude ? [INJ.exclude] : []);
/* r76: motorways are left out of the router itself (a profile built on OSRM's car profile, motorways and their ramps not
   routable), so "no motorway" and "no ferry" hold together; the request then only excludes ferries */
const PROFILE = INJ.noMotorway ? '/data/cs-nomotorway.lua' : '/opt/car.lua';
function writeProfile() { if (!INJ.noMotorway) return; fs.writeFileSync(path.join(WORK, 'cs-nomotorway.lua'),
  "package.path = '/opt/?.lua;' .. package.path\nlocal base = dofile('/opt/car.lua')\nlocal setup0 = base.setup\nbase.setup = function()\n  local p = setup0()\n  p.speeds.highway.motorway = nil\n  p.speeds.highway.motorway_link = nil\n  return p\nend\nreturn base\n"); }
const usesFerry = js => !!(js && js.routes && js.routes[0] && (js.routes[0].legs || []).some(l => (l.steps || []).some(st => st.mode === 'ferry')));
async function preferred(base, coords) {
  let first = null;
  for (const ex of EXCLS) { const r = await fetch(base + '/route/v1/driving/' + coords + '?overview=full&geometries=polyline&steps=true&exclude=' + encodeURIComponent(ex)); if (!r.ok) continue;
    const js = await r.json(); if (!js.routes || !js.routes[0]) continue; if (!usesFerry(js)) return { ok: true, status: 200, json: async () => js }; if (!first) first = js; }
  return first ? { ok: true, status: 200, json: async () => first } : null; }
/* r59 retry pass (input field mode:"retry-missing"): only the rides that still have no stored road. The first pass is
   skipped, their earlier second-pass refusals are cleared, boxes are smaller, a start or finish up to 15 km from the
   nearest road is accepted, and a checkpoint OSRM cannot place on any road is left out of the routing (the stop stays
   in the ride; the page says how far the road passes from it). Lengths are compared with the CURRENT ride length. */
const RETRY = INJ.mode === 'retry-missing' || !!opt('retry-missing', false);
log('rides in the catalogue:', rides.length);

/* ---- NEW ROUTES (owner 2026-10-13: "ingest new routes") ----
   catalogue-queue.json holds the accepted concepts that were never routed: a title, a road and the places it passes. With
   --queue the job finds those places (Nominatim, one request a second, cached in roads-ingest-geocode.json), routes them
   on the same regional routers and writes new-rides.json - measured distance and time, the real road, the named places.
   They go live after review in the next release; nothing is published straight from a machine. */
const QUEUE = opt('queue', fs.existsSync('catalogue-queue.json') ? 'catalogue-queue.json' : '');
const NEW = new Map();   // id -> metadata for queued concepts
const newFile = path.join(OUT, 'new-rides.json');
const newOut = (() => { try { return JSON.parse(fs.readFileSync(newFile, 'utf8')); } catch (e) { return { v: 1, rides: {}, refused: {} }; } })();
/* ---- polyline (precision 5), Douglas-Peucker ---- */
function encode(pts) { let out = '', pl = 0, pn = 0; const e = v => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const [la, lo] of pts) { const a = Math.round(la * 1e5), b = Math.round(lo * 1e5); out += e(a - pl) + e(b - pn); pl = a; pn = b; } return out; }
function decode(s) { const out = []; let i = 0, la = 0, lo = 0; while (i < s.length) { for (const k of [0, 1]) { let r = 0, sh = 0, b; do { b = s.charCodeAt(i++) - 63; r |= (b & 0x1f) << sh; sh += 5; } while (b >= 0x20); const d = r & 1 ? ~(r >> 1) : r >> 1; if (k) lo += d; else la += d; } out.push([la / 1e5, lo / 1e5]); } return out; }
function simplify(pts, tolM) {
  if (pts.length < 3) return pts; const k = 111320, cos = Math.cos(pts[0][0] * Math.PI / 180);
  const P = pts.map(p => [p[1] * k * cos, p[0] * k]); const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1; const st = [[0, pts.length - 1]];
  while (st.length) { const [a, b] = st.pop(); let dm = 0, im = -1; const [x1, y1] = P[a], [x2, y2] = P[b], dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
    for (let i = a + 1; i < b; i++) { const [x, y] = P[i]; let t = l2 ? ((x - x1) * dx + (y - y1) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t)); const d = Math.hypot(x - x1 - t * dx, y - y1 - t * dy); if (d > dm) { dm = d; im = i; } }
    if (dm > tolM) { keep[im] = 1; st.push([a, im], [im, b]); } }
  return pts.filter((_, i) => keep[i]);
}
const cellOf = (la, lo) => (Math.floor(la / 3) + 30) + '-' + (Math.floor(lo / 3) + 60);
const hav = (a, b) => { const R = 6371, t = Math.PI / 180, dLa = (b[0] - a[0]) * t, dLo = (b[1] - a[1]) * t; const h = Math.sin(dLa / 2) ** 2 + Math.cos(a[0] * t) * Math.cos(b[0] * t) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };

/* ---- the site files: read what is there, add, write ---- */
const cells = new Map();
const cellFile = c => path.join(OUT, 'roads-' + c + '.json');
const stepsC = new Map(), stepsFile = c => path.join(OUT, 'steps-' + c + '.json');
/* r46 (GitHub 1 GB rule): cells are stored gzip-compressed (*.json.gz); a leftover plain file is merged in and removed on write */
function readCell(f, key) { let j = null; try { j = JSON.parse(zlib.gunzipSync(fs.readFileSync(f + '.gz')).toString('utf8')); } catch (e) {} let p = null; try { p = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) {} if (j && p) { j[key] = Object.assign({}, j[key], p[key]); return j; } return j || p; }
function writeCell(f, j) { fs.writeFileSync(f + '.gz', zlib.gzipSync(JSON.stringify(j), { level: 9 })); try { fs.rmSync(f); } catch (e) {} }
function stepsGet(c) { if (!stepsC.has(c)) { stepsC.set(c, readCell(stepsFile(c), 'steps') || { v: 1, cell: c, steps: {} }); } return stepsC.get(c); }
function cellGet(c) { if (!cells.has(c)) { cells.set(c, readCell(cellFile(c), 'roads') || { v: 1, cell: c, roads: {} }); } return cells.get(c); }
const progFile = path.join(OUT, 'roads-progress.json');
/* r54: the site keeps roads-progress.json and roads-index.json gzip-compressed (*.json.gz) - read and write those */
const prog = (() => { let a = null, b = null; try { a = JSON.parse(fs.readFileSync(progFile, 'utf8')); } catch (e) {} try { b = JSON.parse(zlib.gunzipSync(fs.readFileSync(progFile + '.gz')).toString('utf8')); } catch (e) {}
  const j = b || a || { v: 1, done: {}, failed: {}, tooBig: [] }; if (a && b) for (const k of ['done', 'done2', 'failed', 'sizes', 'netDone', 'tries']) if (a[k]) j[k] = Object.assign({}, b[k], a[k]); if (a && b) j.tooBig = [...new Set((b.tooBig || []).concat(a.tooBig || []))]; return j; })();
function flush() {
  for (const [c, j] of cells) writeCell(cellFile(c), j);
  for (const [c, j] of stepsC) writeCell(stepsFile(c), j);
  const idx = { v: 1, built: new Date().toISOString(), cells: {} };
  for (const f of fs.readdirSync(OUT)) { const m = f.match(/^roads-(\d+-\d+)\.json(\.gz)?$/); if (!m || m[1] in idx.cells) continue; const j = cells.get(m[1]) || readCell(cellFile(m[1]), 'roads'); if (j) idx.cells[m[1]] = Object.keys(j.roads || {}).length; }
  idx.total = Object.values(idx.cells).reduce((a, b) => a + b, 0);
  writeCell(path.join(OUT, 'roads-index.json'), idx);
  writeCell(progFile, prog);
  try { fs.writeFileSync(path.join(OUT, 'roads-run.txt'), LOGR.join('\n') + '\n'); } catch (e) {}
  if (NEW.size || Object.keys(newOut.rides).length) fs.writeFileSync(newFile, JSON.stringify(newOut, null, 1));
  return idx;
}

/* ---- regions: smallest Geofabrik region that contains every checkpoint of a ride ---- */
function pip(pt, ring) { let inside = false; const [y, x] = pt; for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) { const [xi, yi] = ring[i], [xj, yj] = ring[j]; if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside; } return inside; }
function inGeom(pt, g) { const polys = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : []; return polys.some(p => pip(pt, p[0]) && !p.slice(1).some(h => pip(pt, h))); }
async function regions() {
  let j; if (/^https?:/.test(INDEX)) { log('reading the Geofabrik region index'); const r = await fetch(INDEX); if (!r.ok) throw new Error('index ' + r.status); j = await r.json(); } else j = JSON.parse(fs.readFileSync(INDEX, 'utf8'));
  return j.features.filter(f => f.geometry && f.properties && f.properties.urls && f.properties.urls.pbf).map(f => {
    let b = [180, 90, -180, -90]; const polys = f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates;
    for (const p of polys) for (const [x, y] of p[0]) { b = [Math.min(b[0], x), Math.min(b[1], y), Math.max(b[2], x), Math.max(b[3], y)]; }
    return { id: f.properties.id, parent: f.properties.parent || '', name: f.properties.name, pbf: f.properties.urls.pbf, geom: f.geometry, bbox: b, area: (b[2] - b[0]) * (b[3] - b[1]) };
  });
}
/* each checkpoint belongs to the smallest region around it; a ride whose checkpoints all share one region is routed
   there, a ride that crosses a border is routed on the merged extracts of the regions it touches (osmium merge) */
/* fewer, larger router builds: a ride goes to the LARGEST region that holds all its checkpoints and whose extract is
   small enough for this machine (--max-pbf); sizes come from one HEAD request per region, kept in roads-progress.json.
   Without sizes (offline, tests) each checkpoint takes its smallest region and border crossings merge those. */
async function sizeOf(g) {
  prog.sizes = prog.sizes || {};
  if (g.id in prog.sizes) return prog.sizes[g.id];
  let n = 0; try { const r = await fetch(g.pbf, { method: 'HEAD' }); n = +(r.ok && r.headers.get('content-length')) || 0; } catch (e) { n = 0; }
  if (n) prog.sizes[g.id] = n; return n;   /* a failed HEAD is asked again next run */
}
async function assign(regs, list) {
  const by = new Map(), none = [];
  const sorted = regs.slice().sort((a, b) => a.area - b.area), big = sorted.slice().reverse();
  const inBox = (p, g) => p[1] >= g.bbox[0] && p[1] <= g.bbox[2] && p[0] >= g.bbox[1] && p[0] <= g.bbox[3];
  const leaf = p => sorted.find(g => inBox(p, g) && inGeom(p, g.geom) && !(prog.tooBig || []).includes(g.id));
  const add = (key, set, r) => { if (!by.has(key)) by.set(key, { key, regs: set, rides: [] }); by.get(key).rides.push(r); };
  const decided = new Map();   // region id -> fits (true/false)
  for (const r of list) { const [id, wps] = r; if (!wps || wps.length < 2) { none.push(id); continue; }
    const pts = wps.map(p => [p[0], p[1]]);
    let pick = null;
    for (const g of big) { if ((prog.tooBig || []).includes(g.id) || !pts.every(p => inBox(p, g))) continue; if (!pts.every(p => inGeom(p, g.geom))) continue;
      if (!decided.has(g.id)) { const n = await sizeOf(g); decided.set(g.id, n > 0 && n <= MAXPBF); }
      if (decided.get(g.id)) { pick = g; break; } }
    if (pick) { add(pick.id, [pick], r); continue; }
    const set = []; let miss = false; for (const p of pts) { const g = leaf(p); if (!g) { miss = true; break; } if (!set.includes(g)) set.push(g); }
    if (miss || set.length > 3) { none.push(id); continue; }
    set.sort((a, b) => a.id.localeCompare(b.id)); add(set.map(g => g.id).join('+'), set, r); }
  return { by, none };
}
/* ---- the router ---- */
const sh = (cmd, args, o = {}) => execFileSync(cmd, args, Object.assign({ stdio: 'inherit' }, o));
/* border crossings need two extracts merged: osmium from the Codespace's package manager, else from Docker */
function osmiumMerge(files, out) {
  const have = () => { try { execFileSync('osmium', ['--version'], { stdio: 'ignore' }); return true; } catch (e) { return false; } };
  if (!have()) { try { execFileSync('sudo', ['-n', 'apt-get', 'install', '-y', '-q', 'osmium-tool'], { stdio: 'inherit' }); } catch (e) { try { execFileSync('sudo', ['-n', 'sh', '-c', 'apt-get update -q && apt-get install -y -q osmium-tool'], { stdio: 'inherit' }); } catch (e2) {} } }
  if (have()) return sh('osmium', ['merge', '--overwrite'].concat(files).concat(['-o', out]));
  return sh('docker', ['run', '--rm', '-v', WORK + ':/data', OSMIUM, 'merge', '--overwrite'].concat(files.map(f => '/data/' + path.basename(f))).concat(['-o', '/data/' + path.basename(out)]));
}
async function startRouter(group) {
  fs.rmSync(WORK, { recursive: true, force: true }); fs.mkdirSync(WORK, { recursive: true });
  let total = 0; const sizes = [];
  for (const reg of group.regs) { const head = await fetch(reg.pbf, { method: 'HEAD' }).catch(() => null); const size = head && +head.headers.get('content-length'); sizes.push(size || 0); total += size || 0;
    if (size && size > MAXPBF) return { tooBig: size, reg }; }
  if (total > MAXPBF * 1.3) return { tooLarge: total };
  const files = [];
  for (const [k, reg] of group.regs.entries()) { log('downloading', reg.id, sizes[k] ? Math.round(sizes[k] / 1048576) + ' MB' : ''); const f = path.join(WORK, 'p' + k + '.osm.pbf'); sh('curl', ['-fL', '--retry', '3', '-o', f, reg.pbf]); files.push(f); }
  if (files.length === 1) fs.renameSync(files[0], path.join(WORK, 'r.osm.pbf'));
  else { log('merging', group.key); osmiumMerge(files, path.join(WORK, 'r.osm.pbf')); files.forEach(f => fs.rmSync(f, { force: true })); }
  const d = ['run', '--rm', '-v', WORK + ':/data', IMAGE];
  /* r42: the road network for routing on the rider's phone (backup when OSRM is unavailable), from the same extract */
  if (NET) { try { log('road network for the phone');
    const dm = ['run', '--rm', '-v', WORK + ':/data', OSMIUM];
    sh('docker', dm.concat(['tags-filter', '--overwrite', '/data/r.osm.pbf', 'w/highway=' + NETX.CLASSES.join(','), '-o', '/data/hw.osm.pbf']));
    sh('docker', dm.concat(['export', '--overwrite', '/data/hw.osm.pbf', '-f', 'geojsonseq', '--geometry-types=linestring', '-o', '/data/hw.geojsonseq']));
    await NETX.exportNet(path.join(WORK, 'hw.geojsonseq'), NETDIR, log);
    for (const f of ['hw.osm.pbf', 'hw.geojsonseq']) fs.rmSync(path.join(WORK, f), { force: true }); } catch (e) { log('road network skipped:', String(e && e.message || e).slice(0, 200)); } }
  log('osrm-extract'); writeProfile(); try { sh('docker', d.concat(['osrm-extract', '-p', PROFILE, '/data/r.osm.pbf'])); } catch (e) { if (PROFILE === '/opt/car.lua') throw e; log('motorway-free profile failed, standard profile used:', String(e && e.message || e).slice(0, 160)); sh('docker', d.concat(['osrm-extract', '-p', '/opt/car.lua', '/data/r.osm.pbf'])); }
  fs.rmSync(path.join(WORK, 'r.osm.pbf'), { force: true });
  log('osrm-partition'); sh('docker', d.concat(['osrm-partition', '/data/r.osrm']));
  log('osrm-customize'); sh('docker', d.concat(['osrm-customize', '/data/r.osrm']));
  try { execFileSync('docker', ['rm', '-f', 'csosrm'], { stdio: 'ignore' }); } catch (e) {}
  sh('docker', ['run', '-d', '--name', 'csosrm', '-p', '127.0.0.1:5000:5000', '-v', WORK + ':/data', IMAGE, 'osrm-routed', '--algorithm', 'mld', '--max-viaroute-size', '1000', '/data/r.osrm']);
  for (let k = 0; k < 120; k++) { try { const r = await fetch('http://127.0.0.1:5000/route/v1/driving/0,0;0.001,0.001'); if (r.status) break; } catch (e) {} await new Promise(r => setTimeout(r, 1000)); }
  return { url: 'http://127.0.0.1:5000' };
}
function stopRouter() { try { execFileSync('docker', ['rm', '-f', 'csosrm'], { stdio: 'ignore' }); } catch (e) {} fs.rmSync(WORK, { recursive: true, force: true }); }

async function routeOne(base, ride) {
  const [id, wpsAll, km] = ride; let wps = wpsAll; let r = null;
  for (let tries = 0; ; tries++) {
    const coords = wps.map(p => (+p[1]).toFixed(5) + ',' + (+p[0]).toFixed(5)).join(';');
    const pr = EXCLS.length ? await preferred(base, coords) : null; if (pr) { r = pr; break; }
    r = await fetch(base + '/route/v1/driving/' + coords + '?overview=full&geometries=polyline&steps=true');
    if (r.ok || !RETRY || r.status !== 400 || tries >= 3) break;
    /* "Could not find a matching segment for coordinate N": route without that checkpoint (never the first or last) */
    let msg = ''; try { msg = (await r.json()).message || ''; } catch (e) {}
    const m = msg.match(/coordinate (\d+)/); const k = m ? +m[1] : -1;
    if (k <= 0 || k >= wps.length - 1) break;
    wps = wps.filter((_, i) => i !== k);
  }
  if (!r.ok) return { id, err: 'http ' + r.status };
  const js = await r.json(); const rt = js && js.routes && js.routes[0];
  if (!rt || !rt.geometry) return { id, err: js && js.code || 'no route' };
  const line = decode(rt.geometry); if (line.length < 2) return { id, err: 'empty' };
  const rkm = (+rt.distance || 0) / 1000;
  /* a road that is far longer or shorter than the ride says is not this ride: kept out, listed */
  const nw = NEW.get(id);
  if (nw && nw.tk && (rkm < nw.tk[0] * 0.6 || rkm > nw.tk[1] * 1.6)) return { id, err: 'length ' + Math.round(rkm) + ' km outside ' + nw.tk.join('-') + ' km' };
  if (!nw && km && (rkm > km * 2.3 + 20 || rkm < km * 0.45)) return { id, err: 'length ' + Math.round(rkm) + ' km vs ' + km + ' km' };
  const ENDS = RETRY ? 15 : 8;
  if (hav(line[0], wps[0]) > ENDS || hav(line[line.length - 1], wps[wps.length - 1]) > ENDS) return { id, err: 'ends do not match' };
  const s = simplify(line, 12);
  /* r36+ (owner 2026-11-07: "full functionality, no sign-up, no legal risk"): every turn of the ride, from this own router,
     so the navigator guides turn by turn on the ride from the site's files - [metres along, type, modifier, road, exit] */
  const T = { depart: 0, turn: 1, 'new name': 2, continue: 3, merge: 4, 'on ramp': 5, 'off ramp': 6, fork: 7, 'end of road': 8, roundabout: 9, rotary: 9, 'roundabout turn': 9, 'exit roundabout': 10, 'exit rotary': 10, arrive: 11, notification: 12 };
  const MOD = { uturn: 0, 'sharp right': 1, right: 2, 'slight right': 3, straight: 4, 'slight left': 5, left: 6, 'sharp left': 7 };
  const steps = []; let at = 0; const legs = rt.legs || [];
  legs.forEach((leg, li) => (leg.steps || []).forEach(st => { const m = st.maneuver || {}, t = T[m.type]; if (t == null) { at += +st.distance || 0; return; }
    if ((t === 0 && li > 0) || (t === 11 && li < legs.length - 1)) { if (t === 11) steps.push([Math.round(at), 13, MOD[m.modifier] ?? 4, '', 0, li]); at += +st.distance || 0; return; }
    if (t === 2 && !(st.name || st.ref)) { at += +st.distance || 0; return; }
    steps.push([Math.round(at), t, MOD[m.modifier] ?? 4, String(st.ref && !st.name ? st.ref : st.name || '').slice(0, 60), +m.exit || 0]); at += +st.distance || 0; }));
  return { id, cell: cellOf(wpsAll[0][0], wpsAll[0][1]), v: [encode(s), Math.round(rkm), Math.round((+rt.duration || 0) / 60), wpsAll.length], steps };
}
async function routeAll(base, list, regId) {
  let ok = 0, bad = 0, n = 0; const fails = [], retry = new Set();
  const q = list.slice(), tried = new Set(); const work = async () => { for (;;) { if (Date.now() > DEADLINE) { STOPPED = true; return; } const r = q.shift(); if (!r) return; n++; tried.add(r[0]);
    try { const x = await routeOne(base, r); if (x.err) { bad++; fails.push(x.id + ': ' + x.err); if (NEW.has(x.id) && !/^http 5/.test(x.err)) newOut.refused[x.id.slice(4)] = x.err; if (/^http 5/.test(x.err)) retry.add(x.id); } else if (NEW.has(x.id)) { const nw = NEW.get(x.id), c = nw.c; newOut.rides[c.id] = { id: c.id, title: c.title, road: c.road || '', cc: c.cc || '', region: c.region || '', kind: c.kind || '', tags: c.tags || '', sources: c.sources || '', wps: nw.wps, poly: x.v[0], km: x.v[1], min: x.v[2], routed: new Date().toISOString().slice(0, 10) }; ok++; }
      else { cellGet(x.cell).roads[x.id] = x.v; stepsGet(x.cell).steps[x.id] = x.steps || []; ok++; } } catch (e) { bad++; fails.push(r[0] + ': ' + e.message); retry.add(r[0]); }
    if (n % 200 === 0) log(regId, n + '/' + list.length, 'routed', ok, 'refused', bad); } };
  await Promise.all(Array.from({ length: PAR }, work));
  return { ok, bad, fails, retry, tried };
}
let LASTPUSH = 0;
/* r55: always push to main by name - a run started by a release is checked out on the tag (no branch), where a plain push fails */
const BR = opt('branch', 'main');
function pushMain() { try { sh('git', ['-C', OUT, 'pull', '-q', '--rebase', 'origin', BR]); } catch (e) {} sh('git', ['-C', OUT, 'push', '-q', 'origin', 'HEAD:refs/heads/' + BR]); }
function commit(msg, force) {
  if (!PUSH) return;
  try { /* r55: one pathspec for the whole roads folder - a glob that matches no file made 'git add' fail and nothing was pushed */ sh('git', ['-C', OUT, 'add', '-A', '--', '.']); if (NET && fs.existsSync(NETDIR)) sh('git', ['-C', NETDIR, 'add', '-A', '--', '.']); for (const f of ['new-rides.json', 'roads-ingest-geocode.json']) if (fs.existsSync(path.join(OUT, f))) sh('git', ['-C', OUT, 'add', '--', f]);
    const st = execFileSync('git', ['-C', OUT, 'status', '--porcelain'], { encoding: 'utf8' }); if (!st.trim()) { if (force) { try { pushMain(); } catch (e) {} } return; }
    /* r53: GitHub history - one commit per push, at most every 2 hours (files are written in between, nothing is lost) */
    if (!force && Date.now() - LASTPUSH < 120 * 60000) { log('saved on disk - committed and pushed with the next 2-hourly push'); return; }
    sh('git', ['-C', OUT, 'commit', '-q', '-m', msg]);
    /* the owner may have uploaded a release in the meantime: take it first, then push (roads files never clash with it) */
    /* r46 GitHub rule: every push rebuilds the Pages site - push at most every 30 minutes (and at the end), commits are kept locally in between */
    pushMain(); LASTPUSH = Date.now(); } catch (e) { log('commit/push failed - the files are written; push again later with: git push'); }
}

/* ---- run ---- */
if (QUEUE && !opt('no-ingest', false)) {
  const q = readJson(QUEUE); const core = (q.core || []).filter(c => c && c.id && c.waypoint_names);
  const gfile = path.join(OUT, 'roads-ingest-geocode.json'); const G = (() => { try { return JSON.parse(fs.readFileSync(gfile, 'utf8')); } catch (e) { return {}; } })();
  const GEO = opt('geocoder', 'https://nominatim.openstreetmap.org');
  let asked = 0;
  for (const c of core) {
    if (newOut.rides[c.id] || newOut.refused[c.id]) continue;
    const names = String(c.waypoint_names).split(';').map(x => x.trim()).filter(Boolean); const pts = [];
    for (const n of names) {
      const k = (c.cc || '') + '|' + n;
      if (!(k in G)) {
        if (/^https?:/.test(GEO)) { await new Promise(r => setTimeout(r, 1100)); asked++; }
        try { const u = GEO + '/search?format=json&limit=1&q=' + encodeURIComponent(n + (c.region ? ', ' + String(c.region).split(' - ').pop() : '')) + (c.cc ? '&countrycodes=' + String(c.cc).toLowerCase() : '');
          const r = await fetch(u, { headers: { 'User-Agent': 'CurveScout route catalogue (https://curvescout.com)', Accept: 'application/json' } }); const j = r.ok ? await r.json() : [];
          G[k] = j && j[0] ? [+(+j[0].lat).toFixed(5), +(+j[0].lon).toFixed(5)] : null; } catch (e) { G[k] = null; }
        if (asked % 20 === 0) fs.writeFileSync(gfile, JSON.stringify(G)); }
      if (G[k]) pts.push([G[k][0], G[k][1], n]);
    }
    fs.writeFileSync(gfile, JSON.stringify(G));
    /* places that were not found, or that lie far from the others, are dropped; fewer than three left is not a ride */
    const centre = pts.length ? [pts.reduce((a, p) => a + p[0], 0) / pts.length, pts.reduce((a, p) => a + p[1], 0) / pts.length] : null;
    const good = pts.filter(p => centre && hav(p, centre) < 250);
    if (good.length < 3) { newOut.refused[c.id] = 'only ' + good.length + ' of ' + names.length + ' places found'; continue; }
    if (/\bloop\b/.test(String(c.tags || '')) && hav(good[0], good[good.length - 1]) > 5) good.push(good[0]);
    const tk = Array.isArray(c.target_km) ? c.target_km : null;
    NEW.set('new:' + c.id, { c, wps: good, tk });
    rides.push(['new:' + c.id, good.map(p => [p[0], p[1]]), tk ? Math.round((tk[0] + tk[1]) / 2) : 0]);
  }
  fs.writeFileSync(newFile, JSON.stringify(newOut, null, 1));
  log('queued concepts to route as new rides:', NEW.size, '(' + Object.keys(newOut.rides).length + ' already done, ' + Object.keys(newOut.refused).length + ' refused)');
}

const regs = await regions();
/* r36+: a ride routed before turn steps were kept is routed again once (prog.done2) */
prog.done2 = prog.done2 || {};
const todo = RETRY ? [] : rides.filter(r => !prog.done2[r[0]]);
if (RETRY) { prog.done3 = prog.done3 || {}; prog.clipFail = prog.clipFail || {}; prog.retried = prog.retried || {};
  for (const r of rides) if (!prog.retried[r[0]]) { delete prog.done3[r[0]]; delete prog.clipFail[r[0]]; prog.retried[r[0]] = 1; }
  if (!prog.retryStarted) { for (const k of Object.keys(prog.tries || {})) if (k.startsWith('clip:')) delete prog.tries[k]; prog.retryStarted = 1; } }
const { by, none } = await assign(regs, todo);
let order = [...by.values()].sort((a, b) => (a.regs.length - b.regs.length) || (b.rides.length - a.rides.length));
if (ONLY.length) order = order.filter(x => x.regs.some(g => ONLY.includes(g.id)));
log(order.length + ' router builds planned (' + order.filter(x => x.regs.length === 1).length + ' single regions, ' + order.filter(x => x.regs.length > 1).length + ' border crossings), ' + todo.length + ' rides not yet done, ' + none.length + ' rides fit no region');
if (PLAN) { for (const x of order) console.log(String(x.rides.length).padStart(6), x.key); process.exit(0); }
prog.tries = prog.tries || {};
for (let gi = 0; gi < order.length; gi++) { const x = order[gi];
  /* r54: a region needs about an hour to build; with less time left the next run takes it */
  if (!ROUTER && Date.now() > DEADLINE - 75 * 60000) { STOPPED = true; log('time limit near - the next run carries on with', x.key); break; }
  if (Date.now() > DEADLINE) { STOPPED = true; break; }
  /* r54: a region that already used up two runs without finishing is set aside (no endless loop) */
  /* r56: a region build that already failed (too large, out of memory, too slow) is not tried again - the second pass cuts small boxes instead */
  if (!ROUTER && typeof prog.failed[x.key] === 'string' && /^(too large|too slow|Command failed)/.test(prog.failed[x.key])) { log(x.key, 'left to the second pass (' + prog.failed[x.key].slice(0, 40) + ')'); for (const r of x.rides) prog.done[r[0]] = prog.done2[r[0]] = 1; continue; }
  if (!ROUTER && (prog.tries[x.key] || 0) >= 2) { log(x.key, 'did not finish in two runs - left to the live router'); prog.failed[x.key] = 'too slow for this machine'; for (const r of x.rides) prog.done[r[0]] = prog.done2[r[0]] = 1; flush(); continue; }
  if (!ROUTER) { prog.tries[x.key] = (prog.tries[x.key] || 0) + 1; flush(); commit('Roads: starting ' + x.key, false); }
  log('== ' + (gi + 1) + '/' + order.length, x.key, x.rides.length, 'rides');
  let base = ROUTER;
  if (!base) { const st = await startRouter(x).catch(e => ({ err: e.message }));
    if (st.tooBig) { log(st.reg.id, 'is ' + Math.round(st.tooBig / 1048576) + ' MB - its rides go to its sub-regions'); prog.tooBig = [...new Set((prog.tooBig || []).concat(st.reg.id))]; flush();
      const sub = await assign(regs, x.rides); for (const y of sub.by.values()) { const e = order.slice(gi + 1).find(z => z.key === y.key); if (e) e.rides.push(...y.rides); else order.push(y); } stopRouter(); continue; }
    if (st.tooLarge) { log(x.key, 'together are too large for this machine - left to the live router'); prog.failed[x.key] = 'too large together'; flush(); stopRouter(); continue; }
    if (st.err) { log('router failed for', x.key, st.err); prog.failed[x.key] = st.err; flush(); stopRouter(); continue; }
    base = st.url; }
  const res = await routeAll(base, x.rides, x.key);
  for (const r of x.rides) if (res.tried.has(r[0]) && !res.retry.has(r[0])) { prog.done[r[0]] = 1; prog.done2[r[0]] = 1; }
  if (!STOPPED || res.tried.size) delete prog.tries[x.key];   /* a router hiccup is tried again on the next run */
  if (res.fails.length) prog.failed[x.key] = res.fails.slice(0, 200);
  const idx = flush(); cells.clear();
  log(x.key, 'done:', res.ok, 'roads,', res.bad, 'refused · catalogue now', idx.total, 'roads');
  if (NET && !ROUTER) { prog.netDone = prog.netDone || {}; prog.netDone[x.key] = 1; flush(); }
  if (!ROUTER) stopRouter();
  commit('Roads: ' + x.key + ' (' + res.ok + ' rides on their real road)');
  if (STOPPED) break;
}
if (STOPPED) { flush(); commit('Roads: run saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); }
/* r56 second pass - the rides that still have no stored road. Instead of building the router for a whole region (too big for
   a GitHub machine: Italy, Turkey, US state groups...), download the region once, cut a small box around a handful of nearby
   rides (osmium extract) and build the router on that box only. Each box is a few minutes; nothing waits on huge builds.
   Only rides without a stored road are touched, stored roads are never changed. Progress: prog.done3. */
const CLIPMAX = +opt('clip-max', 3500) * 1048576, BOXDEG = +opt('box', RETRY ? 1.2 : 2.2), PAD = +opt('pad', RETRY ? 0.5 : 0.35);
const storedIds = () => { const ids = new Set(); for (const f of fs.readdirSync(OUT)) { const m = f.match(/^roads-(\d+-\d+)\.json(\.gz)?$/); if (!m) continue; const j = readCell(cellFile(m[1]), 'roads'); if (j) for (const k of Object.keys(j.roads || {})) ids.add(k); } return ids; };
function clusters(list) {   /* greedy: rides whose combined box stays within BOXDEG x BOXDEG share one router build */
  const box = r => { const la = r[1].map(p => p[0]), lo = r[1].map(p => p[1]); return [Math.min(...lo), Math.min(...la), Math.max(...lo), Math.max(...la)]; };
  const items = list.map(r => ({ r, b: box(r) })).sort((a, b) => (a.b[0] + a.b[2]) - (b.b[0] + b.b[2]) || (a.b[1] + a.b[3]) - (b.b[1] + b.b[3]));
  const out = [];
  for (const it of items) { let best = null;
    for (const c of out) { const u = [Math.min(c.b[0], it.b[0]), Math.min(c.b[1], it.b[1]), Math.max(c.b[2], it.b[2]), Math.max(c.b[3], it.b[3])];
      if (u[2] - u[0] <= BOXDEG && u[3] - u[1] <= BOXDEG) { best = c; best.u = u; break; } }
    if (best) { best.b = best.u; best.rides.push(it.r); } else out.push({ b: it.b.slice(), rides: [it.r] }); }
  return out.map(c => ({ rides: c.rides, bbox: [c.b[0] - PAD, c.b[1] - PAD, c.b[2] + PAD, c.b[3] + PAD].map(v => Math.round(v * 1e4) / 1e4) }));
}
async function clipAssign(regs, list) {   /* the SMALLEST region holding every checkpoint and small enough to download */
  const by = new Map(), none = []; const sorted = regs.slice().sort((a, b) => a.area - b.area);
  const inBox = (p, g) => p[1] >= g.bbox[0] && p[1] <= g.bbox[2] && p[0] >= g.bbox[1] && p[0] <= g.bbox[3];
  for (const r of list) { const pts = (r[1] || []).map(p => [p[0], p[1]]); if (pts.length < 2) { none.push(r[0]); continue; }
    let pick = null; for (const g of sorted) { if (!pts.every(p => inBox(p, g)) || !pts.every(p => inGeom(p, g.geom))) continue; const n = await sizeOf(g); if (n > 0 && n <= CLIPMAX) { pick = g; break; } }
    let set = pick ? [pick] : [];
    if (!pick) { for (const p of pts) { let g = null; for (const h of sorted) { if (inBox(p, h) && inGeom(p, h.geom)) { const n = await sizeOf(h); if (n > 0 && n <= CLIPMAX) { g = h; break; } } } if (!g) { set = null; break; } if (!set.includes(g)) set.push(g); }
      if (set && (set.length > 3 || set.reduce((a, g) => a + (prog.sizes[g.id] || 0), 0) > CLIPMAX * 1.5)) set = null; }
    if (!set) { none.push(r[0]); continue; }
    set.sort((a, b) => a.id.localeCompare(b.id)); const key = set.map(g => g.id).join('+'); if (!by.has(key)) by.set(key, { key, regs: set, rides: [] }); by.get(key).rides.push(r); }
  return { by, none };
}
async function buildOn(pbf, bbox) {   /* cut the box out of the downloaded region and start the router on it */
  for (const f of fs.readdirSync(WORK)) if (/^c\./.test(f)) fs.rmSync(path.join(WORK, f), { force: true });
  const b = bbox.join(','), out = path.join(WORK, 'c.osm.pbf');
  try { execFileSync('osmium', ['--version'], { stdio: 'ignore' }); sh('osmium', ['extract', '-b', b, '-s', 'smart', '--overwrite', pbf, '-o', out]); }
  catch (e) { sh('docker', ['run', '--rm', '-v', WORK + ':/data', OSMIUM, 'extract', '-b', b, '-s', 'smart', '--overwrite', '/data/' + path.basename(pbf), '-o', '/data/c.osm.pbf']); }
  const d = ['run', '--rm', '-v', WORK + ':/data', IMAGE];
  writeProfile(); try { sh('docker', d.concat(['osrm-extract', '-p', PROFILE, '/data/c.osm.pbf'])); } catch (e) { if (PROFILE === '/opt/car.lua') throw e; log('motorway-free profile failed, standard profile used:', String(e && e.message || e).slice(0, 160)); sh('docker', d.concat(['osrm-extract', '-p', '/opt/car.lua', '/data/c.osm.pbf'])); } fs.rmSync(out, { force: true });
  sh('docker', d.concat(['osrm-partition', '/data/c.osrm'])); sh('docker', d.concat(['osrm-customize', '/data/c.osrm']));
  try { execFileSync('docker', ['rm', '-f', 'csosrm'], { stdio: 'ignore' }); } catch (e) {}
  sh('docker', ['run', '-d', '--name', 'csosrm', '-p', '127.0.0.1:5000:5000', '-v', WORK + ':/data', IMAGE, 'osrm-routed', '--algorithm', 'mld', '--max-viaroute-size', '1000', '/data/c.osrm']);
  for (let k = 0; k < 120; k++) { try { const r = await fetch('http://127.0.0.1:5000/route/v1/driving/0,0;0.001,0.001'); if (r.status) break; } catch (e) {} await new Promise(r => setTimeout(r, 1000)); }
  return 'http://127.0.0.1:5000';
}
if (!PLAN && !opt('no-clip', false)) {
  prog.done3 = prog.done3 || {}; prog.clipFail = prog.clipFail || {};
  const have = storedIds(); const todo3 = rides.filter(r => !have.has(r[0]) && !prog.done3[r[0]]);
  log('second pass: ' + todo3.length + ' rides without a stored road - routed in small boxes cut from their region');
  if (todo3.length && !ROUTER) { try { execFileSync('sudo', ['-n', 'rm', '-rf', '/usr/share/dotnet', '/usr/local/lib/android', '/opt/ghc', '/opt/hostedtoolcache/CodeQL', '/usr/local/share/boost'], { stdio: 'ignore' }); } catch (e) {} }
  const { by: by3, none: none3 } = await clipAssign(regs, todo3);
  for (const id of none3) { prog.done3[id] = 1; prog.clipFail[id] = 'no downloadable region holds it'; }
  const groups = [...by3.values()].sort((a, b) => b.rides.length - a.rides.length);
  for (const x of groups) {
    if (Date.now() > DEADLINE - 30 * 60000) { STOPPED = true; log('time limit near - the next run carries on with', x.key); break; }
    const tk = 'clip:' + x.key; prog.tries[tk] = (prog.tries[tk] || 0) + 1;
    if (!ROUTER && prog.tries[tk] > 3) { log(x.key, 'did not finish in three runs - left to the live router'); for (const r of x.rides) { prog.done3[r[0]] = 1; prog.clipFail[r[0]] = 'region too slow'; } flush(); continue; }
    flush();
    let pbf = null;
    if (!ROUTER) { try { fs.rmSync(WORK, { recursive: true, force: true }); fs.mkdirSync(WORK, { recursive: true }); const files = [];
        for (const [k, reg] of x.regs.entries()) { log('downloading', reg.id, Math.round((prog.sizes[reg.id] || 0) / 1048576) + ' MB'); const f = path.join(WORK, 'p' + k + '.osm.pbf'); sh('curl', ['-fsSL', '--retry', '3', '-o', f, reg.pbf]); files.push(f); }
        pbf = path.join(WORK, 'r.osm.pbf'); if (files.length === 1) fs.renameSync(files[0], pbf); else { osmiumMerge(files, pbf); files.forEach(f => fs.rmSync(f, { force: true })); }
      } catch (e) { log('download failed for', x.key, String(e.message || e).slice(0, 160)); stopRouter(); continue; } }
    const boxes = clusters(x.rides); log('== ' + x.key + ': ' + x.rides.length + ' rides in ' + boxes.length + ' boxes');
    let ok = 0, bad = 0;
    for (const c of boxes) {
      if (Date.now() > DEADLINE - 15 * 60000) { STOPPED = true; break; }
      let base = ROUTER;
      if (!ROUTER) { try { base = await buildOn(pbf, c.bbox); } catch (e) { log('box failed', c.bbox.join(','), String(e.message || e).slice(0, 120)); for (const r of c.rides) { prog.done3[r[0]] = 1; prog.clipFail[r[0]] = 'box build failed'; } continue; } }
      const res = await routeAll(base, c.rides, x.key);
      for (const r of c.rides) if (res.tried.has(r[0]) && !res.retry.has(r[0])) prog.done3[r[0]] = 1;
      for (const f of res.fails) { const i = f.indexOf(': '); prog.clipFail[f.slice(0, i)] = f.slice(i + 2); }
      ok += res.ok; bad += res.bad;
      if (!ROUTER) { try { execFileSync('docker', ['rm', '-f', 'csosrm'], { stdio: 'ignore' }); } catch (e) {} }
      if (STOPPED) break;
    }
    if (!STOPPED) delete prog.tries[tk];
    const idx = flush(); cells.clear(); if (!ROUTER) stopRouter();
    log(x.key, 'second pass:', ok, 'new roads,', bad, 'refused · catalogue now', idx.total, 'roads');
    commit('Roads: ' + x.key + ' second pass (' + ok + ' rides on their real road)');
    if (STOPPED) break;
  }
  if (STOPPED) { flush(); commit('Roads: run saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); }
}
/* r42: regions whose rides were routed before the phone network existed get their network now (download + export only) */
if (NET && !ROUTER && !PLAN) { prog.netDone = prog.netDone || {};
  const all = await assign(regs, rides); const later = [...all.by.values()].filter(x => x.regs.length === 1 && !prog.netDone[x.key]).sort((a, b) => b.rides.length - a.rides.length);
  log(later.length + ' regions still need their road network for the phone');
  for (const x of later) { try { fs.rmSync(WORK, { recursive: true, force: true }); fs.mkdirSync(WORK, { recursive: true }); const reg = x.regs[0];
      log('network', x.key); sh('curl', ['-fL', '--retry', '3', '-o', path.join(WORK, 'r.osm.pbf'), reg.pbf]);
      const dm = ['run', '--rm', '-v', WORK + ':/data', OSMIUM];
      sh('docker', dm.concat(['tags-filter', '--overwrite', '/data/r.osm.pbf', 'w/highway=' + NETX.CLASSES.join(','), '-o', '/data/hw.osm.pbf']));
      sh('docker', dm.concat(['export', '--overwrite', '/data/hw.osm.pbf', '-f', 'geojsonseq', '--geometry-types=linestring', '-o', '/data/hw.geojsonseq']));
      await NETX.exportNet(path.join(WORK, 'hw.geojsonseq'), NETDIR, log); prog.netDone[x.key] = 1; flush(); commit('Network: ' + x.key + ' (roads for routing on the phone)');
    } catch (e) { log('network failed for', x.key, String(e && e.message || e).slice(0, 160)); } finally { fs.rmSync(WORK, { recursive: true, force: true }); } } }
/* r60: a height profile for every stored road (Terrain Tiles on AWS), before the job may call itself finished */
if (!PLAN && !opt('no-heights', false) && !INJ.noHeights && !ROUTER) { const HT = await import(new URL('./road-heights.mjs', import.meta.url));
  const allDone = await HT.run(OUT, DEADLINE, log);
  if (!allDone) { flush(); commit('Roads: heights saved (time limit - the next run carries on)', true); log('stopped at the time limit - everything is saved; the next run carries on.'); process.exit(0); } }
commit('Roads: finished run', true);
const idx = flush(); log('finished.', idx.total, 'roads in', Object.keys(idx.cells).length, 'cells.', none.length, 'rides fit no region (they keep the live router).');
commit('Roads: catalogue index');
