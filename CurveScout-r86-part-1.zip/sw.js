/* CurveScout service worker - the road is where the signal isn't.
   App files: network first, cached copy offline. Pictures and libraries: cache-first.
   Ride shards: cached the moment a ride is opened, so it stays readable with no bars.
   Tiles / live APIs: never cached here (they go stale and they're big). */
/* r34 audit CS-R34-008: every release cache is named curvescout-app-<build>, and cleanup recognises exactly that family
   (plus the two older namings) - a later release can never leave this one behind, and code is only ever read from the
   current release's own cache (no global caches.match that could hand out an old app.js). */
const V = 'curvescout-app-r86-20261123';
const OWN_RELEASE = k => /^curvescout-app-[\w.-]+$/.test(k) || /^curvescout-[0-9a-f]{6,}$/.test(k) || /^curvescout-r\d+-\d{8}$/.test(k);
const fromV = (req) => caches.open(V).then(c => c.match(req));
/* ---- AN UPDATE MUST NOT TAKE A RIDER'S ROUTES ----
   Route data was cached in the same versioned cache as the shell, and activation deletes every
   cache but the new version - so each app update silently wiped the routes a rider had taken
   offline. Route data now lives in its own cache, which activation never touches; only the
   rider's own "Erase everything" clears it. V is stamped with the build when the site is
   assembled, so every release really is a new version. */
const ROUTES = 'curvescout-routes';
const MAP = 'curvescout-map', MAPMAX = 2500;
/* only map files the rider chose to keep go through here; everything else goes straight to the network as before */
let MAPKEEP = false; const MAPSET = new Set();
caches.open(MAP).then(c => c.keys()).then(k => k.forEach(r => MAPSET.add(r.url))).catch(() => {});
self.addEventListener('message', ev => { if (ev.data && 'csMapKeep' in ev.data) MAPKEEP = !!ev.data.csMapKeep; });
function csMapStore(req, res) {
  if (!res || !(res.ok || res.type === 'opaque')) return; const copy = res.clone(); MAPSET.add(req.url);
  caches.open(MAP).then(c => c.put(req, copy).then(() => c.keys()).then(k => { if (k.length > MAPMAX) return Promise.all(k.slice(0, k.length - MAPMAX).map(x => { MAPSET.delete(x.url); return c.delete(x); })); })).catch(() => {});
}
function csMapFetch(req) {
  const net = new Promise((ok, no) => { const t = setTimeout(() => no(new Error('slow')), 6000); fetch(req).then(r => { clearTimeout(t); ok(r); }, e => { clearTimeout(t); no(e); }); });
  return net.then(res => { csMapStore(req, res); return res; })
    .catch(() => caches.open(MAP).then(c => c.match(req)).then(hit => hit || Response.error()));
}
/* ---- THE WORKER WAS DOWNLOADING THE INDEX A SECOND TIME ----
   Measured on a cold load: 23.8 MB fetched, of which 21.6 MB was data/summary.json twice.
   The page asks for it because it needs it now; the worker asked for it again during
   install, in parallel, for offline use. Same ten megabytes, same second, twice over a
   phone connection.
   The shell is the small things a page cannot start without. The index is added to the
   cache when the page's own copy arrives - see the message handler below - so offline still
   works and nobody pays for it twice. */
const SHELL = [
  './', './index.html', './styles.css', './app.js', './config.js', './manifest.webmanifest',
  './assets/phone-route.js', './assets/copilot/copilot-runtime.js',
  './assets/anchor-controller.js', './assets/content-prime.js', './assets/content-prime.css',
  './data/places.json',
  './assets/curvescout-mark-transparent.png', './assets/cerebral-local.svg',
];

/* ---- THE WORKER HOLDS COPIES TOO ----
   "Erase everything" cleared six keys in the page and left every cache this worker had
   opened, including saved routes a rider had deliberately taken offline. The page asks; the
   worker empties itself and says nothing more about it. */
self.addEventListener('message', e => {
  if (!e.data || e.data.type !== 'erase-all') return;
  e.waitUntil(caches.keys().then(names => Promise.all(names.map(n => caches.delete(n)))));
});

/* the page hands over what it has already downloaded; we store it rather than re-fetch it */
self.addEventListener('message', e => {
  const d = e.data || {};
  if (d.type !== 'cache-index' || !d.url || typeof d.body !== 'string') return;
  e.waitUntil(caches.open(V).then(c => c.put(new Request(d.url),
    new Response(d.body, { headers: { 'content-type': 'application/json' } }))));
});

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(V)
      .then(async c => {
        await Promise.allSettled(SHELL.map(u => c.add(u)));
        const required = ['./index.html', './styles.css', './app.js', './config.js', './assets/phone-route.js', './assets/copilot/copilot-runtime.js'];
        const present = await Promise.all(required.map(u => c.match(u)));
        if (present.some(r => !r || !r.ok)) throw new Error('Incomplete application shell; update not activated');
      })
      .then(() => self.skipWaiting())
  );
});

/* ---- A NEW RELEASE MUST REACH A PAGE THAT IS ALREADY OPEN (owner 2026-10-12) ----
   A browser that had visited the old site kept running the old app from this cache: a shared trip link opened the start
   page (the old app has no trips) and back left the trip. When this worker replaces an older CurveScout release it asks
   every open page who it is. A page running this app or newer answers and decides itself (it switches at once if it was
   just opened, otherwise on the rider's next tap, so nothing typed is lost). A page that does not answer is an older app
   that cannot update itself: it is reloaded once, at the same address, so the link the rider tapped opens in the new
   app. A first install reloads nothing; the map library's own tile cache does not count as an older release. */
const ACKS = new Set();
self.addEventListener('message', e => { if (e.data && e.data.type === 'cs-ack' && e.source) ACKS.add(e.source.id); });
self.addEventListener('activate', e => {
  let upgrade = 0;
  e.waitUntil(
    caches.keys()
      /* ---- ONLY OLD COPIES OF THIS APP ARE REMOVED (r30 audit: an update deleted a ride saved for offline and an
         unrelated cache too) ----
         Removed: earlier app versions (curvescout-<build>) and nothing else - not the saved routes, not the studio voice
         (92 MB the rider chose to download), not the map library's tiles. Before an old version goes, any ride data it
         still holds (older releases saved rides there) is moved into the routes cache, so nothing saved is lost. */
      .then(keys => { const old = keys.filter(k => k !== V && k !== ROUTES && OWN_RELEASE(k));
        upgrade = old.length;
        /* r31 audit (CS-R31-009): copy, then VERIFY every copy, and only then delete. Any failure - a full disk, an
           unreadable entry, a copy that is not there afterwards - keeps the old cache: it may be the only complete copy. */
        return Promise.all(old.map(k => caches.open(k).then(c => c.keys().then(reqs => {
          const data = reqs.filter(r => /\/data\/|\/data__/.test(r.url));
          return caches.open(ROUTES).then(rc => Promise.all(data.map(r => rc.match(r).then(have => have ? true
              : c.match(r).then(res => { if (!res) throw new Error('unreadable ' + r.url); return rc.put(r, res); }))))
            .then(() => Promise.all(data.map(r => rc.match(r)))))
            .then(found => { if (found.some(x => !x)) throw new Error('copy missing'); return caches.delete(k); });
        })).catch(() => { upgrade = Math.max(0, upgrade - 1); return null; }))); })
      .then(() => self.clients.claim())
      /* the hand-over to open pages runs AFTER activation, never inside it: a page reload inside waitUntil held the
         worker in "activating", and every request of every page waited behind it (found in testing, 2026-10-12) */
      .then(() => { if (upgrade) setTimeout(handOver, 0); })
  );
});
function handOver() {
  self.clients.matchAll({ type: 'window' }).then(cs => {
    cs.forEach(c => { try { c.postMessage({ type: 'cs-release', v: V }); } catch (err) {} });
    /* Never force-reload an unresponsive page: it may be navigating or hold unsaved edits.
       Current clients acknowledge and defer their own update while riding. */
  });
}

/* Changed content records: ask the server first, without deleting saved offline data. */
async function csPrimeContentFetch(req) {
  const cache = await caches.open(ROUTES);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(req, {cache:'no-cache',signal:controller.signal});
    if (response && response.ok) {
      try { await cache.put(req, response.clone()); } catch (_) { /* Quota does not discard a usable response. */ }
      return response;
    }
    return (await cache.match(req)) || response || Response.error();
  } catch (_) {
    return (await cache.match(req)) || Response.error();
  } finally { clearTimeout(timer); }
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  /* r59 OFFLINE MAP: map tiles, the map style, its fonts and icons from OpenFreeMap are asked from the network first,
     exactly as before; a copy of what the rider has already seen is kept (at most MAPMAX files, oldest out first), and
     it is what the map shows when there are no bars. "Keep the map offline" on a ride flies the map along the ride
     once, so the whole route has been seen. Nothing is downloaded that the rider's own map did not ask for. Only while
     that runs (csMapKeep) and for map files already kept does the worker step in; all other map traffic is untouched. */
  if (url.hostname === 'tiles.openfreemap.org' && (MAPKEEP || MAPSET.has(req.url))) { e.respondWith(csMapFetch(req)); return; }
  if (url.origin !== location.origin) return; // weather, wiki, overpass: straight to network

  if (/\/data\/(?:ride\/|routes\/|derived\/|index\/)/.test(url.pathname) || /\/data\/derived-index\.json(?:\.gz)?$/.test(url.pathname)) {
    e.respondWith(csPrimeContentFetch(req)); return;
  }

  /* ---- STALE-WHILE-REVALIDATE, NOT FETCH-TWICE ----
     This started a network refresh on every request, including a cache MISS - so the very
     first load of data/summary.json went out twice in the same second: once because the
     page needed it, once "in the background" to refresh a copy that did not exist yet.
     Measured on a cold load: 23.8 MB fetched, 21.6 MB of it that one file, doubled.
     On a hit, serve the cache and refresh behind it. On a miss, fetch once and keep it. */
  /* the folder-free site names data files data__… (audit 2026-10-11: route data landed in the per-release cache) */
  /* the GitHub build stores every file without folders, so ride data is any .json at the top level (not the manifest) */
  if (url.pathname.includes('/data/') || /\/data__/.test(url.pathname) || (/\.json(\.gz)?$/.test(url.pathname) && !/\/(release-manifest|manifest)\.json(?:\.gz)?$/.test(url.pathname))) {
    /* r66: the server first, always (see csPrimeContentFetch) - the saved copy only without network */
    e.respondWith(csPrimeContentFetch(req));
    return;
  }

  /* ---- THE APP ITSELF COMES FROM THE NETWORK FIRST ----
     Cache-first kept a phone on the old app after every release, until a second reload. The page and the files that
     make the app (index, app.js, styles, config, the mapper) are now asked from the network first, with the cached copy
     as the offline fallback and after 4 s of no answer. Pictures and the map library stay cache-first. */
  const shellFile = req.mode === 'navigate' || /\/release-manifest\.json(?:\.gz)?$/.test(url.pathname) || /\/(index\.html|app\.js|styles\.css|config\.js|sw\.js)?$/.test(url.pathname);
  if (shellFile) {
    e.respondWith(new Promise(resolve => {
      let done = false;
      const fromCache = () => fromV(req).then(h => h || (req.mode === 'navigate' ? fromV(new Request('./index.html')) : null));
      const t = setTimeout(() => fromCache().then(h => { if (h && !done) { done = true; resolve(h); } }), 4000);
      /* cache: 'no-cache' asks the server whether the file changed - GitHub Pages lets browsers keep files 10 minutes,
         which paired a new page with the old app.js */
      fetch(req, { cache: 'no-cache' }).then(res => {
        if (res && res.status >= 500) { fromCache().then(h => { if (!done) { done = true; clearTimeout(t); resolve(h || res); } }); return; }   /* r84: a passing server error never replaces the working app */
        if (res && res.ok && res.type === 'basic') { const copy = res.clone(); caches.open(V).then(c => c.put(req, copy)); }
        if (!done) { done = true; clearTimeout(t); resolve(res); }
      }).catch(() => fromCache().then(h => { if (!done) { done = true; clearTimeout(t); resolve(h || Response.error()); } }));
    }));
    return;
  }

  // Everything else from this site: cache-first with a network fallback.
  e.respondWith(
    fromV(req).then(hit => hit || fetch(req).then(res => {
      if (res && res.ok && (res.type === 'basic')) {
        const copy = res.clone();
        caches.open(V).then(c => c.put(req, copy));
      }
      return res;
    }).catch(() => req.mode === 'navigate' ? fromV(new Request('./index.html')) : Response.error()))
  );
});

// The app asks for specific rides to be stored for a trip.
self.addEventListener('message', e => {
  const d = e.data || {};
  if (d.type !== 'cacheRides' || !Array.isArray(d.urls)) return;
  /* saved rides go to the routes cache, which no update touches (they were in the versioned shell cache before) */
  e.waitUntil(
    caches.open(ROUTES)
      .then(c => Promise.allSettled(d.urls.map(u => c.add(u))))
      .then(rs => {
        /* r48: a ride file may exist plain or compressed (.gz); one of the two counts as stored */
        const base = u => String(u).replace(/\.gz$/, ''), okSet = new Set(d.urls.filter((u, i) => rs[i].status === 'fulfilled').map(base));
        const okCount = okSet.size;
        if (e.source) e.source.postMessage({ type: 'cached', ok: okCount, total: new Set(d.urls.map(base)).size });
      })
  );
});
