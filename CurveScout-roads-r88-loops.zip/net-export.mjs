/* CurveScout road network for routing on the rider's phone (backup when the public OSRM server is not available).
   Input: highway ways exported by osmium as GeoJSON lines (one LineString per way, with its tags).
   Output: one file per 1° square, data/net/net-<lat>_<lon>.json (every file far below 10 MB), and net-index.json.
   Each edge runs from crossing to crossing: [la1, lo1, la2, lo2] (1e-5 degree integers), metres, road class, flags
   (1 one-way, 2 toll, 4 motorway), curviness 0-255, name index, polyline of the points between (precision 5).
   Nodes are identified by their coordinates, so squares join without ids. Data: OpenStreetMap contributors, ODbL. */
import fs from 'node:fs'; import path from 'node:path'; import readline from 'node:readline'; import zlib from 'node:zlib';
/* GitHub Pages keeps a site under 1 GB: files are gzip-compressed (the phone unpacks them), residential streets stay out
   (a destination in town is reached from the nearest through road) and the whole network is capped at CAP_MB. */
export const CAP_MB = 150;   /* r44: the site plus roads plus SEO pages must stay under GitHub Pages' 1 GB */
const gz = o => zlib.gzipSync(JSON.stringify(o), { level: 9 });
const readGz = f => JSON.parse(zlib.gunzipSync(fs.readFileSync(f)).toString('utf8'));
function dirMB(d) { let t = 0; try { for (const f of fs.readdirSync(d)) t += fs.statSync(path.join(d, f)).size; } catch (e) {} return t / 1048576; }
export const CLASSES = ['motorway', 'motorway_link', 'trunk', 'trunk_link', 'primary', 'primary_link', 'secondary', 'secondary_link', 'tertiary', 'tertiary_link', 'unclassified'];
const CLS = Object.fromEntries(CLASSES.map((c, i) => [c, i]));
const R = 6371008.8, rad = Math.PI / 180;
export function hav(a, b) { const dLa = (b[0] - a[0]) * rad, dLo = (b[1] - a[1]) * rad; const s = Math.sin(dLa / 2) ** 2 + Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(s)); }
function enc(pts) { let o = '', pl = 0, pn = 0; const e = v => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const [la, lo] of pts) { o += e(la - pl) + e(lo - pn); pl = la; pn = lo; } return o; }
const q = v => Math.round(v * 1e5);
/* curviness: degrees of heading change per km, scaled to 0-255 */
function curv(pts) { let turn = 0, len = 0; for (let i = 1; i < pts.length; i++) { len += hav(pts[i - 1], pts[i]); if (i > 1) { const h1 = Math.atan2(pts[i - 1][1] - pts[i - 2][1], pts[i - 1][0] - pts[i - 2][0]), h2 = Math.atan2(pts[i][1] - pts[i - 1][1], pts[i][0] - pts[i - 1][0]); let d = Math.abs(h2 - h1); if (d > Math.PI) d = 2 * Math.PI - d; turn += d / rad; } }
  return len > 30 ? Math.min(255, Math.round(turn / (len / 1000) / 4)) : 0; }
function usable(t) { if (!t || !(t.highway in CLS)) return false; if (/^(no|private)$/.test(t.access || '') || /^(no|private)$/.test(t.motor_vehicle || '') || /^(no|private)$/.test(t.motorcycle || '')) return false; if (t.area === 'yes') return false; return true; }
/* geojsonseq lines -> network files. Two passes: count how many ways use each point (a crossing is used twice or more),
   then cut every way at its crossings. */
export async function exportNet(seqFile, outDir, log = () => {}, opt = {}) {   /* r88 opt: { majorsOnly, only: Set of squares, capMB } */
  const lines = async function* () { const rl = readline.createInterface({ input: fs.createReadStream(seqFile), crlfDelay: Infinity }); for await (let l of rl) { l = l.replace(/^\x1e/, '').trim(); if (!l) continue; let f; try { f = JSON.parse(l); } catch (e) { continue; } if (!f.geometry || f.geometry.type !== 'LineString' || !usable(f.properties)) continue; yield f; } };
  const use = new Map(); let ways = 0;
  for await (const f of lines()) { ways++; const c = f.geometry.coordinates; c.forEach((p, i) => { const k = q(p[1]) + ',' + q(p[0]); use.set(k, (use.get(k) || 0) + (i === 0 || i === c.length - 1 ? 2 : 1)); }); }
  log('network: ' + ways + ' ways, ' + use.size + ' points');
  const cells = new Map(), names = new Map(); let edges = 0;
  const cellOf = (la, lo) => Math.floor(la / 1e5) + '_' + Math.floor(lo / 1e5);
  const put = (a, b, mid, t, len, cv) => { const ow = t.oneway === 'yes' || t.oneway === '1' || t.highway === 'motorway' || t.junction === 'roundabout' ? 1 : 0;
    const fl = ow | (t.toll === 'yes' ? 2 : 0) | (/^motorway/.test(t.highway) ? 4 : 0); const nm = t.ref && /^(motorway|trunk)/.test(t.highway) ? t.ref : (t.name || t.ref || '');
    let ni = names.get(nm); if (ni === undefined) { ni = names.size; names.set(nm, ni); }
    const c = cellOf(a[0], a[1]); let C = cells.get(c); if (!C) { C = { e: [], nm: new Map() }; cells.set(c, C); }
    let li = C.nm.get(nm); if (li === undefined) { li = C.nm.size; C.nm.set(nm, li); }
    C.e.push(a[0], a[1], b[0], b[1], Math.round(len), CLS[t.highway], fl, cv, li, enc(mid)); edges++; };
  for await (const f of lines()) { const t = f.properties; let c = f.geometry.coordinates.map(p => [q(p[1]), q(p[0])]); if (t.oneway === '-1') { c = c.reverse(); t.oneway = 'yes'; }
    let start = 0; for (let i = 1; i < c.length; i++) { if (i === c.length - 1 || (use.get(c[i][0] + ',' + c[i][1]) || 0) >= 2) { const seg = c.slice(start, i + 1); const fl = seg.map(p => [p[0] / 1e5, p[1] / 1e5]); let len = 0; for (let k = 1; k < fl.length; k++) len += hav(fl[k - 1], fl[k]);
      if (len > 0) put(seg[0], seg[seg.length - 1], thin(seg.slice(1, -1)), t, len, curv(fl)); start = i; } } }
  fs.mkdirSync(outDir, { recursive: true }); const idxF = path.join(outDir, 'net-index.json'); let idx = { v: 1, cells: {} }; try { idx = JSON.parse(fs.readFileSync(idxF, 'utf8')); } catch (e) {}
  /* r88 majors-only coverage: a square gets (or adds to) its main-road file only; a square with a full file is never touched */
  if (opt.majorsOnly) { let wrote = 0, capped = false;
    for (const [c, C] of cells) { if (opt.only && !opt.only.has(c)) continue; if (fs.existsSync(path.join(outDir, 'net-' + c + '.json.gz'))) continue;
      const f = path.join(outDir, 'netm-' + c + '.json.gz'); let prev = null; try { prev = readGz(f); } catch (e) {}
      if (!prev && dirMB(outDir) > (opt.capMB || CAP_MB)) { capped = true; log('network: size cap reached (' + (opt.capMB || CAP_MB) + ' MB) - ' + c + ' left out'); continue; }
      let nmArr = [...C.nm.keys()], e = []; for (let i = 0; i < C.e.length; i += 10) if (C.e[i + 5] <= 7) for (let k = 0; k < 10; k++) e.push(C.e[i + k]);
      if (prev && prev.e && prev.names) { const seen = new Set(); for (let i = 0; i < e.length; i += 10) seen.add(e.slice(i, i + 4).join(',')); const map = new Map(nmArr.map((n, i) => [n, i]));
        for (let i = 0; i < prev.e.length; i += 10) { if (seen.has(prev.e.slice(i, i + 4).join(','))) continue; const n = prev.names[prev.e[i + 8]] || ''; let li = map.get(n); if (li === undefined) { li = nmArr.length; nmArr.push(n); map.set(n, li); } e.push(...prev.e.slice(i, i + 8), li, prev.e[i + 9]); } }
      if (!e.length) continue; const used = [...new Set(e.filter((v, i) => i % 10 === 8))].sort((a, b) => a - b), re = new Map(used.map((v, i) => [v, i])); for (let i = 8; i < e.length; i += 10) e[i] = re.get(e[i]); nmArr = used.map(v => nmArr[v]);
      fs.writeFileSync(f, gz({ v: 1, cell: c, names: nmArr, e })); wrote++; }
    log('network (main roads): ' + wrote + ' squares written'); return { ways, edges, cells: wrote, capped }; }
  for (const [c, C] of cells) { const f = path.join(outDir, 'net-' + c + '.json.gz'); let prev = null; try { prev = readGz(f); } catch (e) {}
    if (!prev && dirMB(outDir) > CAP_MB) { log('network: size cap reached (' + CAP_MB + ' MB) - ' + c + ' left out'); continue; }
    /* a square shared by two regions: keep the edges of both, without doubles */
    let nmArr = [...C.nm.keys()], e = C.e; if (prev && prev.e && prev.names) { const seen = new Set(); for (let i = 0; i < e.length; i += 10) seen.add(e.slice(i, i + 4).join(',')); const map = new Map(nmArr.map((n, i) => [n, i]));
      for (let i = 0; i < prev.e.length; i += 10) { if (seen.has(prev.e.slice(i, i + 4).join(','))) continue; const n = prev.names[prev.e[i + 8]] || ''; let li = map.get(n); if (li === undefined) { li = nmArr.length; nmArr.push(n); map.set(n, li); } e.push(...prev.e.slice(i, i + 8), li, prev.e[i + 9]); } }
    const body = gz({ v: 1, cell: c, names: nmArr, e }); fs.writeFileSync(f, body);
    { const m = []; for (let i = 0; i < e.length; i += 10) if (e[i + 5] <= 7) for (let k = 0; k < 10; k++) m.push(e[i + k]); fs.writeFileSync(path.join(outDir, 'netm-' + c + '.json.gz'), gz({ v: 1, cell: c, names: nmArr, e: m })); } idx.cells[c] = { edges: e.length / 10, kb: Math.round(body.length / 1024) }; }
  idx.built = new Date().toISOString(); idx.licence = 'Road data (c) OpenStreetMap contributors, ODbL'; fs.writeFileSync(idxF, JSON.stringify(idx));
  log('network: ' + edges + ' edges in ' + cells.size + ' squares'); return { ways, edges, cells: cells.size };
}
/* keep the shape but drop points closer than ~15 m to the straight line between their neighbours */
function thin(pts) { if (pts.length < 3) return pts; const out = [pts[0]]; for (let i = 1; i < pts.length - 1; i++) { const a = out[out.length - 1], b = pts[i], c = pts[i + 1]; const ax = (b[1] - a[1]) * Math.cos(b[0] / 1e5 * rad), ay = b[0] - a[0], bx = (c[1] - a[1]) * Math.cos(b[0] / 1e5 * rad), by = c[0] - a[0];
  const L = Math.hypot(bx, by) || 1, d = Math.abs(ax * by - ay * bx) / L * 1.11; if (d > 15 || Math.hypot(ax, ay) * 1.11 > 400) out.push(b); } out.push(pts[pts.length - 1]); return out; }
