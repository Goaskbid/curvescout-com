/* CurveScout phone-router repair, 2026-11-11.
 * Local computation uses downloaded same-origin OSM-derived network tiles.
 * The host sees tile requests and normal connection metadata. Online routing,
 * when selected, sends coordinates to the configured routing provider first.
 * Compatibility: legacy v1 compact tiles; optional stable node_ids in newer tiles.
 * This reader cannot reconstruct missing OSM access/turn-restriction metadata.
 * r89: coverage tiles (netc-*, v2) carry OSM node ids, way ids and via-node turn restrictions; legacy tiles keep
 * their coordinate junctions. Which squares have which tiles comes from net-index.json and netc-index.json.
 * Preserve graph provenance and qualify the source graph separately for guidance.
 */
(function () {
  'use strict';
  if (window.CS_PHONE_ROUTE) return;
  const RAD = Math.PI / 180, R = 6371008.8;
  const SPEED = [110,60,90,50,75,45,65,40,55,35,45,30,10];
  const rawFetch = window.fetch.bind(window);
  const G = {key:new Map(),la:[],lo:[],adj:[],E:[],loaded:{},byCell:{},edgeCells:new Map(),edgeKeys:new Set(),legacyTiles:0,coordStable:new Map(),restN:new Map(),restPend:new Map()};
  const pending = new Map();
  const wrap = x => ((x + 180) % 360 + 360) % 360 - 180;
  const finite = x => typeof x === 'number' && Number.isFinite(x);
  const valid = p => Array.isArray(p) && p.length === 2 && finite(p[0]) && finite(p[1]) && Math.abs(p[0])<=90 && Math.abs(p[1])<=180;
  function abortError() {return new DOMException('Routing cancelled','AbortError');}
  function check(signal) {if(signal && signal.aborted) throw abortError();}
  function hav(a,b) {const x=(b[0]-a[0])*RAD,y=wrap(b[1]-a[1])*RAD;const s=Math.sin(x/2)**2+Math.cos(a[0]*RAD)*Math.cos(b[0]*RAD)*Math.sin(y/2)**2;return 2*R*Math.asin(Math.sqrt(Math.min(1,Math.max(0,s))));}
  function bearing(a,b) {const dl=wrap(b[1]-a[1])*RAD;return (Math.atan2(Math.sin(dl)*Math.cos(b[0]*RAD),Math.cos(a[0]*RAD)*Math.sin(b[0]*RAD)-Math.sin(a[0]*RAD)*Math.cos(b[0]*RAD)*Math.cos(dl))/RAD+360)%360;}
  function dec(s) {const out=[];let i=0,la=0,lo=0;while(i<s.length){for(let k=0;k<2;k++){let r=0,shift=0,b;do{if(i>=s.length||shift>30)throw Error('Malformed graph polyline');b=s.charCodeAt(i++)-63;if(b<0||b>63)throw Error('Malformed graph polyline');r|=(b&31)<<shift;shift+=5;}while(b>=32);const d=(r&1)?~(r>>1):r>>1;if(k===0)la+=d;else lo+=d;}if(!valid([la/1e5,lo/1e5]))throw Error('Invalid graph coordinate');out.push([la/1e5,lo/1e5]);}return out;}
  const cell = p => Math.floor(p[0])+'_'+Math.floor(wrap(p[1]));
  function nkey(la,lo,stable){if(stable===undefined)return -((la+9000000)*40000000+(lo+18000000))-1;const n=Number(stable);return Number.isSafeInteger(n)&&n>=0&&String(n)===String(stable)?n:'id:'+String(stable);}   /* r87: numeric keys - far less memory than strings */
  function node(la,lo,stable) {const k=nkey(la,lo,stable);let i=G.key.get(k);if(i===undefined){i=G.la.length;G.key.set(k,i);G.la.push(la);G.lo.push(lo);G.adj.push([]);const c=cell([la/1e5,lo/1e5]);(G.byCell[c]||(G.byCell[c]=[])).push(i);seam(i,la,lo,stable,k);}else if(G.la[i]!==la||G.lo[i]!==lo)throw Error('Inconsistent graph node identity');return i;}
  /* r89 seam: where a coverage tile (OSM node ids) meets a legacy tile (coordinate junctions) the same road end exists as
     two nodes at the same point; they are joined by a 1 m connector - only when exactly one id-node sits at that point
     (two id-nodes at one point are a bridge over a road and stay apart) */
  function seam(i,la,lo,stable,k){if(stable===undefined){const s=G.coordStable.get(k);if(s!==undefined&&s>=0)connect(i,s);return;}
    const ck=nkey(la,lo);const prev=G.coordStable.get(ck);if(prev===undefined){G.coordStable.set(ck,i);const l=G.key.get(ck);if(l!==undefined)connect(l,i);}else if(prev!==i)G.coordStable.set(ck,-1);
    const pr=G.restPend.get(k);if(pr){G.restPend.delete(k);G.restN.set(i,(G.restN.get(i)||[]).concat(pr));}}
  function connect(a,b){const id=G.E.length,e=new Edge(a,b,[0,0,0,0,1,4,0,0,0,''],'');e.conn=1;G.E.push(e);G.adj[a].push(id);G.adj[b].push(-id-1);indexCells(id,[cell([G.la[a]/1e5,G.lo[a]/1e5])]);}
  function edgePts(pa,pb,g){const P=[pa,...dec(g),pb],o=[pa];for(let k=1;k<P.length;k++){const q=o[o.length-1],p=P[k];if(p[0]!==q[0]||p[1]!==q[1])o.push(p);}return o;}   /* r88: points sit on a 1e-5 grid - closer than 1 cm means the same point; no distance maths per point */
  function cumOf(pts){const cum=[0];for(let k=1;k<pts.length;k++)cum.push(cum[k-1]+hav(pts[k-1],pts[k]));return cum;}
  const TOUCHED=[];
  function ekey(str){let h1=0x811c9dc5,h2=0x9747b28c;for(let i=0;i<str.length;i++){const c=str.charCodeAt(i);h1=Math.imul(h1^c,16777619);h2=Math.imul(h2^c,1540483477)^(h2>>>15);}return (h1>>>0)*2097152+((h2>>>0)&2097151);}   /* r87: 53-bit number instead of a long string per edge */
  /* r88 (owner: "sort out this crazy slowness"): an edge's identity hash is mixed from its numbers and its road line's
     characters directly - building one long text per edge and hashing it was 40% of a trip's load time */
  let H1=0,H2=0;function mx(v){H1=Math.imul(H1^v,16777619);H2=Math.imul(H2^v,1540483477)^(H2>>>15);}
  function mxs(t,from,to){for(let i=from;i<to;i++)mx(t.charCodeAt(i));}
  function mxv(x){if(typeof x==='number'&&Number.isSafeInteger(x)){mx(x|0);mx((x/4294967296)|0);}else if(x===undefined)mx(-7);else{const t=String(x);mx(-t.length);mxs(t,0,t.length);}}
  function ekeyOf(a,sa,sb){H1=0x811c9dc5;H2=0x9747b28c;mxv(sa);mxv(sb);for(let k=0;k<9;k++)mxv(a[k]);const g=a[9],n=g.length;mx(n);if(n<=32)mxs(g,0,n);else{mxs(g,0,16);mxs(g,n-16,n);}return (H1>>>0)*2097152+((H2>>>0)&2097151);}   /* the ends, the numbers and the length of a road line name it; the whole line is not read */
  /* r87: a slim edge - its ends are its nodes' coordinates, class/flags/curvature packed in one number */
  class Edge{constructor(na,nb,a,name,w){this.a=na;this.b=nb;this.len=a[4];this.m=a[5]|(a[6]<<4)|(a[7]<<12);this.name=name;this.g=a[9];this._p=null;this.w=w;this.conn=0;}
    get total(){const c=this.cum;return c[c.length-1];}
    get cls(){return this.m&15;} get fl(){return (this.m>>4)&255;} get cv(){return (this.m>>12)&255;}
    get pts(){if(!this._p){const A=[G.la[this.a]/1e5,G.lo[this.a]/1e5],B=[G.la[this.b]/1e5,G.lo[this.b]/1e5];let P=edgePts(A,B,this.g);if(P.length<2)P=[A,B];this._p=[P,null];TOUCHED.push(this);}return this._p[0];}
    get cum(){const P=this.pts;return this._p[1]||(this._p[1]=cumOf(P));}}
  function dropTouched(){for(const e of TOUCHED)e._p=null;TOUCHED.length=0;}
  /* r87: an edge whose nearer end is further from the stop than the edge is long cannot come within the snap limit - its
     points are never decoded for snapping */
  function maybeNear(e,p,limit){if(!(e instanceof Edge))return true;const ky=1.11195,kx=ky*Math.cos(p[0]*RAD),ya=(G.la[e.a]-p[0]*1e5)*ky,xa=wrap(G.lo[e.a]/1e5-p[1])*1e5*kx,yb=(G.la[e.b]-p[0]*1e5)*ky,xb=wrap(G.lo[e.b]/1e5-p[1])*1e5*kx,d=Math.sqrt(Math.min(xa*xa+ya*ya,xb*xb+yb*yb))*0.97;return d-(e.len*1.05+50)<=limit+1;}   /* r88: flat-earth distance with a 3% margin in place of two great-circle sums per road (it only rules roads out) */
  function indexCells(id,keys){for(const k of keys){if(!G.edgeCells.has(k))G.edgeCells.set(k,new Set());G.edgeCells.get(k).add(id);}}
  function indexEdge(e,id,P) {const keys=new Set();const pts=P||e.pts;for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i];const n=Math.max(1,Math.ceil(Math.max(Math.abs(b[0]-a[0]),Math.abs(wrap(b[1]-a[1])))*4));for(let j=0;j<=n;j++)keys.add(cell([a[0]+(b[0]-a[0])*j/n,wrap(a[1]+wrap(b[1]-a[1])*j/n)]));}for(const k of keys){if(!G.edgeCells.has(k))G.edgeCells.set(k,new Set());G.edgeCells.get(k).add(id);}}
  function addCell(j) {
    if(!j||!Array.isArray(j.e)||j.e.length%10||!Array.isArray(j.names)||j.e.length>10000000)throw Error('Malformed network tile');
    const stable=Array.isArray(j.node_ids)&&j.node_ids.length===j.e.length/5;
    if(j.node_ids&&!stable)throw Error('Invalid node identity table');
    const staged=[],identities=new Map();
    for(let i=0;i<j.e.length;i+=10){const a=j.e.slice(i,i+10),pa=[a[0]/1e5,a[1]/1e5],pb=[a[2]/1e5,a[3]/1e5];
      if(!(Number.isInteger(a[0])&&Number.isInteger(a[1])&&Number.isInteger(a[2])&&Number.isInteger(a[3]))||!valid(pa)||!valid(pb)||!finite(a[4])||a[4]<=0||!Number.isInteger(a[5])||a[5]<0||a[5]>=SPEED.length||!Number.isInteger(a[6])||a[6]<0||a[6]>255||!finite(a[7])||a[7]<0||a[7]>255||!Number.isInteger(a[8])||a[8]<0||a[8]>=j.names.length||typeof j.names[a[8]]!=='string'||typeof a[9]!=='string')throw Error('Invalid network edge');
      const sa=stable?j.node_ids[i/5]:undefined,sb=stable?j.node_ids[i/5+1]:undefined;
      for(const [key,p] of [[sa,pa],[sb,pb]])if(key!==undefined){if(!['string','number'].includes(typeof key)||String(key)==='')throw Error('Invalid node identity');const k=nkey(0,0,key),old=G.key.get(k),prev=identities.get(k);if((old!==undefined&&(G.la[old]!==Math.round(p[0]*1e5)||G.lo[old]!==Math.round(p[1]*1e5)))||(prev&&(prev[0]!==p[0]||prev[1]!==p[1])))throw Error('Inconsistent graph identity');identities.set(k,p);}
      /* r88 (owner: "sort out this crazy slowness"): a road's points are decoded at load only when it leaves its own cell -
         most roads stay inside one, and their points are only needed if a route touches them */
      const far=cell(pa)!==cell(pb)||a[4]>40000,pts=far?edgePts(pa,pb,a[9]):null;if(pts&&pts.length<2)throw Error('Empty network edge');
      staged.push({a,sa,sb,pts,name:j.names[a[8]],w:Array.isArray(j.w)?j.w[i/10]:undefined});
    }
    for(const x of staged){const a=x.a,key=ekeyOf(a,x.sa,x.sb);if(G.edgeKeys.has(key))continue;const na=node(a[0],a[1],x.sa),nb=node(a[2],a[3],x.sb),id=G.E.length;   /* r89: after node(), which may add a seam connector */
      /* r87: an edge keeps only its compact road line; its points and running distances are rebuilt when a route needs them
         and dropped again after the route (memory: a 7-day trip held ~370 MB of point arrays and crashed phones) */
      const e=new Edge(na,nb,a,x.name,x.w);G.E.push(e);G.edgeKeys.add(key);G.adj[na].push(id);if(!(e.fl&1))G.adj[nb].push(-id-1);if(x.pts)indexEdge(e,id,x.pts);else indexCells(id,[cell([a[0]/1e5,a[1]/1e5])]);}
    if(!stable)G.legacyTiles++;
    /* r89: via-node turn restrictions of a coverage tile: [from way, via node, to way, only?] */
    if(stable&&Array.isArray(j.rs))for(let i=0;i+3<j.rs.length;i+=4){const r={from:j.rs[i],to:j.rs[i+2],only:j.rs[i+3]===1},k=nkey(0,0,j.rs[i+1]),v=G.key.get(k);if(v!==undefined)G.restN.set(v,(G.restN.get(v)||[]).concat([r]));else G.restPend.set(k,(G.restPend.get(k)||[]).concat([r]));}
  }
  async function decodeResponse(r) {const b=await r.arrayBuffer();if(b.byteLength>25000000)throw Error('Network tile exceeds byte limit');if(typeof window.csGunzipJson==='function')return window.csGunzipJson(b);const u=new Uint8Array(b);if(u[0]!==31||u[1]!==139)return JSON.parse(new TextDecoder().decode(u));if(typeof window.DecompressionStream==='function')return new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'))).json();if(window.pako&&typeof window.pako.ungzip==='function')return JSON.parse(window.pako.ungzip(u,{to:'string'}));throw Error('Gzip decoder unavailable');}
  function waitFor(p,signal) {check(signal);if(!signal)return p;return new Promise((resolve,reject)=>{const onAbort=()=>{signal.removeEventListener('abort',onAbort);reject(abortError());};signal.addEventListener('abort',onAbort,{once:true});p.then(v=>{signal.removeEventListener('abort',onAbort);if(signal.aborted)reject(abortError());else resolve(v);},e=>{signal.removeEventListener('abort',onAbort);reject(e);});});}
  /* r89: which squares have a legacy full tile (net-index.json) and which a qualified coverage tile (netc-index.json);
     a square in neither is not asked for (no requests for squares the site does not have) */
  let IDX=null,IDXctl=null;
  function indexes(signal){if(!IDX){const ctl=new AbortController();IDXctl=ctl;const t=setTimeout(()=>ctl.abort(),8000);
      IDX=(async()=>{const get=async u=>{try{const r=await rawFetch(u,{signal:ctl.signal});if(!r.ok)return null;const j=await r.json();return j&&j.cells?new Set(Object.keys(j.cells)):null;}catch(e){return null;}};const [l,c]=await Promise.all([get('/data/net/net-index.json'),get('/data/net/netc-index.json')]);clearTimeout(t);
        if(ctl.signal.aborted&&IDX===P){IDX=null;}return {legacy:l,cov:c||new Set()};})();const P=IDX;}
    if(signal)signal.addEventListener('abort',()=>{if(IDXctl&&IDX){IDXctl.abort();}},{once:true});
    return waitFor(IDX,signal);}   /* an index read given up with its route is read again by the next route */
  async function load(c,major,signal) {
    check(signal);const k=(major==='c'?'c':major?'m':'f')+c;if(major==='c'&&G.loaded[k])return true;if(G.loaded['f'+c]||G.loaded[k])return true;if(G.miss&&G.miss[k]&&Date.now()-G.miss[k]<30000)return false;   /* r88 (audit R1): a missing tile is asked for again after 30 s *//* r83: a tile the site does not have is asked for once, not on every route */
    let task=pending.get(k);
    if(!task){const ctl=new AbortController();task={ctl,users:0,done:false};pending.set(k,task);
      task.promise=(async()=>{let timer;try{const body=(async()=>{const r=await rawFetch('/data/net/net'+(major==='c'?'c':major?'m':'')+'-'+c+'.json.gz',{signal:ctl.signal});if(!r.ok){if(r.status===404)(G.miss||(G.miss={}))[k]=Date.now();return null;}const b=await r.arrayBuffer();return {arrayBuffer:async()=>b};})();const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{ctl.abort();reject(Error('Network tile timed out'));},10000);});const got=await Promise.race([body,timeout]);clearTimeout(timer);check(ctl.signal);if(!got)return false;task.got=true;const j=await decodeResponse(got);   /* r88 (slowness): the 10 s limit is for the download; unpacking a tile on a busy phone took longer, timed out, and the tile was fetched and unpacked a second time */addCell(j);G.loaded[k]=1;return true;}catch(e){return false;}finally{clearTimeout(timer);task.done=true;if(pending.get(k)===task)pending.delete(k);}})();
    }
    task.users++;try{return await waitFor(task.promise,signal);}finally{task.users--;if(!task.users&&!task.done&&!task.got){task.ctl.abort();   /* r88: a tile already downloaded is still unpacked and kept when its route is given up (a slow phone gave up a trip day after 15 s and fetched every tile again) */if(pending.get(k)===task)pending.delete(k);}}
  }
  function cellsFor(pts) {const full=new Set(),major=new Set();function around(p,set){for(let dl=-1;dl<=1;dl++)for(let dn=-1;dn<=1;dn++){const lat=Math.floor(p[0])+dl;if(lat< -90||lat>=90)continue;set.add(lat+'_'+Math.floor(wrap(Math.floor(p[1])+dn)));}}
    /* r87 (owner: a 7-day Geneva-Rome trip crashed the phone): a long transfer (over 250 km between stops) keeps full road
       detail only in the stop's own cell and a neighbour it is within 0.2 degrees of - main roads elsewhere (a tile without a
       main-road file falls back to the full one). Rides and shorter legs keep the full ring around every stop. */
    let span=0;for(let i=1;i<pts.length;i++)span=Math.max(span,hav(pts[i-1],pts[i]));
    const near=(p,set)=>{const la=Math.floor(p[0]),lo=Math.floor(p[1]),fy=p[0]-la,fx=p[1]-lo,dys=[0].concat(fy<0.2?[-1]:[],fy>0.8?[1]:[]),dxs=[0].concat(fx<0.2?[-1]:[],fx>0.8?[1]:[]);for(const dl of dys)for(const dn of dxs){const lat=la+dl;if(lat< -90||lat>=90)continue;set.add(lat+'_'+Math.floor(wrap(lo+dn)));}};
    if(span>250000)pts.forEach(p=>{near(p,full);around(p,major);});else pts.forEach(p=>around(p,full));for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],n=Math.max(1,Math.ceil(hav(a,b)/40000));if(n>300)throw Error('Route exceeds local coverage budget');for(let s=0;s<=n;s++)around([a[0]+(b[0]-a[0])*s/n,wrap(a[1]+wrap(b[1]-a[1])*s/n)],major);}for(const c of full)major.delete(c);if(full.size+major.size>400)throw Error('Route exceeds local coverage budget');return [...full].map(c=>[c,false]).concat([...major].map(c=>[c,true]));}
  async function loadAll(tasks,signal) {const X=await indexes(signal);check(signal);let cursor=0,found=0;await Promise.all(Array.from({length:Math.min(4,tasks.length)},async()=>{while(cursor<tasks.length){check(signal);const item=tasks[cursor++],c=item[0];let ok;
      if(X.legacy&&!X.legacy.has(c))ok=X.cov.has(c)?await load(c,'c',signal):false;   /* r89: not a legacy square - its coverage tile, if qualified, else nothing */
      else ok=await load(c,item[1],signal)||(item[1]?await load(c,false,signal):false)||(X.cov.has(c)?await load(c,'c',signal):false);
      if(ok)found++;}}));return found;}   /* r87: no major-road tile there -> the full tile */
  function allowed(e,o){return !(o.motorway&&(e.fl&4))&&!(o.toll&&(e.fl&2))&&!(o.ferry&&(e.fl&8));}
  function snap(p,o) {const ids=new Set();for(let dl=-1;dl<=1;dl++)for(let dn=-1;dn<=1;dn++){const es=G.edgeCells.get((Math.floor(p[0])+dl)+'_'+Math.floor(wrap(Math.floor(p[1])+dn)));if(es)for(const id of es)ids.add(id);}let best=null;const scaleX=R*RAD*Math.max(0.000001,Math.cos(p[0]*RAD)),scaleY=R*RAD,limit=finite(o.maxSnapMeters)?Math.min(800,Math.max(0,o.maxSnapMeters)):800;
    for(const id of ids){const e=G.E[id];if(!allowed(e,o)||!maybeNear(e,p,limit))continue;for(let k=1;k<e.pts.length;k++){const a=e.pts[k-1],b=e.pts[k],ax=wrap(a[1]-p[1])*scaleX,ay=(a[0]-p[0])*scaleY,dx=wrap(b[1]-a[1])*scaleX,dy=(b[0]-a[0])*scaleY,l2=dx*dx+dy*dy,t=l2?Math.max(0,Math.min(1,-(ax*dx+ay*dy)/l2)):0;const q=[a[0]+(b[0]-a[0])*t,wrap(a[1]+wrap(b[1]-a[1])*t)],d=hav(p,q);if(d<=limit+0.000001&&(!best||d<best.distance-0.01)){best={edge:id,segment:k,t,point:q,distance:d,along:e.cum[k-1]+(e.cum[k]-e.cum[k-1])*t};}}}return best;}
  function queryGraph(snaps) {const baseN=G.la.length,baseE=G.E.length,points=[],edges=[],adj=new Map(),cut=new Set(),groups=new Map(),ids=[];
    const point=n=>n<baseN?[G.la[n]/1e5,G.lo[n]/1e5]:points[n-baseN];const edge=id=>id<baseE?G.E[id]:edges[id-baseE];
    function adjacency(n){if(!adj.has(n))adj.set(n,n<baseN?G.adj[n].filter(x=>!cut.has(x<0?-x-1:x)):[]);return adj.get(n);}
    snaps.forEach((s,i)=>{if(!groups.has(s.edge))groups.set(s.edge,[]);groups.get(s.edge).push({...s,index:i});});
    for(const [eid,ss] of groups){const e=G.E[eid];cut.add(eid);const marks=[{at:0,node:e.a,point:e.pts[0]},{at:e.total,node:e.b,point:e.pts.at(-1)}];
      for(const s of ss.sort((a,b)=>a.along-b.along)){let mark=marks.find(m=>Math.abs(m.at-s.along)<0.05);if(!mark){mark={at:s.along,node:baseN+points.length,point:s.point};points.push(s.point);marks.push(mark);}ids[s.index]=mark.node;}
      marks.sort((a,b)=>a.at-b.at);for(let i=1;i<marks.length;i++){const a=marks[i-1],b=marks[i];if(b.at-a.at<0.01)continue;const pts=[a.point];for(let k=1;k<e.pts.length-1;k++)if(e.cum[k]>a.at+0.01&&e.cum[k]<b.at-0.01)pts.push(e.pts[k]);pts.push(b.point);const ne={a:a.node,b:b.node,len:e.len*(b.at-a.at)/e.total,cls:e.cls,fl:e.fl,cv:e.cv,name:e.name,g:e.g,total:e.total,pts,cum:e.cum,w:e.w,conn:e.conn},id=baseE+edges.length;edges.push(ne);adjacency(a.node).push(id);if(!(e.fl&1))adjacency(b.node).push(-id-1);}
    }
    // A later cut may affect an adjacency already instantiated for a shared node.
    for(const [n,list] of adj)adj.set(n,list.filter(id=>!cut.has(id<0?-id-1:id)));
    return {ids,point,edge,adj:n=>adj.get(n)||(n<baseN?G.adj[n].filter(id=>(id<0?-id-1:id)<baseE&&!cut.has(id<0?-id-1:id)):[])};
  }
  async function astar(s,t,o,Q,signal) {const g=new Map([[s,0]]),prev=new Map(),done=new Set(),heap=[];const heuristic=n=>hav(Q.point(n),Q.point(t))/(110/3.6)*(o.curvy?0.6:1);
    function push(x){heap.push(x);let i=heap.length-1;while(i){const p=(i-1)>>1;if(heap[p][0]<=heap[i][0])break;[heap[i],heap[p]]=[heap[p],heap[i]];i=p;}}
    function pop(){const top=heap[0],last=heap.pop();if(heap.length){heap[0]=last;let i=0;for(;;){const l=i*2+1,r=l+1;let m=i;if(l<heap.length&&heap[l][0]<heap[m][0])m=l;if(r<heap.length&&heap[r][0]<heap[m][0])m=r;if(m===i)break;[heap[i],heap[m]]=[heap[m],heap[i]];i=m;}}return top;}
    push([heuristic(s),s]);let n=0;while(heap.length){check(signal);const u=pop()[1];if(done.has(u))continue;done.add(u);if(u===t)break;if(++n>3000000)return null;if(n%4096===0)await new Promise(resolve=>setTimeout(resolve,0));const RL=u<G.la.length?G.restN.get(u):undefined,pin=RL?prev.get(u):undefined,inW=pin===undefined?undefined:Q.edge(pin<0?-pin-1:pin).w;for(const id of Q.adj(u)){const rev=id<0,e=Q.edge(rev?-id-1:id),v=rev?e.a:e.b;if(!allowed(e,o))continue;if(RL&&inW!==undefined&&RL.some(r=>r.from===inW&&(r.only?r.to!==e.w:r.to===e.w)))continue;   /* r89: a turn the map forbids is never taken */let cost=e.len/(SPEED[e.cls]/3.6);if(o.curvy)cost*=(e.fl&4)?1.8:(e.cls>=4&&e.cls<=10?1.15-e.cv/255*0.55:1.05);const score=g.get(u)+cost;if(score<(g.get(v)??Infinity)){g.set(v,score);prev.set(v,id);push([score+heuristic(v),v]);}}}
    if(s!==t&&!prev.has(t))return null;const path=[];let at=t;while(at!==s){const id=prev.get(at);if(id===undefined||path.length>G.E.length+snapsBudget)return null;path.push(id);const e=Q.edge(id<0?-id-1:id);at=id<0?e.b:e.a;}return path.reverse();
  }
  const snapsBudget=400;
  function modifier(d){d=wrap(d);const a=Math.abs(d);return a<20?'straight':a<45?(d>0?'slight right':'slight left'):a<135?(d>0?'right':'left'):(d>0?'sharp right':'sharp left');}
  function leg(path,Q){const steps=[];let current=null,coords=[],distance=0,duration=0;for(const id of path){if(Q.edge(id<0?-id-1:id).conn)continue;   /* r89: a 1 m seam connector is not a road of its own */
    const e=Q.edge(id<0?-id-1:id),pts=id<0?e.pts.slice().reverse():e.pts.slice(),seconds=e.len/(SPEED[e.cls]/3.6);coords=coords.length?coords.concat(pts.slice(1)):pts;distance+=e.len;duration+=seconds;const before=current?bearing(current.pts.at(-2),current.pts.at(-1)):0,after=bearing(pts[0],pts[1]),m=modifier(after-before),fresh=!current||e.name!==current.name||Math.abs(wrap(after-before))>60;if(fresh){if(current)steps.push(current.step);let type=!current?'depart':e.name===current.name?'continue':m==='straight'?'new name':'turn';if(current&&(e.fl&4)&&!(current.fl&4))type='on ramp';else if(current&&!(e.fl&4)&&(current.fl&4))type='off ramp';current={name:e.name,fl:e.fl,pts,step:{distance:e.len,duration:seconds,name:e.name,mode:'driving',geometry:{type:'LineString',coordinates:pts.map(p=>[p[1],p[0]])},maneuver:{type,modifier:steps.length?m:undefined,location:[pts[0][1],pts[0][0]],bearing_before:Math.round(before),bearing_after:Math.round(after)}}};}else{current.step.distance+=e.len;current.step.duration+=seconds;current.pts=current.pts.concat(pts.slice(1));current.step.geometry.coordinates=current.step.geometry.coordinates.concat(pts.slice(1).map(p=>[p[1],p[0]]));current.fl=e.fl;}}
    if(current)steps.push(current.step);if(coords.length<2)return null;const end=coords.at(-1);steps.push({distance:0,duration:0,name:'',mode:'driving',geometry:{type:'LineString',coordinates:[[end[1],end[0]],[end[1],end[0]]]},maneuver:{type:'arrive',location:[end[1],end[0]],bearing_before:0,bearing_after:0}});return{distance,duration,weight:duration,steps,summary:'',coords};}
  /* r87: a memory budget for the road graph - when no route is being worked out and the graph holds more than the budget,
     it is emptied before the next route (tiles come back from the browser cache; a 7-day trip no longer piles up) */
  let ACTIVE=0;const BUDGET=20;
  function weight(){let w=0;for(const k in G.loaded)w+=k[0]==='m'?0.25:1;return w;}
  function resetGraph(){G.key=new Map();G.la=[];G.lo=[];G.adj=[];G.E=[];G.loaded={};G.byCell={};G.edgeCells=new Map();G.edgeKeys=new Set();G.legacyTiles=0;G.coordStable=new Map();G.restN=new Map();G.restPend=new Map();API.resets=(API.resets||0)+1;}
  /* r88 (slowness): a trip asks for its days one after another, so the graph was idle - and emptied - between two days of the
     same trip and its tiles were fetched and decoded again (27 of 89 on Geneva - Madrid). It is now emptied only after 12 s
     without a route, or at once when it holds over 1.8 times the budget (the memory guard stays). */
  let lastEnd=0,idleT=0;
  async function route(pts,o){const w=ACTIVE===0&&pending.size===0?weight():0;if(w>BUDGET*1.8||(w>BUDGET&&Date.now()-lastEnd>12000))resetGraph();ACTIVE++;try{return await route0(pts,o);}finally{ACTIVE--;lastEnd=Date.now();if(ACTIVE===0){dropTouched();clearTimeout(idleT);idleT=setTimeout(()=>{if(ACTIVE===0&&pending.size===0&&Date.now()-lastEnd>=12000&&weight()>BUDGET)resetGraph();},12500);}}}   /* and emptied 12.5 s after the last route when over budget, so an open page does not keep a trip's roads */
  async function route0(pts,o){o={...(o||{})};const signal=o.signal;check(signal);if(!Array.isArray(pts)||pts.length<2||pts.length>100||!pts.every(valid))return{code:'InvalidQuery',message:'Every required stop needs valid coordinates'};
    const visits=pts.map(p=>p.slice());let tasks;try{tasks=cellsFor(visits);}catch(e){return{code:'NoRoute',message:e.message};}const loaded=await loadAll(tasks,signal);check(signal);const snaps=visits.map((p,i)=>snap(p,{...o,maxSnapMeters:o.radiuses&&Number.isFinite(o.radiuses[i])?Math.min(o.maxSnapMeters??800,o.radiuses[i]):o.maxSnapMeters}));if(snaps.some(x=>!x))return{code:'NoSegment',message:'A required stop is outside the downloaded road network'};const Q=queryGraph(snaps),legs=[];let coords=[];
    for(let i=1;i<Q.ids.length;i++){check(signal);if(Q.ids[i]===Q.ids[i-1])return{code:'NoRoute',message:'Consecutive stops do not define a usable road segment'};const p=await astar(Q.ids[i-1],Q.ids[i],o,Q,signal);if(!p||!p.length)return{code:'NoRoute',message:'No permitted road connects the required stops'};const l=leg(p,Q);if(!l)return{code:'NoRoute',message:'No usable route geometry'};coords=coords.length?coords.concat(l.coords.slice(1)):l.coords;delete l.coords;legs.push(l);}check(signal);
    const distance=legs.reduce((n,l)=>n+l.distance,0),duration=legs.reduce((n,l)=>n+l.duration,0);if(coords.length<2||!finite(distance)||distance<=0||legs.length!==visits.length-1)return{code:'NoRoute',message:'Incomplete route'};
    return{code:'Ok',source:'curvescout-phone',routes:[{distance,duration,weight:duration,weight_name:'routability',legs,geometry:{type:'LineString',coordinates:coords.map(p=>[p[1],p[0]])}}],waypoints:snaps.map(s=>({location:[s.point[1],s.point[0]],distance:s.distance,name:G.E[s.edge].name})),cs_provenance:{engine:'r50-repair-20261111',loaded_tiles:loaded,requested_tiles:tasks.length,legacy_topology:G.legacyTiles>0,graph_access_and_restrictions_verified:false}};
  }
  function encode(coords,precision){let la=0,lo=0,out='';const factor=10**precision,part=n=>{let v=n<0?~(n<<1):n<<1,r='';while(v>=32){r+=String.fromCharCode((32|(v&31))+63);v>>>=5;}return r+String.fromCharCode(v+63);};for(const p of coords){const a=Math.round(p[1]*factor),b=Math.round(p[0]*factor);out+=part(a-la)+part(b-lo);la=a;lo=b;}return out;}
  function parse(url){let u;try{u=new URL(url,location.href);}catch(e){return null;}if(!['router.project-osrm.org','routing.openstreetmap.de'].includes(u.hostname))return null;const m=/\/route\/v1\/(driving|car|motorcycle)\/([^?]+)$/.exec(u.pathname);if(!m)return null;let pts;try{pts=decodeURIComponent(m[2]).split(';').map(s=>{const p=s.split(',');return p.length===2&&p.every(x=>x.trim()!==''&&Number.isFinite(Number(x)))?[Number(p[1]),Number(p[0])]:[];});}catch(e){return null;}if(pts.length<2||!pts.every(valid))return null;const ex=(u.searchParams.get('exclude')||'').split(',').filter(Boolean);if(ex.some(x=>!['motorway','toll','ferry'].includes(x)))return null;const radiusText=u.searchParams.get('radiuses'),radiuses=radiusText?radiusText.split(';').map(x=>x==='unlimited'?Infinity:x.trim()!==''?Number(x):NaN):null;const geometry=u.searchParams.get('geometries')||'polyline',unsupported=['bearings','approaches','waypoints'].filter(k=>u.searchParams.get(k));if(radiuses&&(radiuses.length!==pts.length||radiuses.some(r=>!(r>=0))))unsupported.push('radiuses');return{pts,geometry,steps:u.searchParams.get('steps')==='true',overview:u.searchParams.get('overview')!=='false',unsupported,o:{radiuses,motorway:ex.includes('motorway'),toll:ex.includes('toll'),ferry:ex.includes('ferry'),curvy:u.searchParams.get('cs_curvy')==='1'}};}
  async function answer(p,signal){let j;if(p.unsupported.length||!['geojson','polyline','polyline6'].includes(p.geometry))j={code:'InvalidOptions',message:'The local network cannot preserve these routing options: '+p.unsupported.join(',')};else j=await route(p.pts,{...p.o,signal});check(signal);if(j.code==='Ok'){for(const r of j.routes){if(p.geometry!=='geojson'){r.geometry=encode(r.geometry.coordinates,p.geometry==='polyline6'?6:5);for(const l of r.legs)for(const s of l.steps)s.geometry=encode(s.geometry.coordinates,p.geometry==='polyline6'?6:5);}if(!p.overview)delete r.geometry;if(!p.steps)for(const l of r.legs)delete l.steps;}}API.last=j.code;return new Response(JSON.stringify(j),{status:j.code==='Ok'?200:400,headers:{'content-type':'application/json'}});}
  const API={route,graph:G,force:false,off:false,last:null,version:'r50-repair-20261111',reset:()=>{G.miss={};try{sessionStorage.removeItem('cs-phone-until');}catch(e){}}};
  window.CS_PHONE_ROUTE=API;
  window.fetch=async function(input,init){const url=typeof input==='string'?input:input&&input.url||'',p=parse(url);if(!p||API.off)return rawFetch(input,init);const signal=init&&init.signal||input&&input.signal;check(signal);if(API.force)return answer(p,signal);
    const ctl=new AbortController(),onAbort=()=>ctl.abort();if(signal)signal.addEventListener('abort',onAbort,{once:true});let timer,response,error;try{const online=rawFetch(input,{...init,signal:ctl.signal});const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{ctl.abort();reject(Error('Online routing timed out'));},7000);});response=await Promise.race([online,timeout]);}catch(e){error=e;}finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',onAbort);}check(signal);
    if(response&&response.status!==429&&response.status!==403&&response.status<500)return response;
    const mine=await answer(p,signal);check(signal);if(mine.ok)return mine;if(response)return response;if(error&&error.name==='AbortError'&&signal&&signal.aborted)throw abortError();return mine;
  };
})();
